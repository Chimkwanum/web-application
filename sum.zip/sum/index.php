<?php include('conn.php'); session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>How to Sum Column in MySQL using PHP/MySQLi</title>
</head>
<body>
	<h3>Sales Table</h3>
	<table border="1">
		<th>Product Name</th>
		<th>Quantity</th>
	<?php
		$total_qty=0;
		
		//MySQLi Procedural
		//$query=mysqli_query($conn,"select * from sales left join product on product.productid=sales.productid order by product.product_name asc");
		//while($row=mysqli_fetch_array($query)){
		/*	?>
				<tr>
					<td><?php echo $row['product_name']; ?></td>
					<td><?php echo $row['sales_qty']; ?></td>
				</tr>
				
			<?php */
		//	$total_qty += $row['sales_qty'];
		//}
		
		//MySQLi OOP
		$query=$conn->query("select * from sales left join product on product.productid=sales.productid order by product.product_name asc");
		while($row=$query->fetch_array()) {
			?>
				<tr>
					<td><?php echo $row['product_name']; ?></td>
					<td><?php echo $row['sales_qty']; ?></td>
				</tr>
			<?php 
			$total_qty += $row['sales_qty'];
		}
	?>
	<tr>
		<td>TOTAL QTY:</td>
		<td><?php echo $total_qty; ?></td>
	
	</tr>
	</table>
	<div style="position:relative; left: 300px; top: -300px;">
	<h3>Group By Product</h3>
	<ul>
	<?php 
		//MySQLi Procedural
		//$a=mysqli_query($conn,"select *, sum(sales_qty) as total_sales from sales left join product on product.productid=sales.productid group by sales.productid");
		//while($arow=mysqli_fetch_array($a)){
		/*	?>
			<li>Total <?php echo $arow['product_name'] ?>: <?php echo $arow['total_sales']; ?></li>
			<?php */
		//}
		
		//MySQLi OOP
		$a=$conn->query("select *, sum(sales_qty) as total_sales from sales left join product on product.productid=sales.productid group by sales.productid");
		while($arow=$a->fetch_array()){
			?>
			<li>Total <?php echo $arow['product_name'] ?>: <?php echo $arow['total_sales']; ?></li>
			<?php 
		}
	?>
	
	</ul>
	<h3>Insert New Sales</h3>
	<form method="POST" action="add_sale.php">
		<select name="sales_product">
			<option value="0">Select Product</option>
			<?php
				$p=$conn->query("select * from product");
				while($prow=$p->fetch_array()){
					?>
					<option value="<?php echo $prow['productid']; ?>"><?php echo $prow['product_name']; ?></option>
					<?php
				}
				
				//$p=mysqli_query($conn,"select * from product");
				//while($prow=mysqli_fetch_array($p)){
				/*	?>
					<option value="<?php echo $prow['productid']; ?>"><?php echo $prow['product_name']; ?></option>
					<?php */
				//}
			?>
		</select>
		Qty: <input type="text" name="sales_qty" required>
		<input type="submit" value="ADD">
	</form>
	<span>
		<?php
			if (isset($_SESSION['msg'])){
				echo $_SESSION['msg'];
				unset ($_SESSION['msg']);
			}
		?>
	</span>
	</div>
</body>
</html>