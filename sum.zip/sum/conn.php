<?php
 
//MySQLi Procedural
//$conn = mysqli_connect("localhost","root","","sum");
//if (!$conn) {
//	die("Connection failed: " . mysqli_connect_error());
//}

//MySQLi OOP
$conn = new mysqli("localhost","root","","sum");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
 
?>