<?php
class User {
	protected static $table_name = "users";
	
	public $id = 2;
	public $username;
	public $password;
	public $first_name;
	public $last_name;
	//Common database methods
}
$user = new User;
?>