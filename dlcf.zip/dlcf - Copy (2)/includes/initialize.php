<?php


/*

defined('SITE_ROOT') ? null : define('SITE_ROOT', DS. 'wamp' .DS. 'www' .DS. 'projects' .DS. 'btb' .DS. 'photo_gallery');

defined('LIB_PATH') ? null : define('LIB_PATH', SITE_ROOT.DS.'includes');

require_once(LIB_PATH.DS.'congif.php');

require_once(LIB_PATH.DS.'functions.php');

require_once(LIB_PATH.DS.'session.php');

require_once(LIB_PATH.DS.'database.php');

require_once(LIB_PATH.DS.'user.php');
*/
// require_once('database_object.php');
// require_once('session.php');
// require_once('database.php');
// require_once('photograph.php');
// require_once('comment.php');
// require_once('user.php');
// require_once('config.php');
// require_once('functions.php');
// require_once('pagination.php');
defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);

define("ADMIN_IMG", 'http://' .  $_SERVER['HTTP_HOST'] . '/projects/dlcf/public/admin_pics/');
define("POST_IMG", 'http://' .  $_SERVER['HTTP_HOST'] . '/projects/dlcf/public/post_pics/');
define("POST_URL", 'http://' .  $_SERVER['HTTP_HOST'] . '/projects/dlcf/public/posts/');
define("IMAGE_URL", 'http://' .  $_SERVER['HTTP_HOST'] . '/projects/dlcf/public/images/');
define("SCRIPT_URL", 'http://' .  $_SERVER['HTTP_HOST'] . '/projects/dlcf/public/javascripts/');

require_once('db_connection.php');
require_once('functions.php');
require_once('validation_functions.php');
require_once('session.php');

?>









