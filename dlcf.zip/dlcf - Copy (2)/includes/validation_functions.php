<?php

$errors = array();

$upload_errors =array(
	UPLOAD_ERR_OK			=> "No errors.",
	UPLOAD_ERR_INI_SIZE		=> "Larger than upload_max_filesize.",
	UPLOAD_ERR_FORM_SIZE	=> "Larger than form MAX_FILE_SIZE.",
	UPLOAD_ERR_PARTIAL		=> "Partial upload.",
	UPLOAD_ERR_NO_FILE		=> "No file.",
	UPLOAD_ERR_NO_TMP_DIR	=> "No temporary directory.",
	UPLOAD_ERR_CANT_WRITE	=> "Can't write to disk.",
	UPLOAD_ERR_EXTENSION	=> "File upload stopped by extension."
);

function validate_post_type() {
	if($_POST['post_type'] != "edu" && $_POST['post_type'] != "announce" && $_POST['post_type'] != "spirit") {
		$errors['post_type'] = "There was an error in the Post Type";
	}
}

function fieldname_as_text($fieldname) {
  $fieldname = str_replace("_", " ", $fieldname);
  $fieldname = ucfirst($fieldname);
  return $fieldname;
}

function has_presence($value) {
	return isset($value) && $value !== "";
}

function check_post_name() {
	global $errors;
	$topic = mysql_prep($_POST["post_name"]);
	$query = "SELECT * FROM posts WHERE topic = '{$topic}'";
	$result_set = query($query);
	if($post = fetch_assoc($result_set)) {
		$errors['post_name'] = "There is a Post  with this Name Please rename the post";
	}
}

function validate_photo($required_fields) {
	global $errors;
	global $upload_errors;
	if(!isset($_FILES)) {
		$errors['Files'] = "No file was Uploaded";
		return false;
	}
	foreach($required_fields as $field) {
		//Perform error checking on the form parameters
		if (!$_FILES[$field]['tmp_name'] || empty($_FILES[$field]['tmp_name']) || !is_array($_FILES[$field])) {
			$errors['Files'] = "No file was Uploaded";
			return false;
		} elseif($_FILES[$field]['error'] != 0) {
			//This is to report what PHP says went wrong
			$errors[$field] = $upload_errors[$_FILES[$field]['error']];
			return false;
		} elseif(!getimagesize($_FILES[$field]['tmp_name'])) {
			$errors[$field] = "The " . $field . " is Invalid";
			return false;
		} else {
			return true;
		}
	}
	return true;
}

function validate_file($required_fields) {
	global $errors;
	global $upload_errors;
	if(!isset($_FILES)) {
		$errors['Files'] = "No file was Uploadedaaa";
		return false;
	}
	foreach($required_fields as $field) {
		//Perform error checking on the form parameters
		if (!$_FILES[$field] || empty($_FILES[$field]) || !is_array($_FILES[$field])) {
			$errors['Files'] = "No file was Uploaded.bbb";
			return false;
		} elseif($_FILES[$field]['error'] != 0) {
			//This is to report what PHP says went wrong
			$errors[$field] = $upload_errors[$_FILES[$field]['error']];
			return false;
		} else {
			return true;
		}
	}
}

function confirm_level_course() {
	global $errors;
	if(!isset($_POST['courseid'])) {
		$errors['course'] = "The Course is Invalid";
		return false;
	}
	if(!isset($_POST['level'])) {
		$errors['level'] = "The Level is Invalid";
		return false;
	}
	
	$level = (int) $_POST['level'];
	$courseid = (int) mysql_prep($_POST['courseid']);
	$query = "SELECT * FROM courses WHERE id = {$courseid}";
	$result = query($query);
	if($result = mysqli_fetch_assoc($result)) {
		$years = (int) $result['years'];
		if($level > 0 && $level <= $years) {
			return true;
		} else {
			// $errors['level'] = "1: " . $level . " 2: " . $years;
			$errors['level'] = "The level is Invalid";
			return false;
		}
	} else {
		$errors['course'] = "The Course is Invalid";
		return false;
	}
}

function confirm_password() {
	global $errors;
	if(!isset($_POST['password']) && !isset($_POST['confirm-password'])) {
		$errors['passwords'] = "The Passwords do not match";
		return false;
	}
	$pass1 = $_POST['password'];
	$pass2 = $_POST['confirm-password'];
	if($pass1 === $pass2) {
		return true;
	} else {
		$errors['password'] = "Password is not the same";
		return false;
	}
}

function confirm_course_name($course_num) {
	global $errors;
	$num = mysql_prep($course_num);
	$query = "SELECT * FROM courses WHERE id = {$num}";
	$result = query($query);
	if($result = mysqli_fetch_assoc($result)) {
		return true;
	} else {
		$errors['coursename'] = "There was an error in the course name";
		return false;
	}
}

function validate_presences($required_fields) {
	global $errors;
	foreach($required_fields as $field) {
		if(!isset($_POST[$field])) {
			$errors[$field] = fieldname_as_text($field) . " is Invalid";
			continue;
		}
		$value = trim($_POST[$field]);
		if (!has_presence($value)) {
			$errors[$field] = fieldname_as_text($field) . " can't be blank";
		}
	}
}

// * string length
// max length
function has_max_length($value, $max) {
	return strlen($value) <= $max;
}
	
function validate_max_lengths($fields_with_max_lengths) {
	global $errors;
	// Expects an assoc. array
	foreach($fields_with_max_lengths as $field => $max) {
		if(!isset($_POST[$field])) {
			$errors[$field] = fieldname_as_text($field) . "is Invalid";
			continue;
		}
		$value = trim($_POST[$field]);
	  if (!has_max_length($value, $max)) {
	    $errors[$field] = fieldname_as_text($field) . " is too long";
	  }
	}
}

// * inclusion in a set
function has_inclusion_in($value, $set) {
	return in_array($value, $set);
}

?>
