<?php
function last_id() {
	global $connection;
	return mysqli_insert_id($connection);
}

function redirect_to($location = NULL) {
  if ($location != NULL) {
		header("Location: {$location}");
	exit;
  }
}

function query($query) {
	global $connection;
	$result = mysqli_query($connection, $query);
	confirm_query($result);
	return $result;
}

function confirm_query($result_set){
	if(!$result_set){
		die("Database query failed");
	}
}

function escape_value($string){
	global $connection;
	$escaped_string = mysqli_real_escape_string($connection, $string);
	return $escaped_string;
}

function mysql_prep($string){
	global $connection;
	$escaped_string = mysqli_real_escape_string($connection, $string);
	return $escaped_string;
}

function check_email_regex($email) {
	return true;
}

function fetch_array($result_set) {
	return mysqli_fetch_array($result_set);
}

function fetch_assoc($result_set) {
	return mysqli_fetch_assoc($result_set);
}

function is_ajax_request() {
	return isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
  $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest';
}

function val_admin_id($admin_id) {
	$id = (int) mysql_prep($admin_id);
	$query = "SELECT * FROM admins WHERE id = {$id}";
	$result_set = query($query);
	if($result = fetch_assoc($result_set)) {return $result;} else {return false;}
}

function load_my_messages($admin_id, $rank) {
	$escaped_id = (int) mysql_prep($admin_id);
	if($rank == 1) {
		//Leader
		$query = "SELECT * FROM messages WHERE recipient_id = {$escaped_id} OR recipient_id = -1 OR recipient_id = -2 ORDER by time DESC";
	} else {			
		$query = "SELECT * FROM messages WHERE recipient_id = {$escaped_id} OR recipient_id = -2 ORDER by time DESC";
	}
	$messages = query($query);
	$output = "";
	while($message = mysqli_fetch_assoc($messages)) {
		if($message['sender_id'] == $escaped_id) {continue;}
		$id = $message['id'];
		$time = strftime("%B %d, %Y at %I:%M %p", $message['time']);
		$name = val_admin_id($message['sender_id'])['first_name'];
		$output.= "<div class=\"message article\" id=\"mess-{$id}\" data-messId=\"{$id}\" data-context=\"rec\" onclick=\"showMessage('mess-{$id}')\">{$message['message']}<br>{$name}<br>{$time}</div>";
	}
	return $output;
}

function load_sent_messages($admin_id) {
	$id = (int) mysql_prep($admin_id);
	$query = "SELECT * FROM messages WHERE sender_id = {$id} ORDER by time DESC";
	$messages = query($query);
	$output = "";
	while($message = mysqli_fetch_assoc($messages)) {
		$id = $message['id'];
		$time = strftime("%B %d, %Y at %I:%M %p", $message['time']);
		$name = val_admin_id($message['recipient_id'])['first_name'];
		if($message['recipient_id'] == -1) {$name = "All Leaders";}
		if($message['recipient_id'] == -2) {$name = "All Workers";}
		$output.= "<div class=\"message article\" id=\"mess-{$id}\" data-messId=\"{$id}\" data-context=\"sent\" onclick=\"showMessage('mess-{$id}')\"> {$message['message']}<br>{$name}<br>{$time}</div>";
		// $output.= "<div class=\"message article\"> {$message['message']}<br>{$message['recipient_id']}<br>{$message['time']}</div>";
	}
	return $output;
}

function prod_image($image_id, $context) {
	$id = mysql_prep($image_id);
	$pic = fetch_assoc(query("SELECT * FROM pictures WHERE id={$id}"));
	$image = "<div id=\"image_{$id}\" class=\"images\" style=\"background: url(../post_pics/{$id}_postpic_large@2.png); background-size: cover;\">{$pic['name']}</div>";
	return $image;
}

function input_images($content) {
	$pat = "/\[\[content:image, source:([\\d]+), download:(.+?)\]\]/";
	
	while(preg_match($pat, $content, $mat)){
		$image = prod_image($mat[1], "div");
		$content = str_replace($mat[0], $image, $content);	
	}
	return $content;
}

function render_post_name($name) {
	$name = str_replace("\t", "", $name);
	$str_len = 20;
	return preg_replace("/ +/", "-", $name);
}

function generate_post($id) {
	$post = fetch_assoc(query("SELECT * FROM posts WHERE id={$id}"));
	$topic = $post['topic'];
	$type = $post['content_type'];
	$content = nl2br(input_images($post['content']));
	$script_url = SCRIPT_URL;
	require_once("../../includes/layouts/posts_layout.php");
	require_once('../../includes/initialize.php');
	return $layout;
}

function form_errors($errors=array()) {		
	$output = "";
	if (!empty($errors)) {
	  $output .= "<div class=\"error\">";
	  $output .= "Please fix the following errors:";
	  $output .= "<ul>";
	  foreach ($errors as $key => $error) {
		$output .= "<li>";
		$output .= htmlentities($error);
		$output .= "</li>";
	  }
	  $output .= "</ul>";
	  $output .= "</div>";
	}
	return $output;
}

function create_page($id, $post_name) {
	$name = '../posts/' . render_post_name($post_name) . '.php';
	$content = "<?php require_once('../../includes/initialize.php'); echo generate_post({$id}); ?>";
	// while(file_exists($name)) {
		
	// }
	if (file_put_contents($name, $content)) {
		return true;
	}
}

function generate_feat_image($content, $type) {
	$str = "";
	$pat = "/\[\[content:image, source:([\\d]+), download:(.+?)\]\]/";
	if(preg_match($pat, $content, $mat)) {
		return $mat[1];		
	} else {
		// return "../post_pics/{$type}_default.png";
		return false;
	}
}

function post_url($topic) {
	return POST_URL . render_post_name($topic) . '.php';
	// return '../posts/' . 
}

function validate_pending_admin($pend_email, $pend_rand) {
	$email = mysql_prep($pend_email);
	$rand = mysql_prep($pend_rand);
	$query = "SELECT * FROM pending_admins WHERE email='{$email}' AND rand='{$rand}'";
	$result_set = query($query);
	if($result = fetch_assoc($result_set)) {return $result;} else {return false;}
}

function send_rand($email) {
		return '12345';
}

function load_posts_thumb($admin_id, $context, $level, $edu_op, $per_page, $off) {
	$cont = mysql_prep($context);
// function load_posts_thumb($cont) {
	if($admin_id != NULL) {
		if(!val_admin_id($admin_id)) {
			exit;
		}
	}
	if($cont != 'all') {
		$query = "SELECT * FROM posts WHERE content_type='{$cont}' ORDER BY created DESC LIMIT {$per_page} OFFSET {$off}";
	} else {
		$query = "SELECT * FROM posts ORDER BY created DESC LIMIT {$per_page} OFFSET {$off}";
	}
	if($cont == 'edu' && $edu_op == 'sel') {
		$query = "SELECT * FROM posts WHERE content_type='{$cont}' AND content_level={$level} ORDER BY created DESC LIMIT {$per_page} OFFSET {$off}";
	}
	$posts = query($query);
	$extra = '';
	$finished = false;
	if(mysqli_num_rows($posts) < 1) {
		$finished = true;
	}
	if(mysqli_num_rows($posts) < $per_page) {
		$finished = true;
	}
	$string = "";
	$post_pic = POST_IMG;
	while($post = mysqli_fetch_assoc($posts)) {
		$pic_id = generate_feat_image($post['content'], $post['content_type']);
		$url = post_url($post['topic']);
		if(!$pic_id) {
			$url1 = "{$post_pic}{$post['content_type']}_default_small.png";
			$url2 = "{$post_pic}{$post['content_type']}_default_large.png";
		} else {
			$url1 = "{$post_pic}{$pic_id}_postpic_small.png";
			$url2 = "{$post_pic}{$pic_id}_postpic_large@2.png";
			// $url1 = "{$post_pic}{$pic_id}_postpic_1.png";
			// $url2 = "{$post_pic}{$pic_id}_postpic_2.png";
		}
				
		
		$style = "<style>@media screen and (min-width:1200px){#post_thumb_{$post['id']} {background: url({$url1});background-size: cover;}}@media screen and (max-width: 1199px){#post_thumb_{$post['id']} {background: url({$url2});background-size: cover;}}</style>";
		$string.= $style;
		$string.= "<div id =\"post_thumb_{$post['id']}\" class=\"article posts\" style=\"\">";
		$string.= "<a href=\"{$url}\" target=\"_blank\"><div style=\"overflow: hidden;\">";
		$string.= "<div class=\"caption\">{$post['topic']}wwkwlejhewlheihjaw</div></div></a>";
		if($admin_id != NULL) {
			$string.= "<a href=\"edit_post.php?id={$post['id']}\"><div class=\"edit-link\">Edit Post</div></a>";
		}
		$string.= "</div>";
	}	
	return ['finished' => $finished, 'message' => $string];
}

function full_name($first, $second) {return ucfirst($first) . " " . ucfirst($second);}

function course_name($course_id) {
	$id = mysql_prep($course_id);
	$query = "SELECT * FROM courses WHERE id = {$id}";
	$result = query($query);
	$course = fetch_assoc($result);
	return ['fullname' => $course['coursename'], 'shortname' => $course['shortname']];
}

function load_admins($id) {
	$admins = query("SELECT * FROM admins");
	$output = "";
	while($admin = fetch_assoc($admins)) {
		if($admin['id'] == $id){continue;}
		$url1 = ADMIN_IMG .  "{$admin['id']}_admin_prof_1.png";
		$url2 = ADMIN_IMG .  "{$admin['id']}_admin_prof_2.png";
		$full_name = full_name($admin['first_name'], $admin['last_name']);
		$course = course_name($admin['course'])['shortname'];
		$style = "<style>@media screen and (min-width:1200px){#admin_thumb_{$admin['id']} {background: url({$url1});background-size: cover;}}@media screen and (max-width: 1199px){#admin_thumb_{$admin['id']} {background: url({$url2});background-size: cover;}}</style>";
		$output.= $style;
		$output.= "<div id=\"admin_thumb_{$admin['id']}\" class=\"admin_thumb article\" onclick=\"loadAdmin({$admin['id']});\">";
		$output.= "<div class=\"admin-caption\">";
		$output.= "<p>&nbsp;&nbsp;{$full_name}</p>";
		$output.= "<p>&nbsp;&nbsp;{$course}</p>";
		$output.= "<p>&nbsp;&nbsp;{$admin['level']}00 level</p>";
		$output.="</div></div>";
	}
	return $output . $output . $output;
	// return $output;
}

function check_pending_admin($pending_email) {
	$email = mysql_prep($pending_email);
	$query = "SELECT * FROM pending_admins WHERE email = '{$email}'";
	$result_set = query($query);
	if($result = fetch_assoc($result_set)) {return $result;} else {return false;}
}

function val_admin_email($admin_email) {
	$email = mysql_prep($admin_email);
	$query = "SELECT * FROM admins WHERE email = '{$email}'";
	$result_set = query($query);
	if($result = fetch_assoc($result_set)) {return $result;} else {return false;}
}

function password_check($password, $existing_hash){
	//existing hash contains format and salt at start
	// $hash = crypt($password, $existing_hash);
	// if ($hash === $existing_hash){
		// return true;
	// } else {
		// return false;
	// }
	if($password == $existing_hash) {
		return true;
	} else {
		return false;
	}
}

function attempt_login($email, $password) {
	if($admin = val_admin_email($email)){
		if(password_check($password, $admin['hashed_password'])) {
			return $admin;
		} else {
			return false;
		}
	} else {
		return false;
	}
}
	
function password_encrypt($password){
	// $hash_format = "$2y$10$";// tells php to use blowfish with a cost of 10
	// $salt_length = 22;//Blowfish salts should be 22 charac or more
	// $salt = generate_salt($salt_length);
	// $format_and_salt = $hash_format . $salt;
	// $hash = crypt($password, $format_and_salt);
	// return $hash;
	return $password;
}

function generate_salt($length){
	//not 100% unique, not random, but good enough for a salt
	//MD5 returns 32 Characters
	$unique_random_string = md5(uniqid(mt_rand(), true));
	
	//Valid characters for a salt are [a-zA=Z0-9./]
	$base64_string = base64_encode($unique_random_string);
	
	//But not '+' which is valid in base64 encoding
	$modified_base64_string = str_replace('+', '.', $base64_string);
	
	//Truncate string to the correct length
	$salt = substr($modified_base64_string, 0, $length);
	
	return $salt;
}

function move_pic($old_path, $new_path) {
	if(move_uploaded_file($old_path, $new_path)) {
		$imagecreate = "imagecreatefrom"  . str_replace('image/', '', getimagesize($new_path)['mime']);
		$resource = $imagecreate($new_path);
		$sizes = [
			'1' => 150,
			'2' => 250,
			'3' => 400,
			'4' => 600,
			'5' => 750
		];
		foreach ($sizes as $name => $size) {
			$scaled = imagescale($resource, $size);
			imagepng($scaled, $new_path . '_' . $name . '.png', 9);
			imagedestroy($scaled);
		}
		unlink($new_path);
		return true;
	}
}

function load_all_pictures($per_page, $off) {
	$query = "SELECT * FROM pictures ORDER BY time DESC LIMIT {$per_page} OFFSET {$off}";
	$pictures = query($query);
	$finished = false;
	if(mysqli_num_rows($pictures) < 1) {
		$finished = true;
	}
	if(mysqli_num_rows($pictures) < $per_page) {
		$finished = true;
	}
	$output = "";
	while($pic = fetch_assoc($pictures)) {
		$url = POST_IMG . "{$pic['id']}_postpic_1.png";
		$output.= "<div class=\"pictures\" data-name=\"{$pic['name']}\" data-id=\"{$pic['id']}\" id=\"pic_{$pic['id']}\" style=\"background: url({$url}), url(spinner.gif); background-size: cover;\" onclick=\"picClick('pic_{$pic['id']}')\"></div>";
	}
	// return $output;
	return ['finished' => $finished, 'pictures' => $output];

}

function listed_admins($id) {
	$admins = query("SELECT * FROM admins");
	$output = "";
	while($admin = fetch_assoc($admins)) {
		if($admin['id'] == $id){continue;}
		$output.= "<div class=\"admin-container\">";
		$output.= "<div class=\"radio-cover\"><input type=\"radio\" name=\"admin_id\" class=\"radio\" value=\"{$admin['id']}\"></div>";
		$output.= "<label for=\"id\" class=\"admin-name\" style=\"\" >{$admin['first_name']}</label>";
		$output.="<div class=\"admin-pic\" style=\"\" ></div>";
		$output.="</div>";
	}
	return $output;
}

function check_pic_name($pic_name) {
	$name = mysql_prep($pic_name);
	if(fetch_assoc(query("SELECT * FROM pictures WHERE name='{$name}'"))) {
		return true;
	} else {
		return false;
	}
}
?>