<?php
$text = "Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that";
$layout = <<<EOT
<!DOCTYPE html PULIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html lang = "en">
	<head>
		<meta charset="UTF-8">
	   
		<meta name="viewport" content="width=device-width, initial-scale = 1.0">
		<link rel="stylesheet" href="../stylesheets/post.css">
		<link rel="stylesheet" href="../stylesheets/jquery.mCustomScrollbar.min.css">
		<title></title>
		<style>
		</style>
	</head>
	<body>
		<section id="window">
		<div id="reading" style="margin:0 auto;position:fixed;color:white;text-align:center; padding: 0px;content-align: center; z-index: 10; width: 100%;">W:<span id="w"></span>px &nbsp;H:<span id="h"></span>px<span id="click">Click</span></div>
		<header id="header">
		<div id="logos">
		<div id="logo1"></div> <div id="logo2"></div><h1 style="float: left;margin: 0px; font-size: 2rem;color: rgb(200,200,200); line-height: 6rem;">DLCF Fupre Official</h1>
		</div>
		</header>
		<section id="main">
			<section id="post-section">
				<section id="post-section-scroll" data-mcs-theme="dark-thick">
				<div id="post-content" style = "">
					<h1 id="topic">{$topic}</h1>
					<div id="content">{$content}<br><br><br> {$text}</div><br>
					<div id="">
						{$type} Posts:<br>
						Post Created By John Doe<br>
						Created On the 5th of November 1995<br>
						Updated on 20th of December 2090
					</div>
				</div>
				
				<div id="comments">
					<div id="comments-div">
						<div id="load-before"></div>
						<button id="load-comm-button" class="load-comm-button" data-page="0" data-postId="5">Load  Comments</button><br>
					</div>
					Comment as:<br>
					<select id="comment-select">
						<option value="name1">FaceBook Account</option>
						<option value="name2">Google Plus Account</option>
						<option value="name3">Twitter Account</option>
						<option value="name">Type Name</option>
					</select><br>
						<input type = "text" name = "post_name" id="sender-name" placeholder="Type Your Name" /><br>
					<div style="max-height: 300px; max-width: 300px; resize: none;"><textarea name="content" style="background:inherit; font-size: 1rem;"></textarea></div><br>
					<button id="comm-submit">Post Comment</button>			
				</div>
					<section id="posts" class="thumbnail-cover hor-scroll" data-mcs-theme="rounded-dots-dark">
					<div class="article posts load" id="loadall">
						<div class="load-button" id="buttonall">
						<div id="all" class="load-click" data-page="0">Load More...</div>
						</div>
						<div id="spinall" class="load-spin" style="display: none"></div>
					</div>
					</section>
				
				</section>
			</section>
		
			<section id="advert" style="">
				<div id="church-desc" style=""> 
					Worship With us At Deeper Life Campus FellowShip In any Of This Days:<br>
					Sunday Worship Service: 7am<br>
					Monday Bible Study: 5pm<br>
					Thursday Revival Service: 5pm<br>
					At any of  the below locations:
					
				</div>
				<div id="locations"class="hor-scroll">
				
					<div class="location-div hor-article">
						<div class="location-pics"></div>
						<div class="location-desc">
						<p style="margin:0; word-wrap: break-word;">This  Is Just Some random text</p>
						</div>
					</div>
					
					<div class="location-div hor-article">
						<div class="location-pics"></div>
						<div class="location-desc">
						<p style="margin:0; word-wrap: break-word;">This  Is Just Some random text</p>
						</div>
					</div>
					
				</div>
			</section>
			</section>
		<footer>
			All Rights Reserved DLCF FUPRE 2017 
		</footer>
		
		</section>
		
		
	
	
	<script src="{$script_url}jquery.js"></script>
	<script src="{$script_url}jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="{$script_url}post.js"></script>
	<script src="{$script_url}custom_scroll.jsa"></script>
	<script>
	
	
	$(document).ready(function () {
		height = document.getElementsByClassName('height');
		for (var i = 0; i < height.length; i++) {
			height[i].style.height = window.innerHeight;
		}
		
		// windowHeight = $(window).innerHeight();
		// $('.height').css('height', windowHeight);
		document.getElementById("w").innerHTML = window.innerWidth;
		document.getElementById("h").innerHTML = window.innerHeight;
			$("#post-sectiond").mCustomScrollbar({
				scrollButtons:{enable:true},
				theme:"dark-thick",
				scrollbarPosition:"inside"
			});
	});

	var post = document.getElementById('post-section');
	var postw = post.innerWidth;
    $('#click').click(function (){
		// alert('working');
		alert("Height is " + postw);
	});
	$(window).resize(function() {
		height = document.getElementsByClassName('height');
		for (var i = 0; i < height.length; i++) {
			height[i].style.height = window.innerHeight;
		}
		
		// windowHeight = $(window).innerHeight();
		// $('.height').css('height', windowHeight);
		document.getElementById("w").innerHTML = window.innerWidth;
		document.getElementById("h").innerHTML = window.innerHeight;
		// document.getElementById("reading").style.marginLeft = (window.innerWidth/2) - 12;
		// windowHeight = $(window).innerHeight();
		// $('.height').css('height', windowHeight);
		// width = window.innerWidth;
		// height = window.innerHeight;
		// var w = document.getElementById("w");
		// w.innerHTML = width;
		// var h = document.getElementById("h");
		// h.innerHTML = height;
	});
	</script>
	
	</body>
	
EOT;
?>