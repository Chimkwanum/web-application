<?php
require_once("../includes/functions.php");
sleep(4);
if(isset($_GET['login'])){	
if(!is_ajax_request()) { exit; }
}

$login_cont = <<<EOT
<style>
.login-input{
	border-width: 2px;
	border-color: black;
	padding: 5px;
	margin-bottom: 10px;
	border-radius: 5px;
	line-height: 2rem;
	font-family: inherit;
	font-size: 1rem;
	background: rgb(20,20,20);
	color: white;
	width: 15rem;
}
.login-input:focus{
	background: white;
	color: rgb(20,20,20);
}
#login_button:focus{
	background: orange;	
	color: rgb(20,20,20);
}
#login-form{
	font-family: cursive,fantasy;			
}
#login_button{
	width: 5rem;
	text-align: left;
	color: orange;
}
#login_button:hover{
	color: indigo;
	cursor: pointer;
}
</style>


<section id="form-div"style="margin: 0 auto; width: 40%; margin-top: 2rem; align-content: center;text-align: left;display:none;">
<span style="font-size: 1rem; font-family: cursive,fantasy; font-weight: bold; color: black;">Login:</span> <br />
<form action= "" method = "post" id="login-form">	
<input type = "email" name = "email" value = "" class="login-input" placeholder="Email" id="confirm-password"/><br />
<input type = "password" name = "password" value = "" class="login-input" placeholder="Password" id="password"/><br />
<button name="submit" style="margin-bottom: 0px;"type = "submit" id="login_button" class="login-input submit">Proceed</button><br>
<button style="text-align: right; margin-top: 0px; background: black; color: red; border-radius: .2rem; border-color: black;" onclick="closePopup();">Close</button>
</form>
<div id="login-error"></div>
</section>

EOT;

$login_script = <<<EOT
var site;
function redirect() {
	window.location.replace(site);
}
setTimeout(slideDown, 1000);
function slideDown() {		
	$("#form-div").slideDown(1000);
}
document.getElementById("login-form").onsubmit = function() {
	var button = document.getElementById("login_button");
	button.innerHTML= "Loading...";
	button.disabled = true;
	// alert("test");
	var form = document.getElementById("login-form");
	var form_data = new FormData(form);
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}
	var url = 'validate_login.php';
	var xhr = new XMLHttpRequest();
	xhr.open('POST', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var error_div = document.getElementById("login-error");
			// button.disabled = true;
			var json = JSON.parse(xhr.responseText);
			if(json.success == true) {
				error_div.style.color = "green";
				error_div.innerHTML=json.message;
				site = json.location;
				setTimeout(redirect, 2000);
			} else {
				error_div.style.color = "red";
				error_div.innerHTML = json.message;

			}
			button.disabled = false;
			button.innerHTML= "Proceed";

		}
	}
	xhr.send(form_data);	
	return false;
}

EOT;
if(isset($_GET['login'])){	
	$string = ['message' => $login_cont, 'script' => $login_script];
	$return_array = ['success' => true, 'message' => $string];
	echo json_encode($return_array);
	exit;
}
?>




<?php



?>
<!DOCTYPE HTML>	
<html>
	<head>
		<meta charset="UTF-8">
        <title>Some</title>
		<meta name="viewport" content="width=device-width, initial-scale = 1.0">
		<style>
		.login-input{
			border-width: 2px;
			border-color: black;
			padding: 5px;
			margin-bottom: 10px;
			border-radius: 5px;
			line-height: 2rem;
			font-family: inherit;
			font-size: 1rem;
			color: white;
			width: 15rem;
			background: rgb(20,20,20);
		}
		.login-input:focus{
			background: white;
			color: rgb(20,20,20);
		}
		#login_button:focus{
			background: orange;	
			color: rgb(20,20,20);
		}
		#login-form{
			font-family: cursive,fantasy;			
		}
		#login_button{
			width: 5rem;
			text-align: left;
			color: orange;
		}
		#login_button:hover{
			color: indigo;
			cursor: pointer;
		}
		#logo1{
			display: inline-block;
			height: 40px;
			width: 40px;
			background: url(images/logo1.png);
			background-size: cover;
		}
		#logo2{
			height: 40px;
			width: 40px;
			display: inline-block;
			margin-left: 1rem;
			background: url(images/logo2.png);
			background-size: cover;
		}
		</style>
	</head>
	<body>
	
		<section id="form-div"style="margin: 0 auto; width: 15rem; align-content: center;">
		<div style="width: 100%;  height: 50px;">
			<div id="logo1"></div> <div id="logo2"></div>
			<div style="display: inline-block; height: 50px; line-height: 50px; overflow: hidden; font-family: cursive,fantasy; font-weight: bold;"> &nbsp;DLCF FUPRE</div>
		</div>
		<span style="font-size: 1rem; font-family: cursive,fantasy; font-weight: bold;">Login:</span> <br />
		<form action= "" method = "post" id="login-form">	
		<input type = "email" name = "email" value = "" class="login-input" placeholder="Email" id="confirm-password"/><br />
		<input type = "password" name = "password" value = "" class="login-input" placeholder="Password" id="password"/><br />
		<!--<input type = "submit" name = "submit" id="login_button" value = "Proceed" class="login-input submit"/><br />-->
		<button name="submit" style="margin-bottom: 0px; display: block;"type = "submit" id="login_button" class="login-input submit">Sign in</button><br>
		</form>
		<div id="error"></div>
		</section>
		<script>
		var site;
		function redirect() {
			// window.location.href = site;
			window.location.replace(site);
		}
		document.getElementById("login-form").onsubmit = function() {
			var button = document.getElementById("login_button");
			button.innerHTML= "Loading...";
			button.disabled = true;
			// alert("test");
			var form = document.getElementById("login-form");
			var form_data = new FormData(form);
			for ([key, value] of form_data.entries()) {
			  console.log(key + ': ' + value);
			}
			var url = 'validate_login.php';
			var xhr = new XMLHttpRequest();
			xhr.open('POST', url, true);
			xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
			xhr.onreadystatechange = function () {
				if(xhr.readyState == 4 && xhr.status == 200) {
					console.log(xhr.responseText);
					var error_div = document.getElementById("error");
					// button.disabled = true;
					var json = JSON.parse(xhr.responseText);
					if(json.success = true) {
						error_div.style.color = "green";
						error_div.innerHTML=json.message;
						site = json.location;
						setTimeout(redirect, 2000);
					} else {
						error_div.style.color = "red";
						error_div.innerHTML = json.message;

					}
					button.disabled = false;
					button.innerHTML= "Proceed";

				}
			}
			xhr.send(form_data);	
			return false;
		}
		</script>
	
	</body>
</html>

