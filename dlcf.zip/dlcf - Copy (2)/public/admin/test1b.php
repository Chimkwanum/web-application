<?php $max_file_size = 10000000000000; ?>
<!DOCTYPE html PULIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
	
<html lang = "en">
	<head>		
		<meta charset="UTF-8">
	   
		<meta name="viewport" content="width=device=width, initial-scale = 1.0">
		<link rel="stylesheet" href="main.css">
		<title></title>
	</head>
	<body>
	<div id="pic" style="height: 100px; width:100px;"></div>
	<form action= "<?php echo $_SERVER['PHP_SELF'];?>" method = "post" enctype="multipart/form-data" id="form">
	
	<input type = "hidden" name = "MAX_FILE_SIZE" value = "<?php echo $max_file_size; ?>"/><br>
	<input type = "file" name = "profile-pic" /><br>
	<!--<input class="submit" type="submit" name="submit" id="validate-new-admin" value="Upload photo"/><br />-->
	<button  id = "submit" class="submit" value = "" onclick= "return false";> Proceed</button>
	<br /><br /><br />
	<div id="debug"></div>
	</form>

<script src="../javascripts/jquery.js"></script>
<script>
$("#submit").click(function () {
alert("submitted");
var form = document.getElementById("form");
var action = "test1.php";
var picdiv = document.getElementById("pic");
picdiv.style.background = "url(spinner.gif)";
picdiv.style.backgroundSize = "cover";
// gather form data
var form_data = new FormData(form);
// console.log("processing");
for ([key, value] of form_data.entries()) {
  console.log(key + ': ' + value);
}

var xhr = new XMLHttpRequest();
xhr.open('POST', action, true);

xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
xhr.onreadystatechange = function () {
	if(xhr.readyState == 4 && xhr.status == 200) {
		picdiv.style.background = "url(picture)";
		picdiv.style.backgroundSize = "cover";
		console.log('Result: ' + xhr.responseText);
		var debugdiv = document.getElementById("debug");
		// var result = "\"" + xhr.responseText + "\"";
		debugdiv.innerHTML = xhr.responseText;
		// var json = JSON.parse(xhr.responseText);
		// if (json.success == true) {
			// displayPopUpMessage(json.message);
		// } else {
			// displayError(json.error);
		// }
		
	}
}
xhr.send(form_data);
});

</script>
	</body>
</html>
