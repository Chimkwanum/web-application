<?php
	require_once("../../includes/db_connection.php");
	function fetch_assoc($result_set) {
		return mysqli_fetch_assoc($result_set);
	}

	
	function query($query) {
		global $connection;
		$result = mysqli_query($connection, $query);
		confirm_query($result);
		return $result;
	}

	function confirm_query($result_set){
		if(!$result_set){
			die("Database query failed");
		}
	}

	$query = "select * from admins where id=500";
	$results = query($query);
	print_r($results);
	if($result = fetch_assoc($results)) {
		echo "true";
	} else {echo "false";}
	
	while($result = fetch_assoc($results)){
		print_r($result);
	}
	
	$query = "insert into messages (message, sender_id, recipient_id, time) values ('some message', 1, 1, 223333)";
?>