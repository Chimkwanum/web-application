<?php
$test = "	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you";
?>
<!DOCTYPE html PULIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
	
<html lang = "en">
	<head>		
		<meta charset="UTF-8">
	   
		<meta name="viewport" content="width=device=width, initial-scale = 1.0">
		<link rel="stylesheet" href="main.css">
		<link rel="stylesheet" href="../stylesheets/jquery.mCustomScrollbar.min.css">

		<title></title>
		<style>
			#mess_main{
				height: 300px;
				width: 350px;
				margin: 0 auto;
				display: none;
			}
			#mess_message{
				height: 90%;
				max-height: 90%;
				border-radius: .5rem .5rem 0 0;
				background: linear-gradient(rgba(100,100,100,.7), rgba(100,100,100,.7)), url(../images/pic13.jpg);
				background-size: cover;
				color: white;
				padding: 1rem;
				overflow: auto;
			}
			#mess_from {
				background: rgb(90,90,50);
				height: 10%;
				padding: 1rem;
				padding-top: 0;
				margin-top: 0;
				color: white;
				border-radius: 0 0 .5rem .5rem;
			}
			.mess_att{
				color: black;
				font-weight: bold;
			}
		
		</style>
	</head>
	<body>
	<div id="mess_main" style="background: linear-gradient(rgba(100,100,100,.7), rgba(100,100,100,.7)), url(../images/pic13.jpg);">
	<div id="mess_message" data-mcs-theme="dark-thick">
			<?php echo $test . $test . $test; ?>
	</div>
	<div id="mess_from">
		<span class="mess_att">From:</span> Okerefe Umukoro<br>
		<span class="mess_att">Time:</span> 25th Dec 2014. 05:30 pm.
	</div>
	
	</div>
	<script src="../javascripts/jquery.js"></script>
	<script src="../javascripts/jquery.mCustomScrollbar.concat.min.js"></script>
	<script>
	
	setTimeout(slideDown, 1000);
	$("#message").mCustomScrollbar({
		scrollButtons:{enable:true},
		theme:"dark-thick",
		scrollbarPosition:"inside"
	});
	function slideDown() {		
		$("#mess_main").slideDown(500);
	}

	</script>
	</body>
	
	</html>