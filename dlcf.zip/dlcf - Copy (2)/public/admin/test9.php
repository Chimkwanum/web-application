<!DOCTYPE HTML>	
<html>
	<head>
		<meta charset="UTF-8">
        <title>Test9</title>
		<meta name="viewport" content="width=device-width, initial-scale = 1.0">
		<link rel="stylesheet" href="../stylesheets/jquery.mCustomScrollbar.min.css">
		<link rel="stylesheet" href="stylesheets/main.css">
    <style>
	
		.section {
			white-space: nowrap;
			overflow: auto;
			display: inline-block;
			height: 200px;
		}

	.article{
		height: 100px;
		width: 100px;
		background: purple;
		display: inline-block;
	}
	#section{
		width: 500px;
		overflow: auto;
	}
	
	</style>
	</head>
	<body>
	<section id="popup" style="">
	<div style="height:100px; width: 100px; background: url(spinner.gif); background-size:cover;">
	</div>
	<div style="width: 100px;">&nbsp;&nbsp;&nbsp;Loading....</div>
	</section>
	
	
	
	<br><br><br><br><br><br><br><br>
	<div class="article" style="justify-content: center; align-items: center;">
	Hello there
	<span>Some Items</span>
	</div>
<br><br><br><br><br>
	
	
	
	
	
	
	<section id="section">
	<div class="section">
		
	<div class="article">
		<div class="article"></div>
	</div>
	<div class="article"></div>
	<div class="article"></div>
	<div class="article"></div>
	<div class="article"></div>
	<div class="article"></div>
	
	</div>
	
	</section>
		<!--<script src="../javascripts/jquery.js"></script>
		<script src="../javascripts/jquery.mCustomScrollbar.concat.min.js"></script>-->
	
	<script>
	$(window).on("load",function(){
		var amount=200;
		$(".section").mCustomScrollbar({
			axis:"x",
			//theme:"rounded-dots-dark",
			//theme:"3d-thick",
			advanced:{
				autoExpandHorizontalScroll:true
			},
				autoHideScrollbar: false,
			scrollButtons:{
				enable:true,
				scrollType:"stepped"
			},
			keyboard:{scrollType:"stepped"},
			snapAmount:amount,
			mouseWheel:{scrollAmount:amount}
		});
	});
	</script>
	
	</body>
	
</html>



<div id ="" class="article posts" style="">
<a href="" target="_blank">
<div style="overflow: hidden;">	
<div class="caption\"></div>
</div>
</a>
</div>


























