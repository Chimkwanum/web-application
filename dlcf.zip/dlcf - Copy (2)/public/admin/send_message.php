<?php
require_once('../../includes/session.php'); 
require_once('../../includes/db_connection.php');
require_once('../../includes/functions.php');
if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

// sleep(3);

if(!is_ajax_request()) { exit; }


require_once('../../includes/validation_functions.php');
if (!isset($_POST['message']) || !isset($_POST['receiver'])){
	$return_array = ['success' => false, 'error' => "The transaction cant be done from 1"];
	echo json_encode($return_array);
	exit;// goback
}

$required_fields = array("message", "receiver");
// $user_id = $session->$user_id;
validate_presences($required_fields);
	
$fields_with_max_lenghts = array("message" => 300);
validate_max_lengths($fields_with_max_lenghts);
// process the form

if(!empty($errors)) {
	$return_array = ['success' => false, 'error' => "The transaction cant be done from errors hey"];
	echo json_encode($return_array);
	exit;// goback
}
$message = mysql_prep($_POST['message']);
$id = (int) mysql_prep($_POST['receiver']);

if($id === -1 || $id === -2 || $id === -3) {
} else {
	$return_array = ['success' => false, 'error' => "The transaction cant be done from 1"];
	echo json_encode($return_array);
	exit;// goback
}
$time = (int) time();
if($id === -3) {
	if (!isset($_POST['admin_id'])){
		$return_array = ['success' => false, 'error' => "The transaction cant be done from id"];
		echo json_encode($return_array);
		exit;// goback
	}
	 // Every body
	if(!val_admin_id($_POST['admin_id'])) {
		$return_array = ['success' => false, 'error' => "The transaction cant be done from id"];
		echo json_encode($return_array);
		exit;// goback
	}
	$id = (int) mysql_prep($_POST['admin_id']);
	$query = "INSERT INTO messages (message, recipient_id, sender_id, time) VALUES (";
	$query.= "'{$message}', {$id}, {$session->user_id}, {$time})";
	$result = query($query);
	if($result) {
		$return_array = ['success' => true, 'message' => "Your message has been sent successfully"];
		echo json_encode($return_array);
		exit;// goback
	} else {exit;}
	// $query = "INSERT INTO message_log (admins_id, message_id) VALUES ({$session->user_id}, {$message_id}");
	
} else {
	$query = "INSERT INTO messages (message, recipient_id, sender_id, time) VALUES (";
	$query.= "'{$message}', {$id}, {$session->user_id}, {$time})";
	$result = query($query);
	if($result) {
		$return_array = ['success' => true, 'message' => "Your message has been sent successfully"];
		echo json_encode($return_array);
		exit;// goback
	} else {exit;}
	// $query = "INSERT INTO message_log (admins_id, message_id) VALUES ({$session->user_id}, {$message_id}");
	
}
?>