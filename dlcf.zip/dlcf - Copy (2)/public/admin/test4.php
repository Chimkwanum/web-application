<!DOCTYPE html PULIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
	
<html lang = "en">
	<head>		
		<meta charset="UTF-8">
	   
		<meta name="viewport" content="width=device=width, initial-scale = 1.0">
		<link rel="stylesheet" href="main.css">
		<title></title>
		<style>
		


		#test{
			height: 400px;
			width: 400px;
			background: url(../images/pic10.jpg);
			background-size: cover;
		}
		@media screen and (max-width: 1199px){
			#test{
				background: url(../images/pic11.jpg);
				background-size: cover;
			}
		}
		
		@media screen and (min-width:1200px){
			#test{
				background: url(../images/pic10.jpg);
				background-size: cover;
			}
		
		}
		</style>
	</head>
	<body>
	
	<div id ='test' style="
	background: url(../images/pic10.jpg);
	background-size: cover;
	@media screen and (max-width: 1199px){
		background: url(../images/pic11.jpg);
		background-size: cover;
	}
	"></div>
	</body>
</html>