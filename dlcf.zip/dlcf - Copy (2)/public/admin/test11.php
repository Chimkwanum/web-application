<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Next Steps</title>
<link href="styles.css" rel="stylesheet" type="text/css">
</head>
<body>
<main role="main">
    <aside role="complementary" class="languages">
    <h3>Core Languages</h3>
     <div id="tabContainer">
    <div id="tabs">
      <ul>
        <li id="tab1"><a href="#tabPanel1">HTML</a></li>
        <li id="tab2"><a href="#tabPanel2">CSS</a></li>
        <li id="tab3"><a href="#tabPanel3">Javascript</a></li>
      </ul>
    </div>
    <div id="containers">
      <div id="tabPanel1">
        <h4>HTML</h4>
        <p><strong>Hypertext Markup Language.</strong> Controls the structure and semantics of web pages. Tags are used to mark up elements and denote content type. Although HTML does contain some presentational elements, it consists primarily of logical tags that identify content or provide information on content hierarchy.</p>
      </div>
      <div id="tabPanel2">
        <h4>CSS</h4>
        <p><strong>Cascading Style Sheets.</strong> Controls the visual presentation of page elements. It is responsible for page layout, color, typography, and element dimensions. Recent additions to CSS have included transforms and animations, which have greatly expanded the capabilities of CSS and the effects that can be controlled through it.</p>
        
      </div>
      <div id="tabPanel3">
        <h4>Javascript</h4>
		<div>
        <p><strong>JavaScript.</strong> Controls the behavior of page elements and is used to create interactive widgets, facilitate user 
	 <p>Over the years many Javascript frameworks and libraries have been developed to extend the capabilities of Javascript and make it faster to write. The success of libraries like jQuery have led to an explosion of Javascript development and have solidified it as the <i>de facto</i> scripting language for the web.</p>
		  </div>
    </div>
  </div>
    </aside>
   
<script>
//tabbed panels

// declare globals to hold all the links and all the panel elements
var tabLinks;
var tabPanels;

window.onload=function() {
    
    // when the page loads, grab the li elements
    tabLinks = document.getElementById("tabs").getElementsByTagName("li");
	// Now get all the tab panel container divs
	tabPanels = document.getElementById("containers").getElementsByTagName("div");

    // activate the _first_ one
    displayPanel(tabLinks[0]);

    // attach event listener to links using onclick and onfocus, fire the displayPanel function, return false to disable the link
    for (var i = 0; i < tabLinks.length; i++) {
        tabLinks[i].onclick = function() { 
			displayPanel(this); 
			return false;
		}
        tabLinks[i].onfocus = function() { 
			displayPanel(this); 
			return false;
		}
    }
}

function displayPanel(tabToActivate) {
    // go through all the <li> elements
    for (var i = 0; i < tabLinks.length; i++) {
        if (tabLinks[i] == tabToActivate) {
			// if it's the one to activate, change its class
            tabLinks[i].classList.add("active");
			// and display the corresponding panel
			tabPanels[i].style.display = "block";
        } else {
			// remove the active class on the link
        	tabLinks[i].classList.remove("active");
			// hide the panel
			tabPanels[i].style.display = "none";
        }
	}
}
</script>

</body>
</html>
