<?php $text = "Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that";
?>
<!DOCTYPE html PULIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html lang = "en">
	<head>
		<meta charset="UTF-8">
	   
		<meta name="viewport" content="width=device-width, initial-scale = 1.0">
		<link rel="stylesheet" href="../stylesheets/post.css">
		<title></title>
		<style>
			#post-section {
			}
			#advert{
			}
			h1{
				margin: 0px;
			}
			#topic{
				padding: 1rem;
				text-align: center;
			}
			#main{
				margin: 0px;
			}
			header{
				margin: 0px;
			}
			#logos{
				height:100px;
			}
			#window{
				margin: 0px;
			}
		</style>
	</head>
	<body>
	<section id="window" class="heigh" style="overflow: hidde;">
	<div id="reading" style="margin:0 auto;position:fixed;color:red;text-align:center; padding: 0px;content-align: center; z-index: 10; width: 100%;">W:<span id="w"></span>px &nbsp;H:<span id="h"></span>px<span id="click">Click</span></div>
	<header id="header">
	<div id="logos">
	<div id="logo1"></div> Hello There<div id="logo2"></div>
	</div>
	</header>
	<section id="main">
		<section id="post-section">
			<div id="inner" style = "background: green; padding: 1rem; font-size: 1.5rem; align-content:center;text-align:left;">
				<h1 id="topic">This Is Going to be the Header of the post</h1>
				<div> <?php echo $text.$text.$text.$text;?> </div>
			</div>
		</section>
		
		<section id="advert" style = "font-size: 1.5rem; align-content: center;text-align: left; overflow: auto;">
			<p> <?php echo $text; ?> </p>

		</section>
	</section>
	</section>


	<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
	<script src="../javascripts/jquery.js"></script>
	<script src="../javascripts/jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="../javascripts/post.js"></script>
	<script src="../javascripts/custom_scroll.jsa"></script>
	<script>
	$(document).ready(function () {
		height = document.getElementsByClassName('height');
		for (var i = 0; i < height.length; i++) {
			height[i].style.height = window.innerHeight;
		}
		
		// windowHeight = $(window).innerHeight();
		// $('.height').css('height', windowHeight);
		document.getElementById("w").innerHTML = window.innerWidth;
		document.getElementById("h").innerHTML = window.innerHeight;
	
	});
	var post = document.getElementById('post-section');
	var postw = post.innerWidth;
    $('#click').click(function (){
		// alert('working');
		alert("Height is " + postw);
	});
	$(window).resize(function() {
		height = document.getElementsByClassName('height');
		for (var i = 0; i < height.length; i++) {
			height[i].style.height = window.innerHeight;
		}
		
		// windowHeight = $(window).innerHeight();
		// $('.height').css('height', windowHeight);
		document.getElementById("w").innerHTML = window.innerWidth;
		document.getElementById("h").innerHTML = window.innerHeight;
		// document.getElementById("reading").style.marginLeft = (window.innerWidth/2) - 12;
		// windowHeight = $(window).innerHeight();
		// $('.height').css('height', windowHeight);
		// width = window.innerWidth;
		// height = window.innerHeight;
		// var w = document.getElementById("w");
		// w.innerHTML = width;
		// var h = document.getElementById("h");
		// h.innerHTML = height;
	});
	</script>
	
	</body>
</html>
