<?php $test = "	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you";?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Next Steps</title>
<link rel="stylesheet" href="../stylesheets/jquery.mCustomScrollbar.min.css">
<style>
	.mess-attr{		
		color: black;
		font-weight: bold;
	}
</style>
</head>
<body>
	<div style="height: 27.8rem; width: 27.5rem; border-radius: .5rem;margin: 0 auto; background: linear-gradient(rgba(40,40,40,.6), rgba(100,100,100,.6)), url(../images/pic17.jpg); background-size: cover;">
	
	<div style="width: 100%; padding-top: 13.75rem;">
		<div style="height: 12.5rem; color: white; border-bottom-right-radius: .5rem;  border-bottom-left-radius: .5rem; padding: .625rem;" padding:>
		<span class="mess-attr">Name:</span> Umukoro Okerefe<br>
		<span class="mess-attr">Department:</span> Mechanical Engineering<br>
		<span class="mess-attr">Level:</span> 400 Level<br>
		<span class="mess-attr">About Me:</span><br>
		<div id="about-admin"  style="overflow: auto; height: 7.5rem; padding-left:.4rem; padding-right: .4rem;" data-mcs-theme="dark-thick">
		<?php echo $test; ?>
		</div>
		</div>
	</div>
	</div>

	<!--<div id ="" class="article posts" style="">
	<a href="{$url}" target="_blank">
	<div>
	<div class="caption"></div>
	</div></a>
	</div>-->
<script src="../javascripts/jquery.js"></script>
<script src="../javascripts/jquery.mCustomScrollbar.concat.min.js"></script>
<script>
$("#about-admin").mCustomScrollbar({
	scrollButtons:{enable:true},
	theme:"dark-thick",
	scrollbarPosition:"inside"
});
</script>
	

</body>

</html>
