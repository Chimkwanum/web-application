<?php
require_once('../../includes/initialize.php');


// if (!$session->is_logged_in()) { redirect_to('../login.php');}

if(!is_ajax_request()) { exit;}

if(!isset($_GET['id'])) {
	exit;
}

if(!$admin = val_admin_id($_GET['id'])) {exit;}

$id = $admin['id'];

$url1 = ADMIN_IMG . "{$id}_admin_prof_3.png";
$url2 = ADMIN_IMG . "{$id}_admin_prof_4.png";
sleep(3);
$test = "	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you";
 
 
$string_con = <<<EOT
	<style>@media screen and (min-width:1200px){#admin-main {background: linear-gradient(rgba(40,40,40,.6), rgba(100,100,100,.6)), url({$url1}); background-size: cover;}}@media screen and (max-width: 1199px){#admin-main {background: linear-gradient(rgba(40,40,40,.6), rgba(100,100,100,.6)), url({$url2}); background-size: cover;}}</style>
	<div id="admin-main-cover" style="display: none;">
	<div id="admin-main"style="height: 27.8rem; width: 27.5rem; border-radius: .5rem;margin: 0 auto; margin-top: 1rem;text-align: left;">
	
	<div style="width: 100%; padding-top: 13.75rem;">
		<div style="height: 12.5rem; color: white; border-bottom-right-radius: .5rem;  border-bottom-left-radius: .5rem; padding: .625rem;" padding:>
		<span class="mess-attr">Name:</span> Umukoro Okerefe<br>
		<span class="mess-attr">Department:</span> Mechanical Engineering<br>
		<span class="mess-attr">Level:</span> 400 Level<br>
		<span class="mess-attr">About Me:</span><br>
		<div id="about-admin"  style="overflow: auto; height: 7.5rem; padding-left:.4rem; padding-right: .4rem;" data-mcs-theme="dark-thick">
		{$test}
		</div>
		</div>
	</div>
	</div>
	<div style="width: 27.5rem; margin: 0 auto;"><button style="float:right; cursor: pointer; background: black; color: red; border-radius: .2rem; border-color: black;" onclick="closePopup();">Close</button></div>
	</div>
EOT;

$string_script = <<<EOT
setTimeout(slideDown, 1000);
$("#about-admin").mCustomScrollbar({
	scrollButtons:{enable:true},
	theme:"dark-thick",
	scrollbarPosition:"inside"
});
function slideDown() {		
	$("#admin-main-cover").slideDown(1000);
}
EOT;

$string = ['message' => $string_con, 'script' => $string_script];
$return_array = ['success' => true, 'message' => $string];
echo json_encode($return_array);
exit;



?>