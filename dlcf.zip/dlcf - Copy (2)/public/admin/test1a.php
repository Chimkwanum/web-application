<?php
require_once('../../includes/session.php');
require_once('../../includes/db_connection.php');
require_once('../../includes/functions.php');
// sleep(2);
$str = " [[content:image, source:17, download:true]] [[content:image, source:16, download:true]]";
// $str = "Hello there how are you, Hello there, Hello there";
$pat = "/\[\[content:image, source:([\\d]+), download:(.+?)\]\]/";


// $str = "Some nonsence";
// if(preg_match($pat, $str, $mat)){
	// echo $mat[1];
	// if($image = prod_image($mat[1], $str)) {
		// echo "true";
	// } else {
		// echo $image;
	// }
	// // echo $mat[0] . '<br>';
	// // echo $mat[1] . '<br>';
	// $str = str_replace($mat[0], $image, $str);	
	
		// echo "true";
// } else {
	// echo "false";
// }
// echo $str;


$topic = "Hello  post  		   abou	 	t   		  somethings                	out there";
$str_len = 20;
// $topic = str_replace("\t", "", $topic);
if ($topic = preg_replace("/ +/", "-", $topic)) {
	echo "It is true<br>";
} else {
	echo "It is false<br>";
}
echo $topic . '<br>';
// preg_replace("/.{15}(.+)/", "z", $topic);
// echo $topic;
// print_r($mat);

// $str = "Hello there";
// echo $str;
// $tmp_file = $_FILES['profile-pic']['tmp_name'];
// $target_file = "picture";
// if(move_pic($tmp_file, $target_file)) {
	// $return_array = ['success' => true, 'message' => "The Image was uploaded"];
	// echo json_encode($return_array);	
	// exit;// goback
// } else {
	// echo "Something went wrong";
// }
// [[content:image, source:5]]
// [[content:image, source:5, download:yes]]
	
?>
	
