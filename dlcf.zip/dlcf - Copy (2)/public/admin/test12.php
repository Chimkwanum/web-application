<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Next Steps</title>
<style>
.test{
	height: 100px;
	width: 100px;
	background: orange;
	
}

.changed{
	height: 400px;
	width: 400px;
	background: violet;
}
</style>
</head>
<body>

	<div id="div"class="" data-class="none">Hello there</div>
	<button id="click">Change Class</button> 
	
	<script>
	var button = document.getElementById('click');
	button.addEventListener("click", function() {
		var div = document.getElementById('div');
		var att = div.getAttribute('data-class');
		if(att == 'none') {
			div.classList.add("test");
			div.setAttribute('data-class','test');
		}
		if(att == 'test'){
			div.classList.remove("test");
			div.setAttribute('data-class','changed');
			div.classList.add("changed");
		}
		
		if(att == 'changed'){
			div.classList.remove("changed");
			div.setAttribute('data-class','test');
			div.classList.add("test");
		}
		
	});
	</script>
</body>   
</html>
