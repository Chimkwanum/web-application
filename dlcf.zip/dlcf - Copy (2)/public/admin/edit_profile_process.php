<?php
require_once('../../includes/session.php'); 
require_once('../../includes/db_connection.php');
require_once('../../includes/functions.php');
require_once('../../includes/validation_functions.php');
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

// sleep(3);

if(!is_ajax_request()) { exit; }

// echo "Reached here";
require_once('../../includes/validation_functions.php');
if (!isset($_POST['first_name'])) {
	$return_array = ['success' => false, 'error' => "The transaction cant be done from 1"];
	echo json_encode($return_array);
	exit;// goback
}



$required_fields = array("first_name", "last_name", "course_id", "level", "about_me");
// $user_id = $session->$user_id;
validate_presences($required_fields);
	
$fields_with_max_lenghts = array("first_name" => 300, "last_name" => 300);
validate_max_lengths($fields_with_max_lenghts);
// process the form
if(!empty($errors)) {
	// $return_array = ['success' => false, 'error' => "The transaction cant be done from errors hey"];
	$return_array = ['success' => false, 'error' => $errors];
	echo json_encode($return_array);
	exit;// goback
}
// echo "ending";
$about = mysql_prep($_POST['about_me']);
$first_name = mysql_prep($_POST['first_name']);
$last_name = mysql_prep($_POST['last_name']);
$course_id = (int) mysql_prep($_POST['course_id']);
$level = (int) mysql_prep($_POST['course_id']);

$query = "UPDATE admins SET ";
$query.= "about_me = '{$about}', first_name = '{$first_name}', ";
$query.= "last_name = '{$last_name}', course = {$course_id}, ";
$query.= "level = {$level} WHERE id={$session->user_id}";
// echo $query;
$result = query($query);
if ($result && mysqli_affected_rows($connection) >= 0) {
	$return_array = ['success' => true, 'message' => "Your profile has been updated"];
	echo json_encode($return_array);
	exit;
} else {
	exit;
}	
// if($id === -1 || $id === -2 || $id === -3) {
// } else {
	// $return_array = ['success' => false, 'error' => "The transaction cant be done from 1"];
	// echo json_encode($return_array);
	// exit;// goback
// }
// $time = (int) time();
// if($id === -3) {
	// if (!isset($_POST['admin_id'])){
		// $return_array = ['success' => false, 'error' => "The transaction cant be done from id"];
		// echo json_encode($return_array);
		// exit;// goback
	// }
	 // // Every body
	// if(!val_admin_id($_POST['admin_id'])) {
		// $return_array = ['success' => false, 'error' => "The transaction cant be done from id"];
		// echo json_encode($return_array);
		// exit;// goback
	// }
	// $id = (int) mysql_prep($_POST['admin_id']);
	// $query = "INSERT INTO messages (message, recipient_id, sender_id, time) VALUES (";
	// $query.= "'{$message}', {$id}, {$session->user_id}, {$time})";
	// $result = query($query);
	// if($result) {
		// $return_array = ['success' => true, 'message' => "Your message has been sent successfully"];
		// echo json_encode($return_array);
		// exit;// goback
	// } else {exit;}
	// // $query = "INSERT INTO message_log (admins_id, message_id) VALUES ({$session->user_id}, {$message_id}");
	
// } else {
	// $query = "INSERT INTO messages (message, recipient_id, sender_id, time) VALUES (";
	// $query.= "'{$message}', {$id}, {$session->user_id}, {$time})";
	// $result = query($query);
	// if($result) {
		// $return_array = ['success' => true, 'message' => "Your message has been sent successfully"];
		// echo json_encode($return_array);
		// exit;// goback
	// } else {exit;}
	// // $query = "INSERT INTO message_log (admins_id, message_id) VALUES ({$session->user_id}, {$message_id}");
	
// }
?>