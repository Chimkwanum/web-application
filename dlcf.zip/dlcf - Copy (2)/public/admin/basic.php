<?php
require_once('../../includes/db_connection.php');
require_once('../../includes/functions.php');
require_once('../../includes/validation_functions.php');
require_once('../../includes/session.php');
?>
<?php $max_file_size = 1000000000 ?>
<?php
$str = "<div style=\"height:400px; width:400px; background: url(building-joy-planning-plans.jpg); background-size:cover;\"></div>";
// $str = htmlentities($str);
// $str = "Hello There";
?>
<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Functions: Multiple Returns </title>
	</head>
	<body>
	
	<?php $admins = listed_admins($session->user_id);
		echo $admins; ?>
	<textarea name="content" style="background:inherit;" rows="20" cols="40"><?php echo $str; ?></textarea>
	
	<br><br><button id="test">Click me</button><br>
	
	<script src="../javascripts/jquery.js"></script>
	<script>
	function typeInTextarea(el, newText) {
	  var start = el.prop("selectionStart")
	  var end = el.prop("selectionEnd")
	  var text = el.val()
	  var before = text.substring(0, start)
	  var after  = text.substring(end, text.length)
	  el.val(before + newText + after)
	  el[0].selectionStart = el[0].selectionEnd = start + newText.length
	  el.focus()
	}

	$("#test").on("click", function() {
	  typeInTextarea($("textarea"), "some text")
	  return false
	});
	</script>
	</body>
</html>