<?php
require_once('../../includes/db_connection.php');
require_once('../../includes/functions.php');
require_once('../../includes/validation_functions.php');
require_once('../../includes/session.php');
if (!$session->is_logged_in()) { redirect_to('../index.php');}

?>
<?php $max_file_size = 1000000000 ?>
<?php
$str = "<div style=\"height:400px; width:400px; background: url(building-joy-planning-plans.jpg); background-size:cover;\"></div>";
// $str = htmlentities($str);
// $str = "Hello There";
?>
<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Functions: Multiple Returns </title>
		<!--<link rel="stylesheet" href="../stylesheets/main.css">-->
		<link rel="stylesheet" href="admin.css">
		<script>
		var id = <?php echo $session->user_id; ?>;
		</script>
	<style>
	#change-pass-div{
		display:none;
	}
	</style>
	</head>
	<body>
	<?php
	$admin = val_admin_id($session->user_id);
	
	
	?>
	<form action= "" method = "post" enctype="multipart/form-data" id="details-form">
	<input type="text" name="first_name" id="first_name" class="edit-form" value="<?php echo $admin['first_name'] ?>" placeholder="First Name" disabled/><br><button class="edit" data-id="first_name" onclick= "return false";>Edit First name</button><br /><br />
	<input type = "text" name = "last_name" id="last_name" class="edit-form" value = "<?php echo $admin['last_name'] ?>" placeholder="Last Name" disabled/><br><button class="edit" data-id="last_name" onclick="return false";>Edit Last name</button><br /><br /><br />
	
	<!--email, username, password, profilepic, level, course, about_me-->
	Course Name:
	<select id="courses" class="select edit-form" name="course_id" disabled>
	<?php
	$query = "SELECT * FROM courses";
	$results = query($query);
	while($result = mysqli_fetch_assoc($results)) {
		echo "<option data-years='{$result['years']}' ";
		echo "value ='{$result['id']}'";
		if($result['id'] == $admin['course']) {
			echo " selelcted ";
		}
		echo ">{$result['coursename']}</option>";
	}
	?>
	</select><br />
	<button class="edit" data-id="courses" onclick="return false";>Edit Course</button><br />
	Level:
	<select class="select edit-form" id="level" name="level" disabled>	
	</select><br />
	<button class="edit" data-id="level" onclick="return false";>Edit Level</button><br />

	About Me:<br />
	<!--<textarea name="aboutme" id="about-me" rows="20" cols="40" disabled ><?php echo $admin['about_me'] ?></textarea><br />-->
	<textarea name="about_me" id="about-me" class="edit-form" rows="5" cols="40" disabled ><?php echo $admin['about_me'] ?></textarea><br />
	<button class="edit" data-id="about-me" onclick="return false";>Edit About me</button><br /><br /><br />	
	<input class="submit" type="submit" name="submit" id="edit-admin-det" value="Edit Admin Details" onclick="return false"; disabled/><br />
	<?php $pic = "../admin_pics/" . $admin['id'] . "_admin_profile.png" ?>
	<!--<div style="height:100px; width:100px; background:url(<?php echo $pic; ?>); background-size:cover; "></div>-->
	<div id="error"></div>
	</form>
	<button id="change-pass-butt" onclick="return false";>Change Password</button><br /><br />
	<section id="change-pass-div" >
	<form action= "" method = "post" enctype="multipart/form-data" id="password-form">
	<input type = "password" name = "oldpassword" value = "" placeholder="Old Password" id="oldpassword"/><br />
	<input type = "password" name = "newpassword" value = "" placeholder="New Password" id="newpassword"/><br />
	<input type = "password" name = "confirm-new-password" value = "" placeholder="Confirm New Password" id="confirm-new-password"/><br />
	<input class="submit" type="submit" name="submit" id="create-password" value="Update Password" onclick="return false";/><br />

	</form>
	</section>
	
	<?php $pic = "../admin_pics/" . $session->user_id . "_admin_profile";  ?>
	<?php //$pic = "../admin_pics/7_admin_profile";  ?>
	<div class= "profile-pic" id="profile-pic" style="
		background: url(<?php echo $pic . "_large.png" ?>);
		background-size: cover;
	@media screen and (max-width:320px){
	}
	
	">
	<div id="image-loader" class="profile-pic" >
	</div></div>
	<form method = "post" enctype="multipart/form-data" id="pic-form">
		<input type = "hidden" name = "MAX_FILE_SIZE" value = "{$max_file_size}"/><br />
		Update Profile Pic:<br>
		<input type = "file" name = "picture"/><br>
		<button id="update-pic" class="submit" value = "" onclick="return false";> Upload</button>
		<div id="pic-error"></div>
		
	</form>
	
	<script src="../javascripts/jquery.js"></script>
	<script src="../javascripts/edit_profile.js"></script>
	</body>
</html>