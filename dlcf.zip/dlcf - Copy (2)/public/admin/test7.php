<?php
$test = "	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you";
?>
<!DOCTYPE html PULIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
	
<html lang = "en">
	<head>		
		<meta charset="UTF-8">
	   
		<meta name="viewport" content="width=device=width, initial-scale = 1.0">
		<link rel="stylesheet" href="main.css">
		<link rel="stylesheet" href="../stylesheets/jquery.mCustomScrollbar.min.css">

		<title></title>
		<style>
		#main{
			height: 25.625rem;
			width: 25rem;
			margin: 0 auto;
			display: none;
		}
		#pic{
			height: 70%;
			width: 100%;
			border-radius: .5rem .5rem 0 0;
			background:  linear-gradient(rgba(100,100,100,.7), rgba(100,100,100,.7)), url(../images/pic12.jpg);
			background-size: cover;
		}
		#det{
			height: 30%;
			width: 23rem;
			/*rgb(120,100,50)*/
			padding: 1rem;
			border-radius: 0 0 .5rem .5rem;
			background: rgb(90,90,50);
			overflow: auto;
			color: white;
		}
		.att{
			color: black;
			font-weight: bold;
		}
		html{
			font-family: fantasy;
		}
		</style>
	</head>
	<body>
		<div id="main">
		<div id="pic"></div>
		<div id="det">
		<span class="att">Name:</span> Umukoro okerefe<br>
		<span class="att">Department:</span> Mechanical Engineering<br>
		<span class="att">Level:</span> 100 Level<br>
		<span class="att">About Okerefe:</span><br>
		<?php echo $test ?>
		</div>
		
		
		</div>
	<script src="../javascripts/jquery.js"></script>
	<script src="../javascripts/jquery.mCustomScrollbar.concat.min.js"></script>
	<script>
	$("#det").mCustomScrollbar({
		scrollButtons:{enable:true},
		theme:"dark-thick",
		scrollbarPosition:"inside"
	});
	function slideDown() {		
		$("#main").slideDown(500);
	}
	$(document).ready(function () {
		setTimeout(slideDown, 1000);
	});
	</script>
	</body>
	</html>