<?php
require_once('../../includes/db_connection.php');
require_once('../../includes/validation_functions.php');
require_once('../../includes/functions.php');
require_once('../../includes/session.php');
// if (!$session->is_logged_in()) { redirect_to('../index.php?landingsite=logfile.php');}
// if (isset($_POST['submit']) && isset($_POST['post_name']) && isset($_POST['content'])) {
if (!isset($_GET['id'])){
	redirect_to("index.php");	
}
$id = mysql_prep($_GET['id']);
$query = "SELECT * FROM posts WHERE id={$id}";
$result_set = query($query);
if(!$post = fetch_assoc($result_set)) {
	exit;
}
// $message="Just messing with you";	
?>

<!DOCTYPE HTML>
<html lang = "en">
	<head>
		<link rel="stylesheet" href="stylesheets/main.css">
		<link rel="stylesheet" href="admin.css">
	<style>
	html {
		background: red;
	}
	</style>
	<script>
	function typeInTextarea(el, newText) {
		var start = el.prop("selectionStart")
		var end = el.prop("selectionEnd")
		var text = el.val()
		var before = text.substring(0, start)
		var after  = text.substring(end, text.length)
		el.val(before + newText + after)
		el[0].selectionStart = el[0].selectionEnd = start + newText.length
		el.focus()
	}
	</script>
	</head>
	<body>
	<section id="popup"></section>
		<div id = "header">
		<h1>Some sites</h2>
		</div>
		<?php //print_r($errors);?>
		<?php if (!empty($message)){echo htmlentities($message);}?>

		<div id = "main">
		<div id = "navigation">

		</div>
		<div id = "page">
		<?php
		function find_post_type($code) {
			if($code == 'edu') {
				return "Educational";
			}
			if($code == 'spirit') {
				return "Spiritual";
			}
			if($code == 'announce') {
				return "Announcement";
			}
			return false;
		}
		
		?>
		<h2>Edit Post: </h2>
		Post Type: <?php echo find_post_type($post['content_type']);?> Posts:
		<p>Name of Post:
		<input type = "text" value = "<?php echo $post['topic'];?>" disabled/><br />
		<?php if($post['content_type'] == "edu"): ?>
			<?php 
			$lev = $post['content_level'] . "00 Level";
			?>
			Level:
			<input type = "text" value = "<?php echo $lev;?>" disabled/><br />
		<?php endif; ?>
		<button id="addimage" onclick="return false";>Add image</button>
		<p class="error"></p>
		<br />

		</p>
		<form action = "create_page.php" method = "post" id="form">
		<input  name="post_id" value="<?php echo $post['id']; ?>" type="hidden"/>

		Content:<br />
		<div style="/*background:url(images/kumuyi.jpg); background-size:cover;*/">
		<div style="/*background: rgba(76,67,65,0.4);*/">
		<textarea name="content" style="background:inherit;"rows="20" cols="40"><?php echo $post['content'];?></textarea>
		</div>
		</div>
		<br />
		<input type = "submit" id="submit" name = "submit" value = "Edit Page" />
		</form>

		<div id="error"></div>
		</div>
		</div>

		<div id = "footer">Copyright <?php echo date("Y"); ?>, Widget Corp
		</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="../javascripts/jquery.js"></script>
	<script src="../javascripts/edit_page.js"></script>
	</body>
	
</html>
<?php if(isset($connection)) {mysqli_close($connection); }?>
A post: .....
Topic of post
Content of post
Pictures present in post
Id of admin who posted


Created 
Last edited
email, date_create, admin_stats