<?php
require_once('../../includes/initialize.php');
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

sleep(3);

if(!is_ajax_request()) { exit; }


require_once('../../includes/validation_functions.php');
if (isset($_GET['email']) && isset($_GET['rank'])){
	if (!check_email_regex($_GET['email'])) {
		$return_array = ['success' => false, 'error' => "The Email is not valid"];
		echo json_encode($return_array);
		exit;
	}
	
	if($_GET['rank'] != "1" && $_GET['rank'] != "2") {
		$return_array = ['success' => false, 'error' => "The Email is not valid"];
		echo json_encode($return_array);
		exit;
	}
	
	$email = mysql_prep($_GET["email"]);
	$rank = (int) ($_GET["rank"]);
	
	/*
	$required_fields = array("username", "password");
	validate_presences($required_fields);

	$fields_with_max_lenghts = array("username" => 30);
	validate_max_lengths($fields_with_max_lenghts);*/
	
	
	
	if(!$rand = send_rand($email)){
		$return_array = ['success' => false, 'error' => "The Transaction couldn't be done"];
		echo json_encode($return_array);
		exit;
	}
	if(check_pending_admin($email)) {
		$return_array = ['success' => true, 'message' => "The Email is already pending"];
		echo json_encode($return_array);
		exit;
	}
	
	if(val_admin_email($email)) {
		$return_array = ['success' => true, 'message' => "The Email already exists as an admin"];
		echo json_encode($return_array);
		exit;
	}
	
	$query = "INSERT INTO pending_admins ( ";
	$query.= "email, rank, rand";
	$query.= ") VALUES ( ";
	$query.= "'{$email}', {$rank}, {$rand}";
	$query.= ")";
	$result = query($query);
	if ($result) {
	//success
		$return_array = ['success' => true, 'message' => "The Transaction was successful"];
		echo json_encode($return_array);
		exit;
	}else{
		//failure
		$return_array = ['success' => false, 'error' => "The Transaction couldn't be done"];
		echo json_encode($return_array);
		exit;
	}
} else {
	$return_array = ['success' => false, 'error' => "The transaction cant be done from 1"];
	echo json_encode($return_array);
	exit;// goback
}

	
	
?>