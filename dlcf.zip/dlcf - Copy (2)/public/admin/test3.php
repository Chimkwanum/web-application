<!DOCTYPE html PULIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
	
<html lang = "en">
	<head>		
		<meta charset="UTF-8">
	   
		<meta name="viewport" content="width=device=width, initial-scale = 1.0">
		<link rel="stylesheet" href="main.css">
		<title></title>
		<style>
		#test{
		height: 9.4rem;
		width: 9.4rem;
		background:blue;
		}
		#test2{
		height: 1rem;
		width: 9.4rem;
		background:red;
		}
		a{
			text-decoration: none;
		}
			
		.edit-link{
			height: 1rem;
			background: red;
			padding-left: .5rem;
			font-size: .9rem;
		}
		.posts{
			background: green;
			height: 10.4rem;
			width: 9.4rem;
			border: 2px black;
			display: inline-block;
			margin: 5px;
			cursor: pointer;
		}
		.caption{
			height: 4.7rem;
			margin-top: 4.7rem;
		}

		</style>
	</head>
	<body>
		<!--<div id = "test">
		
		</div>
		<div id="test2">
		
		</div>-->
		<?php $s = "background: green;
	height: 10.4rem;
	width: 9.4rem;
	border: 2px black;
	display: inline-block;
	margin: 5px;
	cursor: pointer;"?>
	<?php $a = "height: 1rem;
	background: red;
	padding-left: .5rem;
	font-size: .9rem;
	
	"
	
	?>
	
	<div class="article posts" style="<?php echo $s?>">
	<a href="test">
	<div style="overflow: hidden;">
	
	<div class="caption" style="height: 4.7rem;margin-top: 4.7rem;">
	This Topic will be quite long very longTopic will be quite long very long
	</div>
	
	</div>
	</a>
	<a href="edit_post/"><div class="edit-link" style="<?php echo $a?>">Edit Post</div></a>
	
	</div>

	
	
	
	<?php
	// $post= "This Topic will be quite long very longTopic will be quite long very long";
	// $output = "";
	// $output.= "<div class=\"article posts\">";
	// $output.= "<a href=\"test\"><div style=\"overflow: hidden;\">";
	// $output.= "<div class=\"caption\">{$post}</div></div></a>";
	// $output.= "<a href=\"edit_post/\"><div class=\"edit-link\">Edit Post</div></a></div>";
	// echo $output;
?>

	</body>
</html>