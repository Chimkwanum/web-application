<?php
require_once('../../includes/db_connection.php');
require_once('../../includes/functions.php');
?>
<html lang = "en">
	<head>
	<link rel="stylesheet" href="admin.css">
	<link rel="stylesheet" href="../stylesheets/jquery.mCustomScrollbar.min.css">
	</head>
	<body>
	<section class="section" data-mcs-theme="rounded-dots-dark">
	<?php echo load_posts_thumb(); ?>
	</section><br /><br />
	<script src="../javascripts/jquery.js"></script>
	<script src="../javascripts/jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="javascripts/index_script.js"></script>
	
	<script>
	$(window).on("load",function(){
		var amount=200;
		$(".section").mCustomScrollbar({
			axis:"x",
			//theme:"rounded-dots-dark",
			//theme:"3d-thick",
			advanced:{
				autoExpandHorizontalScroll:true
			},
			scrollbarPosition: "outside",
			autoHideScrollbar: true,
			scrollButtons:{
				enable:true,
				scrollType:"stepped"
			},
			keyboard:{scrollType:"stepped"},
			snapAmount:amount,
			mouseWheel:{scrollAmount:amount}
		});
		
	});
	</script>
	
	
	</body>

	