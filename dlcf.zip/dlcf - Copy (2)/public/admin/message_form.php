<?php
require_once('../../includes/session.php'); 
require_once('../../includes/db_connection.php');
require_once('../../includes/functions.php');
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

// sleep(3);

if(!is_ajax_request()) { exit; }

$select = "<select id=\"receivers\" name=\"receiver\">";
if ($session->rank == 1) {
	$select.= "<option value=\"-1\">All Leaders </option>";
}
$select.= "<option value=\"-2\">All Workers </option>";
$select.= "<option value=\"-3\">Selected Persons</option>";
$select.= "</select>";
$admins = listed_admins($session->user_id);
$contain = "height: 300px;
overflow: auto;
display: none;
clear: both;";

$string_con = <<<EOT
	<setion id="container" class="popup-main" style="width: 80%;">
	<form action= "index.php" method = "post" id="form">	
	Type Messages: <br />
	<textarea name="message" id="textarea" style="background:inherit;" rows="10" cols="30" placeholder="Type Message"></textarea><br />
	To {$select}
	<div id="admin-members-container">
	{$admins}
	</div>
	<br><br><br>
	<div style="margin: 0 auto">
	<input class="submit" type="submit" name="submit" id="send-message" value="Send Message" onclick= "return false";/></div>
	<div id="error"></div>
	</form>
	<button id="close-popup">Close Popup</button>
	</section>
EOT;


$string_script = <<<EOT
changeReceive();

function send_message(form) {
	var url = 'send_message.php';
	var xhr = new XMLHttpRequest();
	xhr.open('POST', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			testing();
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			
			var error = document.getElementById("error");
			
			error.innerHTML = json.message;
			if(json.success == true) {
				// We close popup and then disable script
			} else {
				
			}
		}
	}
	xhr.send(form);
}


function changeReceive() {
	var select = document.getElementById("receivers");
	sel_rec = select.options[select.selectedIndex].value;
	var admins = document.getElementById("admin-members-container");
	if(sel_rec == -3) {
		
		$("#admin-members-container").slideDown(500);
		// $("#form").slideToggle(500);
	} else {
		$("#admin-members-container").slideUp(500);
	}
}
$("#receivers").change(function () {
	changeReceive();
});


$("#send-message").click(function () {
	var form = document.getElementById("form");
	alert("here");
	var form_data = new FormData(form);
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}	
	send_message(form_data);
});

var close = document.getElementById("close-popup");
close.addEventListener("click", function () {
	var popup = document.getElementById("popup");
	popup.style.display = "none";
});

EOT;
$string = ['message' => $string_con, 'script' => $string_script];
$return_array = ['success' => true, 'message' => $string];
echo json_encode($return_array);
exit;

if (!isset($_POST['message']) || !isset($_POST['receiver'])){
	$return_array = ['success' => false, 'error' => "The transaction cant be done from 1"];
	echo json_encode($return_array);
	exit;// goback
}
