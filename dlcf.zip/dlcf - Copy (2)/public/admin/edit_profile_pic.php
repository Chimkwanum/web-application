<?php
require_once('../../includes/initialize.php'); 
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

// sleep(3);

if(!is_ajax_request()) { exit; }
	if(!isset($_FILES['picture'])) {exit;}
	$required_fields = array("picture");
	if(!validate_photo($required_fields)) {
		$return_array = ['success' => false, 'message' => "The File is not an image or  is invalid"];
		echo json_encode($return_array);
		exit;
	}
	$id = $session->user_id;
	$tmp_file = $_FILES['picture']['tmp_name'];
	$admin_path = ADMIN_IMG;
	$target_file = "../admin_pics/{$id}_admin_prof";
	$url =  "url(" . ADMIN_IMG . "{$id}_admin_prof_1.png)"; 
	if(move_pic($tmp_file, $target_file)) {
		$return_array = ['success' => true, 'message' => "The Image was uploaded", "url" => $url];
		echo json_encode($return_array);	
		exit;// goback
	} else {
		$return_array = ['success' => false, 'message' => "The Image upload failed"];
		echo json_encode($return_array);
		exit;// goback
	}
	
	$time = (int) time();
	$name = mysql_prep($_POST['pic-name']);
	$query = "INSERT INTO pictures (name, upload_id, time) VALUES ('{$name}', {$session->user_id}, {$time})";
	$result = query($query);
	if(!$result){exit;}
	$tmp_file = $_FILES['picture']['tmp_name'];
	$id = mysqli_insert_id($connection);
	$target_file = '../post_pics/' . $id . '_postpic';
	$now = $target_file . '_small.png'; 
	
	if(move_pic($tmp_file, $target_file)) {
		$return_array = ['success' => true, 'message' => "The Image was uploaded", "now" => $now];
		echo json_encode($return_array);	
		exit;// goback
	} else {
		$return_array = ['success' => false, 'message' => "The Image upload failed"];
		echo json_encode($return_array);
		exit;// goback
	}


