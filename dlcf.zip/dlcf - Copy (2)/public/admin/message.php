<?php
require_once('../../includes/initialize.php'); 
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

sleep(5);

if(!is_ajax_request()) { exit; }
if(!isset($_GET['id'])) {
	exit;
}
if(!isset($_GET['cont'])) {
	exit;
}
if($_GET['cont'] != 'rec' && $_GET['cont'] != 'sent') {
	exit;
}

$test = "	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you	Hello there There Is some thing I wanted to tell you";
$test = $test.$test.$test;
$id = (int) mysql_prep($_GET['id']);
$query = "SELECT * FROM messages WHERE id={$id}";
$message = fetch_assoc(query($query));
if($_GET['cont'] == 'rec') {
	$cont = "From";
	$sender = val_admin_id($message['sender_id']);
	$name = ucfirst($sender['first_name']) . ' ' . ucfirst($sender['last_name']);
	$pic = ADMIN_IMG . $message['sender_id'] . "_admin_profile";
}
if($_GET['cont'] == 'sent') {
	$cont = "Sent to";
	$name = val_admin_id($message['recipient_id'])['first_name'];
	if($message['recipient_id'] == -1) {$name = "All Leaders";}
	if($message['recipient_id'] == -2) {$name = "All Workers";}
	$pic = ADMIN_IMG . $message['recipient_id'] . "_admin_profile";
	
}
$time = strftime("%B %d, %Y at %I:%M %p", $message['time']);

if(!$message) {exit;}
$url1 = $pic . '_small.png';
$url2 = $pic . '_large.png';

// $url1 = $pic . '_2.png';
// $url2 = $pic . '_3.png';

$string_con = <<<EOT
<style>@media screen and (max-width: 800px){#mess_main{background: linear-gradient(rgba(100,100,100,.8), rgba(100,100,100,.8)), url({$url1});background-size: cover;}}@media screen and (min-width:801px){#mess_main{background: linear-gradient(rgba(100,100,100,.8), rgba(100,100,100,.8)), url({$url2});background-size: cover;}}</style>
			
<div id="mess_main" style="">
<div id="mess_message" data-mcs-theme="dark-thick">
{$message['message']}
</div>
<div id="mess_from">
	<span class="mess-attr">{$cont}:</span> {$name}<br>
	<span class="mess-attr">Time:</span> {$time}.
</div>
<button onclick="closePopup();" class="mess-close">Close</button>

</div>

EOT;

$string_script = <<<EOT
setTimeout(slideDown, 1000);
$("#mess_message").mCustomScrollbar({
	scrollButtons:{enable:true},
	theme:"dark-thick",
	scrollbarPosition:"inside"
});
function slideDown() {		
	$("#mess_main").slideDown(500);
}
EOT;

$string = ['message' => $string_con, 'script' => $string_script];
$return_array = ['success' => true, 'message' => $string];
echo json_encode($return_array);
exit;