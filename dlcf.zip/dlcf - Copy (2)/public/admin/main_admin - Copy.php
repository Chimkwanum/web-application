<?php  require_once('../../includes/session.php');?> 
<?php  require_once('../../includes/db_connection.php');?> 
<?php  require_once('../../includes/functions.php');?> 
<?php
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}
?>

<?php  require_once('../../includes/validation_functions.php');?> 
	<?php
	if (isset($_POST['submit'])){
		$username = mysql_prep($_POST["username"]);
		$password = password_encrypt($_POST["password"]);

		$required_fields = array("username", "password");
		validate_presences($required_fields);
		
		$fields_with_max_lenghts = array("username" => 30);
		validate_max_lengths($fields_with_max_lenghts);
		
		if(empty($errors)){
			$query = "INSERT INTO admins ( ";
			$query.= "username, hashed_password";
			$query.= ") VALUES ( ";
			$query.= "'{$username}', '{$password}'";
			$query.= ")";
			$result = query($query);
			if ($result) {
				//success
				$_SESSION["message"] = "Admin Profile Created.";
				redirect_to ("manage_admins.php");
			}else{
				//failure
				$message = "Admin Profile Creation failed.";

			}

			
			}
	}

	
	
?>

<!DOCTYPE HTML>
<html lang = "en">
	<head>
		<link rel="stylesheet" href="stylesheets/main.css">
	</head>
	<body>
<div id = "main">
	
	<div id = "page">
		<?php
			if (!empty($message)){
				echo "<div class = \"message\">" . htmlentities($message) . "</div>";
			}
		?>
		

		<h2>Create Admin</h2>
		<form action = "new_admin.php" method = "post">
		<p>Email:
				<input type = "text" name = "email" value = "" />
				<br />
		</p>
		<p>Admin Rank:<br />
		<select>
			
		</select>
		
		<p>Password:
				<input type = "password" name = "password" value = "" />
				<br />
			
		</p>
		<input type = "submit" name = "submit" value = "Create New Admin" />
		</form>

	</div>
</div>
<div id = "footer">
<?php if(isset($connection)) {mysqli_close($connection); }?>











