<?php
require_once('../../includes/session.php'); 
require_once('../../includes/db_connection.php');
require_once('../../includes/functions.php');
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

// sleep(3);

if(!is_ajax_request()) { exit; }

$select = "<select id=\"receivers\" name=\"receiver\">";
if ($session->rank == 1) {
	$select.= "<option value=\"-1\">All Leaders </option>";
}
$select.= "<option value=\"-2\">All Workers </option>";
$select.= "<option value=\"-3\">Selected Persons</option>";
$admins = listed_admins($session->user_id);
$contain = "height: 300px;
overflow: auto;
display: none;
clear: both;";

$string_con = <<<EOT
	<section>
	<form action= "" method = "post" enctype="multipart/form-data" id="validate-admin-form">
	<input type = "test" name = "first_name" id="first_name" value = "" placeholder="First Name" disabled/><br />
	<input type = "test" name = "last_name" id="last_name" value = "" placeholder="Last Name"/><br />
	<input type = "password" name = "password" value = "" placeholder="password" id="password"/><br />
	<input type = "password" name = "confirm-password" value = "" placeholder="Confirm Password" id="confirm-password"/><br />
	<!--email, username, password, profilepic, level, course, about_me-->
	Course Name:
	<select id="courses" class="select" name="courseid" disabled>
		<option>Hello there</option>
		<option>Hello there</option>
	</select><br />
	Level:
	<select class="select" id="level" name="level">
	
	</select><br />
	About Me:<br />
	<textarea name="aboutme" rows="20" cols="40"></textarea><br />
	<input class="submit" type="submit" name="submit" id="validate-new-admin" value="Create New Admin"/><br />
	</form>
	</section>

EOT;
$string_script = <<<EOT
function send_message(form) {
	var url = 'send_message.php';
	var xhr = new XMLHttpRequest();
	xhr.open('POST', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			testing();
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			
			var error = document.getElementById("error");
			
			error.innerHTML = json.message;
			if(json.success == true) {
				// We close popup and then disable script
			} else {
				
			}
		}
	}
	xhr.send(form);
}



$("#receivers").change(function () {
	var select = document.getElementById("receivers");
	sel_rec = select.options[select.selectedIndex].value;
	if(sel_rec == -3) {
		var admins = document.getElementById("admin-members-container");
		$("#admin-members-container").slideToggle(500);
		// $("#form").slideToggle(500);
	} else {
		$("#admin-members-container").slideUp(500);
	}
	alert("Working");
	// alert(sel_rec);
	
});

$("#send-message").click(function () {
	var form = document.getElementById("form");
	alert("here");
	var form_data = new FormData(form);
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}	
	send_message(form_data);
});


EOT;
$string = ['message' => $string_con, 'script' => $string_script];
$return_array = ['success' => true, 'message' => $string];
echo json_encode($return_array);
exit;

if (!isset($_POST['message']) || !isset($_POST['receiver'])){
	$return_array = ['success' => false, 'error' => "The transaction cant be done from 1"];
	echo json_encode($return_array);
	exit;// goback
}
