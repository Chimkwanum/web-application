<?php
require_once('../../includes/db_connection.php');
require_once('../../includes/validation_functions.php');
require_once('../../includes/functions.php');
require_once('../../includes/session.php');

// if (!$session->is_logged_in()) { exit;}
if (isset($_POST['post_type']) && isset($_POST['post_name']) && isset($_POST['content']) && isset($_POST['level'])) {
	validate_post_type();
	$required_fields = array("post_name", "content", "level");
	// $user_id = $session->$user_id;
	validate_presences($required_fields);
		
	$fields_with_max_lenghts = array("post_name" => 200);
	validate_max_lengths($fields_with_max_lenghts);
	// process the form
	$lev = (int) mysql_prep($_POST["level"]);
	
	$time = (int) time();
	check_post_name();
	if(empty($errors)) {
		$post_name = mysql_prep($_POST["post_name"]);
		$content = mysql_prep($_POST["content"]);
		$post_type = mysql_prep($_POST['post_type']);	
		$query = "INSERT INTO posts ( ";
		$query.= "topic, content, creator_id, created, updated, content_level, content_type";
		$query.= ") VALUES ( ";
		$query.= "'{$post_name}', '{$content}', 1, {$time}, {$time}, {$lev}, '{$post_type}'";
		// $query.= "'{$post_name}', '{$content}', {$session->user_id}, {$time}, {$time}, {$lev}, '{$post_type}'";
		$query.= ")";
		$result = query($query);
		$id = mysqli_insert_id($connection);		
		if ($result) {
			//success
			create_page($id, $post_name);
			$_SESSION["message"] = "Page Created.";
			$return_array = ['success' => true, 'message' => "Page Created Successfully"];
			echo json_encode($return_array); exit;
		} else {
			//failure
			$return_array = ['success' => false, 'message' => "Page Creation failed."];
			echo json_encode($return_array); exit;
		}
	} else {
		$return_array = ['success' => false, 'message' => form_errors($errors)];
		echo json_encode($return_array); exit;
		// print_r ($errors);
	}
}
exit;
// $message="Just messing with you";	
?>