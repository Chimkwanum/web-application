<?php
// window.location.replace("http://sidanmor.com");



?>
<html lang = "en">
	<head>
		<title>DLCF Fupre <?php if ($layout_context == "admin"){ echo "Admin"; }?></title>
		<link rel="stylesheet" href="stylesheets/main.css">
		<style>
		html{
			color:black;
			background: black;
		}
		section{
			color: black;
			height: 300px;
		}
		</style>
		
	</head>
	<body>
		This will be the caban of the Admin
	<section>
		Notification Panel for any messages that one has..
	
	</section>
	<section>
		Posts Created by you
	</section>
	
	<section>
		Posts Edited by you
	</section>

	<section>
		Create Post
	</section>
	
	<section>
		Edit Post
	</section>
	
	
	
	
	</body>
</html>