<?php
require_once('../../includes/session.php'); 
require_once('../../includes/db_connection.php');
require_once('../../includes/functions.php');
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

// sleep(3);

if(!is_ajax_request()) { exit; }
if(!isset($_GET['id'])) {
	exit;
}
$id = (int) mysql_prep($_GET['id']);
$query = "SELECT * FROM admins WHERE id={$id}";
$admin = fetch_assoc(query($query));

if(!$admin) {exit;}
// echo "Message is: " . $message['message'] . "<br>";
// echo "Sender is: " . val_admin_id($message['sender_id'])['first_name'] . "<br>";
$admin_pic = "../admin_pics/" . $admin['id'] . "_admin_profile_large.png";
$admin_name = $admin['first_name'] . ' ' . $admin['last_name'];
$string_con = <<<EOT
	<setion id="container" style="">
	<div style="height: 100px; width:100px; background: url({$admin_pic}); background-size:cover;">{$admin_name}</div>
	<br><br><div>{$admin['about_me']}</div>
	</section>

EOT;

$string_script = <<<EOT
function send_message(form) {
	var url = 'send_message.php';
	var xhr = new XMLHttpRequest();
	xhr.open('POST', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			testing();
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			
			var error = document.getElementById("error");
			
			error.innerHTML = json.message;
			if(json.success == true) {
				// We close popup and then disable script
			} else {
				
			}
		}
	}
	xhr.send(form);
}



$("#receivers").change(function () {
	var select = document.getElementById("receivers");
	sel_rec = select.options[select.selectedIndex].value;
	if(sel_rec == -3) {
		var admins = document.getElementById("admin-members-container");
		$("#admin-members-container").slideToggle(500);
		// $("#form").slideToggle(500);
	} else {
		$("#admin-members-container").slideUp(500);
	}
	alert("Working");
	// alert(sel_rec);
	
});

$("#send-message").click(function () {
	var form = document.getElementById("form");
	alert("here");
	var form_data = new FormData(form);
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}	
	send_message(form_data);
});


EOT;
$string_script = "";
$string = ['message' => $string_con, 'script' => $string_script];
$return_array = ['success' => true, 'message' => $string];
echo json_encode($return_array);
exit;
