<?php
require_once('../../includes/initialize.php');
if (!$session->is_logged_in()) { redirect_to('../index.php');}
?>
<!DOCTYPE html>
<html lang = "en">
	<head>
	<link rel="stylesheet" href="../stylesheets/jquery.mCustomScrollbar.min.css">
	<link rel="stylesheet" href="admin.css">
	<style>
	#popup{
		display: fixed;
	}

	html{
	}
	body{
	}
	#main{
		font-weight: bold;
		background-size: cover;
		height: content-height;
		width: content-width;
		
	}
	
	<?php 
	$folder =ADMIN_IMG;
	
	?>
	@media screen and (max-width:320px) {
		#welcome-div{
			background: linear-gradient(rgba(40,40,40,.4), rgba(100,100,100,.4)), url(<?php echo ADMIN_IMG . $session->user_id;?>_admin_prof_2.png);
			background-size: cover;
		}
	}

	@media screen and (min-width:320px) and (max-width: 479px){
		#welcome-div{
			background: linear-gradient(rgba(40,40,40,.4), rgba(100,100,100,.4)), url(<?php echo ADMIN_IMG . $session->user_id;?>_admin_prof_3.png);
			background-size: cover;
		}
	}
	@media screen and (min-width:480px) and (max-width: 767px){
		#welcome-div{
			background: linear-gradient(rgba(40,40,40,.4), rgba(100,100,100,.4)), url(<?php echo ADMIN_IMG . $session->user_id;?>_admin_prof_5.png);
			background-size: cover;
		}
	}
	@media screen and (min-width:768px) and (max-width: 1023px){
		#welcome-div{
			background: linear-gradient(rgba(40,40,40,.4), rgba(100,100,100,.4)), url(<?php echo ADMIN_IMG . $session->user_id;?>_admin_prof_5.png);
			background-size: cover;
		}
	}
	@media screen and (min-width:1024px) and (max-width: 1199px){
		#welcome-div{
			background: linear-gradient(rgba(40,40,40,.4), rgba(100,100,100,.4)), url(<?php echo ADMIN_IMG . $session->user_id;?>_admin_prof_5.png);
			background-size: cover;
		}
	}
	@media screen and (min-width:1200px){
		#welcome-div{
			background: linear-gradient(rgba(40,40,40,.4), rgba(100,100,100,.4)), url(<?php echo ADMIN_IMG . $session->user_id;?>_admin_prof_5.png);
			background-size: cover;
		}
	}

	
	</style>
	<script>
	function testing() {
		alert("Testing script efficiency");
	}
	</script>
	</head>
	<body>
	<span style="margin:0 auto;position:fixed;color:red;text-align:center; z-index: 10;">W:<span id="w"></span>px &nbsp;H:<span id="h"></span>px</span>
	<section id="popup"></section>
	<section id="main"> 
	<header id="header">
	<div id="logo1"></div> <div id="logo2"></div>
	DLCF <br /> FUPRE
	</header>
	
	<div id="welcome-div">Dear User Welcome to the Admin Section of this site your rank in this site is sso so so and so but please you are advise to update things careflly as what you do here affect the whole fnctnality of the  site. Dear User Welcome to the Admin Section of this site your rank in this site is sso so so and so but please you are advise to update things careflly as what you do here affect the whole fnctnality of the  site</div>
	
	<h3 style="margin: 0;">Messages:</h3>
	Received Messages:<br>
	Below are messages sent to you:<br>
	<div class="message-section-cover section-cover">
	<section class="section message-section" data-mcs-theme="rounded-dots-dark">
	<?php echo load_my_messages($session->user_id, $session->rank) ?>
	<?php //echo load_my_messages(1, 1); ?>
	</section></div><br />
	
	Sent Messages:<br>
	Below are messages sent By you:<br>
	<div class="message-section-cover section-cover">
	<section class="section message-section" data-mcs-theme="rounded-dots-dark">
	<?php echo load_sent_messages($session->user_id) ?>
	<?php //echo load_sent_messages(1) ?>
	</section></div><br />
	<div id="sendmessage">Send Message</div><br><br>
		
	All Posts:<br>
	Below are all the Posts on the site:<br>
	<section class="post-section-cover section-cover section" data-mcs-theme="rounded-dots-dark">
	
		<div class="article posts load" id="loadall">
		<div class="load-button" id="buttonall">
		<div id="all" class="load-click" data-page="0">Load More...</div>
		</div>
		<div id="spinall" class="load-spin"></div>
		
		</div>
	</section>

	<br /><br />
	
	Educational Posts:<br>
	Below are all the Educational Posts on the site:<br>
	<section class="post-section-cover section-cover section" data-mcs-theme="rounded-dots-dark">
	
		<div class="article posts load" id="loadedu">
		<div class="load-button" id="buttonedu">
		<div id="edu" class="load-click" data-page="0">Load More...</div>
		</div>
		<div id="spinedu" class="load-spin"></div>
		
		</div>
	</section>
	<br /><br />


	Spiritual Posts:<br>
	Below are all the Spiritual Posts on the site:<br>
	<section class="post-section-cover section-cover section" data-mcs-theme="rounded-dots-dark">
	
		<div class="article posts load" id="loadspirit">
		<div class="load-button" id="buttonspirit">
		<!--<button id="spirit" class="load-click" data-page="0">Load More...</button>-->
		<div id="spirit" class="load-click" data-page="0">Load More...</div>
		</div>
		<div id="spinspirit" class="load-spin"></div>
		
		</div>
	</section>
	<br /><br />
	
	Announcement Posts:<br>
	Below are all the Announcement Posts on the site:<br>
	<section class="post-section-cover section-cover section" data-mcs-theme="rounded-dots-dark">
		<div class="article posts load" id="loadannounce">
		<div class="load-button" id="buttonannounce">
		<div id="announce" class="load-click" data-page="0">Load More...</div>
		</div>
		<div id="spinannounce" class="load-spin"></div>
		
		</div>
	</section><br /><br />
	
	
	My Posts:<br>
	Below are Posts Created by You:<br>
	<div class="post-section-cover section-cover">
	<section class="section post-section" data-mcs-theme="rounded-dots-dark">
	<?php //echo load_posts_thumb("all"); ?>
	</section></div><br /><br />
	
	
	Posts Edited by you:<br>
	Below are Posts that has been edited by you in the past:<br>
	<div class="post-section-cover section-cover">
	<section class="section post-section" data-mcs-theme="rounded-dots-dark">
	<?php //echo load_posts_thumb("all"); ?>
	</section></div><br /><br />
	
	
	<section>
		<a href="create_page.php">Create Post</a>
	</section><br />
	
	
	<section>
		<a href="edit_profile.php">Edit Profile</a>
	</section><br>
	Admins: <br>
	<div class="admin-section-cover section-cover">
	<section class="section" data-mcs-theme="rounded-dots-dark">
	<?php //echo load_admins($session->user_id);?>
	<?php echo load_admins(1);?>
	</section></div>
	<br><br>
	</section>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="../javascripts/jquery.js"></script>
	<script src="../javascripts/admin_index.js"></script>
	<script src="../javascripts/jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="../javascripts/custom_scroll.js"></script>
	<script>
		
	</script>
	</body>
</html>