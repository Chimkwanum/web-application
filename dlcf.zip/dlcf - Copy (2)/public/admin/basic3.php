<?php $max_file_size = 1000000000 ?>

<!DOCTYPE html PULIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
	
<html lang = "en">
	<head>
		<title>Functions: Multiple Returns </title>
		<style>
		.gen{
			height: 100px;
			width: 100px;
			background: brown;
			margin: 10px;
			display: inline-block;
		}
		</style>
	</head>
	<body>
	<?php
	$id=1;
	for($i=0; $i<5; $i++) {
		echo "<div class=\"gen\" id=\"{$id}\"></div>";
		$id++;
	}?>
	<!--function doWithThisElement(event) {
    event = event || window.event; // IE
    var target = event.target || event.srcElement; // IE

    var id = target.id;
    //...
}-->
	<script src="../javascripts/jquery.js"></script>
	<script>
	$(document).ready(function() {
		$(".gen").click(function(event) {
			var str = "The id is: ";
			alert(str + event.target.id);
		});
	});
	</script>
	</body>
</html>

