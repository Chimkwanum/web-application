<?php require_once('../../includes/initialize.php'); ?>
<?php $text = "<p>Once you master the basics of authoring HTML, you&rsquo;ll need focus on what your next steps will be. If you&rsquo;re an aspiring web designer, you&rsquo;ll need to dive deeper into HTML, CSS, and JavaScript. If you&rsquo;re maintaining a corporate or personal site through a CMS, you&rsquo;ll need to focus on how the CMS works, and the most efficient ways to edit and maintain content. On this page I&rsquo;ll give you some basic advice on how to approach learning web design and point you towards additional resources that can help you along the way.</p>";?>
<!DOCTYPE HTML>	
<html>
	<head>
		<meta charset="UTF-8">
        <title>Test10</title>
		<meta name="viewport" content="width=device-width, initial-scale = 1.0">
		<link rel="stylesheet" href="../stylesheets/jquery.mCustomScrollbar.min.css">
		<style>
		.pictures{
			height: 100px;
			width: 100px;
			border: 10px solid white;
			background: red;
			margin-left: .2rem;
			margin-top: .4rem;
			float: left;
		}
		.pic-size{
			height: 100px;
			width: 100px;
			margin-left: .2rem;
			margin-top: .4rem;
			float: left;
		}
		#load{
			height: 100px;
			width: 100px;
			background: red;
			margin-left: .2rem;
			margin-top: .4rem;
			float: left;
		}
		.tabs:hover{
			background: red; 
			cursor:pointer;
		}

		.tabs.active{
			background: #2e2e2e; /* old browsers */
			cursor:pointer;
		}


		a{
			text-decoration: none;
			color: white;
			margin: 0px;
		}
		.panel{
			height: 100%;
			background: #2e2e2e;
			color: white;
			font-family: fantasy;
			margin: 0 auto;
			margin-bottom: 50px;
			width: 100%;
		}
		#section{
			margin: 0 auto;
			width: 90%;
		}
		#tabs-cover {
			display: block;
			align-content: left;
			text-align: left;
			clear: both;
			margin-bottom: 0px;
			width: 98%;
			float: left;
		}
		#panels-div {
			clear: both;
			width: 96%;
			margin: 0 auto;
			height: 85%;
			background: #2e2e2e;
		}
		
		#tabPanel2 {
		}
		.load-spin{
			height: 100%;
			width: 100%;
			background: url(spinner.gif);
			background-size: cover;
			display: none;
		}
		.popup-main {
			height: 90%;
			width: 750px;
			margin-top: 2rem;
			
		}
		#tab1 {
		}
		#tab2 {
		}
		.tabs, .insert{
			display: inline-block;
			margin: 0 auto;
			cursor: pointer;
			/*background: #2e2e2e;*/
			color: white;
			background: purple;
			line-height: 2rem;
			margin: 0px;
			padding: .4rem;
			word-wrap: break-word;
			border-top-left-radius: .4rem;
			border-top-right-radius: .4rem;
		}
		#insert{
			background: red;
			float: right;
			color: red;
		}
		#insert:hover{			
			background: green;
		}

		#formspin {
			background : url(spinner.gif);
			background-size : cover;
			display: none;
		}
		#image-name-span{
			margin-left: 3rem;
			display: none;
		}
		.image-buttons{
			background: black;
			border-radius: .2rem;
			border-color: black;
			color: white;
		}
		#pic-name{
			font-size: 1rem;
			border-width: 2px;
			border-color: black;
			padding: 1px;
			margin-bottom: 10px;
			border-radius: 5px;
			line-height: 2rem;
			font-family: inherit;
			font-size: 1rem;
			color: white;
			background: rgb(20,20,20);
		}
		#pic-name:focus{
			background: white;
			color: rgb(20,20,20);
		}
	
		</style>
	</head>
	<body style="height: 641px;"> 
	<section id="section" style="width: 80%; height: 90%;"class="popup-main"  data-mcs-theme="dark-thick">
      <div id= "tabs-cover" style="padding-left: 2%;">
        <div id="tab1" class="tabs"><a href="#tabPanel1">
			Upload Image
		</a></div>
        <div id="tab2" class="tabs"><a href="#tabPanel2">
			Select From Uploaded
		</a></div>
		<span id="image-name-span"><b>Image Name:</b> <span id="image-name"></span></span>
		 <div data-image="0" id="insert" class="insert">
			<span id="insert-message" style="display: hidden;">Insert Image</span><span id="img-id"></span>
		</div>
	</div>
	<div id='panels-div'>
	<div id="tabPanel1" class="panel" style="height: 28.5rem; padding: 2%;  margin: 0 auto;overflow: auto;">
	<form method = "post" enctype="multipart/form-data" id="pic-form" class="pic-size" style="margin-right: 1.2rem;">
		<input type = "hidden" name = "MAX_FILE_SIZE" value = "{$max_file_size}"/>
		<input type = "file" name = "picture" class=""/><br>
		<input type = "text" name = "pic-name" id="pic-name" placeholder="Name Of Picture"/><br />
		<button id="submit" class="submit image-buttons" value = "" onclick="return false";> Upload</button><br>
		<div id="error" style='color: white;'></div>
	</form>	
		<div id="insert-before"></div>
		<div id="formspin" class="pic-size"></div>
		<!--<br><button id="insert" onclick="return false"; data-image="0">Insert Image</button><br>-->
		
	</div>
	
	<div id="tabPanel2" class="panel" style="height: 28.5rem; overflow: auto; margin: 0 auto;content-align: center; padding: 2%;">
		<div id="load">
		<div id="load-button">
		<div id="pic-click"  data-page="0">Load More...</div>
		</div>
		<div id="picspin" class="load-spin"></div>
		
		</div>

	</div>
	</div>
	<button class="image-buttons"style="height:1.5rem; float:right;color: red;">Close</button>
	</section>
	<br><br><br><br><br><br><br><br><br><br><br><br>
	<script src="../javascripts/jquery.js"></script>
	<script src="../javascripts/jquery.mCustomScrollbar.concat.min.js"></script>
	
	<script>
	var select = document.getElementById("insert");
	
	function loadPic() {
		// alert('start');
		document.getElementById('load-button').style.display = 'none';
		document.getElementById('picspin').style.display = 'block';
		var page = parseInt(document.getElementById('pic-click').getAttribute('data-page')) + 1;
		// if(id == 'edu') {// }
		
		var url = 'load_pic.php?page=' + page;
		
		var xhr = new XMLHttpRequest();
		xhr.open('GET', url, true);
		xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
		xhr.onreadystatechange = function () {
			if(xhr.readyState == 4 && xhr.status == 200) {
				console.log(xhr.responseText);
				// document.getElementById('debug').innerHTML = xhr.responseText;
				var json = JSON.parse(xhr.responseText);
				if(json.success == true) {
				document.getElementById('pic-click').setAttribute('data-page', page);
				var temp = document.createElement('div');
				// temp.setAttribute('class', 'article');
				temp.setAttribute('id', 'now');
				temp.innerHTML = json.message;
				temp.style.display = 'none';
				$('#load').before(temp);
				$('#now').toggle(1000);
				temp.setAttribute('id', 'later');
				if(json.finished == true) {
					// document.getElementById('load').innerHTML = "";
					document.getElementById('load-button').innerHTML = json.extra;
					document.getElementById('picspin').style.display = 'none';
					document.getElementById('load-button').style.display = 'block';
						// document.getElementById('load').innerHTML = json.extra;
				} else {
					document.getElementById('load-button').style.display = 'block';
					document.getElementById('picspin').style.display = 'none';
				}
					
				}
			}
		}
		xhr.send();	
		
	}
	
	function displayPanel(tabToActivate) {
		// go through all the <li> elements
		for (var i = 0; i < tabLinks.length; i++) {
			if (tabLinks[i] == tabToActivate) {
				// if it's the one to activate, change its class
				tabLinks[i].classList.add("active");
				// and display the corresponding panel
				tabPanels[i].style.display = "block";
			} else {
				// remove the active class on the link
				tabLinks[i].classList.remove("active");
				// hide the panel
				tabPanels[i].style.display = "none";
			}
		}
	}
	
	function clearError() {
		document.getElementById('error').innerHTML = '';
	}

	function picClick(id) {
		var str = "The id of the image is: ";
		// alert(str + event.target.id);
		var image = document.getElementById(id);
		var allimage = document.getElementsByClassName("pictures");
		var pic_id = document.getElementById(id).getAttribute('data-id');
		// alert('Id is ' + document.getElementById(id).getAttribute('data-id'));
		for(i=0; i<allimage.length; i++) {
			allimage[i].style.borderColor = "white";
		}
		image.style.borderColor = "green";
		select.setAttribute('data-image', pic_id);
		document.getElementById('image-name-span').style.display = 'inline';
		document.getElementById('image-name').innerHTML = document.getElementById(id).getAttribute('data-name');
		// document.getElementById('insert-message').innerHTML = "Insert Image";
		document.getElementById('insert').style.color = "white";
		document.getElementById('insert').style.color = "white";

	}

	tabLinks = document.getElementsByClassName("tabs");
	// Now get all the tab panel container divs
	tabPanels = document.getElementsByClassName("panel");

	// activate the _first_ one
	displayPanel(tabLinks[0]);

		// attach event listener to links using onclick and onfocus, fire the displayPanel function, return false to disable the link
	for (var i = 0; i < tabLinks.length; i++) {
		tabLinks[i].onclick = function() { 
			displayPanel(this); 
			return false;
		}
		tabLinks[i].onfocus = function() { 
			displayPanel(this); 
			return false;
		}
	}
	
	$(".popup-main").mCustomScrollbar({
		scrollButtons:{enable:true},
		theme:"light-thick",
		scrollbarPosition:"inside"
	});
	
	$(".panel").mCustomScrollbar({
		scrollButtons:{enable:true},
		theme:"dark-thick",
		scrollbarPosition:"inside"
	});
	
	$("#insert").click(function(event) {
		var popup = document.getElementById("popup");
		var id = select.getAttribute('data-image');
		var text = "\\n" + "[[content:image, source:" + id + ", download:true]]" + "\\n";
		typeInTextarea($("textarea"), text);
		popup.style.display="none";
		return false;
	});

	$("#pic-click").click(function () {
		loadPic();			
	});

	$("#submit").click(function () {
		var form = document.getElementById("pic-form");
		var action = "images.php";
		var picspin = document.getElementById("formspin");
		picspin.style.display = 'block';
		// gather form data
		var form_data = new FormData(form);
		// console.log("processing");
		for ([key, value] of form_data.entries()) {
		  console.log(key + ': ' + value);
		}

		var xhr = new XMLHttpRequest();
		xhr.open('POST', action, true);

		xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
		xhr.onreadystatechange = function () {
			if(xhr.readyState == 4 && xhr.status == 200) {
				// var debugdiv = document.getElementById("debug");
				// debugdiv.innerHTML = xhr.responseText;
				console.log('Result: ' + xhr.responseText);
				var json = JSON.parse(xhr.responseText);
				document.getElementById('error').innerHTML = json.message;
				picspin.style.display = 'none';
				setTimeout(clearError, 3000);
				if(json.success == true) {
					$('#insert-before').before(json.pic_div);
					
					// picdiv.style.background = 'url(' + json.now + ')';
					// picdiv.style.backgroundSize = "cover";
				} else {
					
				}
			}
		}
		xhr.send(form_data);

	});


		// when the page loads, grab the li elements

	</script>	
	</body>
	
</html>