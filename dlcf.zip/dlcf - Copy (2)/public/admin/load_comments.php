<?php

require_once('../../includes/initialize.php'); 

// sleep(3);
if(!is_ajax_request()) { exit; }
if(!isset($_GET['page']) || !isset($_GET['post-id']) ) {
	exit;// goback
}


// $query = "SELECT * FROM comments WHERE post={} ORDER BY time DESC LIMIT {$per_page} OFFSET {$off}";
// $comments = query($query);
// $output = "";
// while($comment = fetch_assoc($comments)) {
	// $output.= "<div class=\"comment\">";
	// $output.= "<p class=\"author\">Umukoro Okerefe Wrote:</p>";
	// $output.= "<p class=\"message\">Heres thats  me designing me site right now</p>";
	// $output.= "<p class=\"post-date\">{$date}.</p>";
	// $output.= "</div>";
	
// }
$date = "50th of December 1945: 4:30pm.";
$output = "";

for($i=0; $i<5; $i++) {
	$output.= "<div class=\"comment\">";
	$output.= "<p class=\"author\">Umukoro Okerefe Wrote:</p>";
	$output.= "<p class=\"message\">Heres thats  me designing me site right now</p>";
	$output.= "<p class=\"post-date\">{$date}.</p>";
	$output.= "</div>";	
}

$comments['comments'] = $output;
$finished = true;
$extra = "";
$return_array = ['comments' => $comments['comments'], 'finished' => $finished, 'extra' => $extra];
echo json_encode($return_array);
exit;// goback




// // function load_posts_thumb($id, 	$cont, 			$level, 		edu_op, 	$amount, 	$off, $admin) {
// $message = load_posts_thumb($id, $_GET['cont'], $_GET['level'], $_GET['edu-op'], $per_page, $offset); 
// // $message = load_posts_thumb($id, $_GET['cont'], $_GET['level'], $_GET['edu-op'], 20, 0);
// $extra = ''; 
// $finished = false;
// if($message['finished'] == true) {
	// $extra = "<div class='article posts'>The Stuff Is Bro....</div>";
	// $finished = true;
// }	

// $return_array = ['success' => true, 'message' => $message['message'], 'finished' => $finished, 'extra' => $extra];
// echo json_encode($return_array);
// exit;// goback


?>