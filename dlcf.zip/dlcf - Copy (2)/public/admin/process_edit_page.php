<?php
require_once('../../includes/db_connection.php');
require_once('../../includes/validation_functions.php');
require_once('../../includes/functions.php');
require_once('../../includes/session.php');
print_r($_POST);
if (!$session->is_logged_in()) { exit;}
if (isset($_POST['post_id']) && isset($_POST['content'])) {
	$required_fields = array("post_id", "content");
	// $user_id = $session->$user_id;
	validate_presences($required_fields);
		
	// $fields_with_max_lenghts = array("post_name" => 200);
	// validate_max_lengths($fields_with_max_lenghts);
	// process the form
	
	$time = (int) time();
	if(empty($errors)) {
		// topic. content, created, updated, content_level, content_type, creator_id
		$id = mysql_prep($_POST['post_id']);
		$content = mysql_prep($_POST["content"]);
		$query = "UPDATE posts SET ";
		$query.= "content = '{$content}', updated = {$time} WHERE id={$id}";
		echo  "<br><br><br>" . $query . "<br><br><br>";
		$result = query($query);
		
		// id, time, page_id, admin_id, 
		if ($result) {
			$time = (int) time();
			$query = "INSERT INTO page_updates (time, page_id, admin_id) VALUES ({$time}, {$id}, {$session->user_id})";
			echo $query;
			query($query);
			$return_array = ['success' => true, 'message' => "Page Edited Successfully"];
			echo json_encode($return_array); exit;
		} else {
			//failure
			$return_array = ['success' => false, 'message' => "Page Edit failed."];
			echo json_encode($return_array); exit;
		}
	}
}
// $message="Just messing with you";	
?>