<?php $max_file_size = 1000000000 ?>
<?php
require_once('../../includes/initialize.php'); 
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

sleep(4);

if(!is_ajax_request()) {exit;}
// Some Kind Of VAlidation for the main admin
if(isset($_GET['delete'])){
	$id = mysql_prep($_GET['delete']);
	$query = "DELETE FROM background_frames WHERE id={$id} LIMIT 1";
	query($query);
	
		$sizes = [
		'1' => 320,
		'2' => 479,
		'3' => 767,
		'4' => 1023,
		'5' => 1200,
		'6' => 1400
	];
	foreach ($sizes as $name => $size) {		
		unlink("../images/{$id}_backpic_{$name}.png");
	}

	$return_array = ['success' => true, 'message' => "The Frame Has Been Deleted and will no longer show on the home page"];
	echo json_encode($return_array);
	exit;
}
if(!isset($_FILES['picture'])) {exit;}
if(!isset($_POST['back-text'])) {exit;}
echo "again";
// backgroundImages
// id
// text

$required_fields = array("back-text");
validate_presences($required_fields);

$required_fields = array("picture");
validate_photo($required_fields);
if(!empty($errors)) {
	$return_array = ['success' => false, 'message' => form_errors($errors)];
	echo json_encode($return_array);
	exit;
}
$text = mysql_prep($_POST['back-text']); 
$query = "INSERT INTO background_frames(back_text) VALUES ('{$text}')";
query($query);
$id = last_id();

$old_path = $_FILES['picture']['tmp_name'];
$new_path = '../images/' . $id . '_backpic';

if(move_uploaded_file($old_path, $new_path)) {
	$imagecreate = "imagecreatefrom"  . str_replace('image/', '', getimagesize($new_path)['mime']);
	$resource = $imagecreate($new_path);
	$sizes = [
		'1' => 320,
		'2' => 479,
		'3' => 767,
		'4' => 1023,
		'5' => 1200,
		'6' => 1400
	];
	foreach ($sizes as $name => $size) {
		$scaled = imagescale($resource, $size);
		// imagepng($scaled, $new_path . '_' . $name . '.png', 9);
		imagepng($scaled, "{$new_path}_{$name}.png", 9);
		imagedestroy($scaled);
	}
	unlink($new_path);
	// $return_array = ['success' => true, 'message' => "Th"];
	// echo json_encode($return_array);
	// exit;
}
// echo 'Windiws Widtg is: ' . $_GET['width'];

// if($width >= 1200){
	// $id = 5;
// }
// if($width <= 1199 && >= 1024){
	// $id = 5;	
// }
// if($width <= 1023 && >= 768){
	// $id = 4;
// }
// if($width <= 767 && >= 480){
	// $id = 3;
// }
// if($width <= 479){
	// $id = 2;
// }
// if($width <= 320){
	// $id = 1;	
// }
	

// @media screen and (max-width:320px) {		
// }
// @media screen and (max-width: 479px){

// }
// @media screen and (min-width:480px) and (max-width: 767px){

// }
// @media screen and (min-width:768px) and (max-width: 1023px){
// }
// @media screen and (min-width:1024px) and (max-width: 1199px){	
// }
// @media screen and (min-width:1200px){
	
// }


// // echo "Reached here";
// $image = array('rgba(255,255,255,.4))', 'rgba(255,255,255,.4))', 'rgba(255,255,255,.4))');
// $return_array = ['success' => false, 'imageNo' => 4, 'image' => $image];
// echo json_encode($return_array);
// exit;

// if(isset($_POST['pic-name'])) {
	// if(!isset($_FILES['picture'])) {exit;}
	// $required_fields = array("pic-name");
	// validate_presences($required_fields);

	// if(check_pic_name($_POST['pic-name'])) {
		// $return_array = ['success' => true, 'message' => "The Image File name has been taken"];
		// echo json_encode($return_array);
		// exit;
	// }
	// $required_fields = array("picture");
	// validate_photo($required_fields);
	// if(!empty($errors)) {
		// $return_array = ['success' => false, 'message' => form_errors($errors)];
		// echo json_encode($return_array);
		// exit;
	// }
?>