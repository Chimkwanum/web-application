<?php  require_once('../../includes/session.php'); 
 require_once('../../includes/db_connection.php');
 require_once('../../includes/functions.php');
 require_once('../../includes/validation_functions.php');
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

sleep(3);

if(!is_ajax_request()) { exit; }


require_once('../../includes/validation_functions.php');
if(!isset($_POST['coursename']) && !isset($_POST['shortname']) && !isset($_POST['years'])) {
	$return_array = ['success' => false, 'error' => "The transaction can't be done"];
	echo json_encode($return_array);
	exit;
}
$required_fields = array("coursename", "shortname");
validate_presences($required_fields);
		
$fields_with_max_lenghts = array("coursename" => 50, "shortname" => 20);
validate_max_lengths($fields_with_max_lenghts);
$coursename = mysql_prep($_POST['coursename']);
$shortname = mysql_prep($_POST['shortname']);
$years = (int) mysql_prep($_POST['years']);
if(empty($errors)) {
	$query = "INSERT INTO courses ( ";
	$query.= "coursename, years, shortname";
	$query.= ") VALUES ( ";
	$query.= "'{$coursename}', {$years}, '{$shortname}')";
	// echo $query;
	$result = query($query);
	if($result) {
		$return_array = ['success' => true, 'message' => "The Course was registered successfully"];
		echo json_encode($return_array);
		exit;
	} else {
		$return_array = ['success' => false, 'error' => "The transaction can't be done"];
		echo json_encode($return_array);
		exit;
	}
} else {
	$errors['success'] = false;
	$errors['error'] = "The transaction can't be done";
	echo json_encode($errors);
	exit;
}
?>