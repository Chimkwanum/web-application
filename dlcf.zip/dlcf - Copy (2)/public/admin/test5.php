<!DOCTYPE html PULIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
	
<html lang = "en">
	<head>		
		<meta charset="UTF-8">
	   
		<meta name="viewport" content="width=device=width, initial-scale = 1.0">
		<link rel="stylesheet" href="main.css">
		<title></title>
		<style>
		.admin-name{
			float: left;
			line-height: 50px;
			background: blue;
			margin:auto auto;
			width: 15rem;
			margin-bottom: 1rem;
		}
		.admins-pic{
			float: left;
			height: 3.125rem;
			width: 3.125rem;
			background: url(building-joy-planning-plans.jpg);
			background-size: cover;
		}
		.radio{
			height: 3.125rem;
			margin: auto auto;
			padding: auto auto;
			width: 2rem;
			float: left;
			background-color: red;
		}
		#admins-container{			
			margin: 0 auto;
			clear: both;
		}
		.admin-container{
			margin: 1rem auto;
			
			width: 24rem;
			clear: both;
		}
		.radio-cover{
			height: 3.125rem;
			float: left;
			width: 2rem;
			margin: auto auto;
			background-color: green;
		}
		
		</style>
	</head>
	<body>
	<?php
	$name = "float: left;
	line-height: 50px;
	background: blue;
	margin:auto auto;
	width: 15rem;";
	
	$pic = "float: left;
	height: 50px;
	width: 50px;
	background: url(building-joy-planning-plans.jpg);
	background-size: cover;";
	
	// while($admin = fetch_assoc($admins)) {
		// if ($admin['id'] == $id) {continue;}
		// $output.= "<div class=\"admin-container\">";
		// $output.= "<div class=\"admins-label\"><input type=\"radio\" name=\"admin_id\" id=\"css\" value=\"{$admin['id']}\"></div>";
		// $output.= "<label for=\"{$admin['id']}\" class=\"admin-name\" style=\"{$name}\" >{$admin['email']}</label>";
		// $output.= "<div class=\"admins-pic\" style=\"{$pic}\" ></div>";
		// $output.= "</div>";
	?>
	$output.= "<div id=\"admins-container\">";
	
	$output.= "<div class=\"admin-container\">";
	$output.= "<div class=\"radio-cover\"><input type=\"radio\" name=\"admin_id\" class=\"radio\" value=\"{$admin['id']}\"></div>";
	$output.= "<label for=\"{$admin['id']}\" class=\"admin-name\">{$admin['email']}</label>";
	$output.= "<div class=\"admin-pic\"></div>";
	$output.= "</div>";
	
	</div>
	
	<div style="height: 200px; overflow:auto; margin 0 auto; width: content;">
	<div id="admins-container"> 
	
	<div class="admin-container">
	<div class="radio-cover"><input type="radio" name="admin_id" class="radio" value="{$admin['id']}"></div>
	<label for="id" class="admin-name" style="" >okerefe@yahoo.com</label>
	<div class="admin-pic" style="" ></div>
	</div>
	<div class="admin-container">
	<div class="radio-cover"><input type="radio" name="admin_id" class="radio" value="{$admin['id']}"></div>
	<label for="id" class="admin-name" style="" >okerefe@yahoo.com</label>
	<div class="admin-pic" style="" ></div>
	</div>
	<div class="admin-container">
	<div class="radio-cover"><input type="radio" name="admin_id" class="radio" value="{$admin['id']}"></div>
	<label for="id" class="admin-name" style="" >okerefe@yahoo.com</label>
	<div class="admin-pic" style="" ></div>
	</div>
	<div class="admin-container">
	<div class="radio-cover"><input type="radio" name="admin_id" class="radio" value="{$admin['id']}"></div>
	<label for="id" class="admin-name" style="" >okerefe@yahoo.com</label>
	<div class="admin-pic" style="" ></div>
	</div>
	
	</div>
	</div>
	
	</body>
</html>