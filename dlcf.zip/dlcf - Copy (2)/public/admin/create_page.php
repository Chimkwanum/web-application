<?php
require_once('../../includes/initialize.php');
// if (!$session->is_logged_in()) { redirect_to('../index.php?landingsite=logfile.php');}
?>
<!DOCTYPE HTML>
<html lang = "en">
	<head>
		<link rel="stylesheet" href="../stylesheets/jquery.mCustomScrollbar.min.css">
		<link rel="stylesheet" href="stylesheets/main.css">
		<link rel="stylesheet" href="admin.css">
	<style>
		html {
			background: red;
		}
		.pictures{
			height: 100px;
			width: 100px;
			border: 10px solid white;
			background: red;
			margin-left: .2rem;
			margin-top: .4rem;
			float: left;
		}
		.pic-size{
			height: 100px;
			width: 100px;
			margin-left: .2rem;
			margin-top: .4rem;
			float: left;
		}
		#load{
			height: 100px;
			width: 100px;
			background: red;
			margin-left: .2rem;
			margin-top: .4rem;
			float: left;
		}
		.tabs:hover{
			background: red; 
			cursor:pointer;
		}

		.tabs.active{
			background: #2e2e2e; /* old browsers */
			cursor:pointer;
		}


		a{
			text-decoration: none;
			color: white;
			margin: 0px;
		}
		.panel{
			height: 100%;
			background: #2e2e2e;
			color: white;
			font-family: fantasy;
			margin: 0 auto;
			margin-bottom: 50px;
			width: 100%;
		}
		#image-section{
			margin: 0 auto;
			width: 90%;
		}
		#tabs-cover {
			display: block;
			align-content: left;
			text-align: left;
			clear: both;
			margin-bottom: 0px;
			width: 98%;
			float: left;
		}
		#panels-div {
			clear: both;
			width: 96%;
			margin: 0 auto;
			height: 85%;
			background: #2e2e2e;
		}
		
		#tabPanel2 {
		}
		.load-spin{
			height: 100%;
			width: 100%;
			background: url(spinner.gif);
			background-size: cover;
			display: none;
		}
		.popup-main {
			height: 90%;
			width: 750px;
			margin-top: 2rem;
			
		}
		#tab1 {
		}
		#tab2 {
		}
		.tabs, .insert{
			display: inline-block;
			margin: 0 auto;
			cursor: pointer;
			/*background: #2e2e2e;*/
			color: white;
			background: purple;
			line-height: 2rem;
			margin: 0px;
			padding: .4rem;
			word-wrap: break-word;
			border-top-left-radius: .4rem;
			border-top-right-radius: .4rem;
		}
		#insert{
			background: red;
			float: right;
			color: red;
		}
		#insert:hover{			
			background: green;
		}

		#formspin {
			background : url(spinner.gif);
			background-size : cover;
			display: none;
		}
		#image-name-span{
			margin-left: 3rem;
			display: none;
		}
		.image-buttons{
			background: black;
			border-radius: .2rem;
			border-color: black;
			color: white;
		}
		#pic-name{
			font-size: 1rem;
			border-width: 2px;
			border-color: black;
			padding: 1px;
			margin-bottom: 10px;
			border-radius: 5px;
			line-height: 2rem;
			font-family: inherit;
			width: 100%;
			font-size: 1rem;
			color: white;
			background: rgb(20,20,20);
		}
		#pic-name:focus{
			background: white;
			color: rgb(20,20,20);
		}
		#image-submit{
			text-align: left;
			float: left;
		}
		#image-submit:focus{
			background: purple;	
			color: rgb(20,20,20);
		}
	
	</style>
	<script>
	function typeInTextarea(el, newText) {
		var start = el.prop("selectionStart")
		var end = el.prop("selectionEnd")
		var text = el.val()
		var before = text.substring(0, start)
		var after  = text.substring(end, text.length)
		el.val(before + newText + after)
		el[0].selectionStart = el[0].selectionEnd = start + newText.length
		el.focus()
	}
	</script>
	</head>
	<body>
	<section id="popup"></section>
		<div id = "header">
		<h1>Some sites</h2>
		</div>
		<?php //print_r($errors);?>
		<?php if (!empty($message)){echo htmlentities($message);}?>

		<div id = "main">
		<div id = "navigation">

		</div>
		<div id = "page">

		<h2> Create Post: </h2>
		<form action = "create_page.php" method = "post" id="form">
		Name of Post:
		<input type = "text" name = "post_name" value = "" /><br />
		Post Type:
		<select name="post_type" id="page-type">
		<option value="edu">Educational Posts</option>
		<option value="announce">Announcement Posts</option>
		<option value="spirit">Spiritual Posts</option>
		</select><br>
		
		<div id="level">Level:
		<select name="level">
		<option value="1">100 Level</option>
		<option value="2">200 Level</option>
		<option value="3">300 Level</option>
		<option value="4">400 Level</option>
		</select></div><br />
		<button id="addimage" onclick="return false";>Add image</button><br>
		Content:<br />
		<div style="/*background:url(images/kumuyi.jpg); background-size:cover;*/">
		<div style="/*background: rgba(76,67,65,0.4);*/">
		<textarea name="content" style="background:inherit;"rows="20" cols="40"></textarea>
		</div>
		</div>
		<br />
		<input type = "submit" name = "submit" value = "Create Page" id="submit"/>
		</form>
		<div id="error" style="width: 100%;"></div>
				<div id="debug"></div>



		</div>
		</div>

		<div id = "footer">Copyright <?php echo date("Y"); ?>, Widget Corp
		</div>
		
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="../javascripts/jquery.js"></script>
	<script src="../javascripts/jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="../javascripts/create_page.js"></script>
	</body>
	
</html>
<?php if(isset($connection)) {mysqli_close($connection); }?>
A post: .....
Topic of post
Content of post
Pictures present in post
Id of admin who posted


Created 
Last edited
email, date_create, admin_stats