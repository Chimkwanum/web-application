<?php $max_file_size = 1000000000 ?>
<?php
require_once('../../includes/initialize.php'); 
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}

sleep(3);

// if(!is_ajax_request()) {exit;}

if(isset($_POST['pic-name'])) {
	if(!isset($_FILES['picture'])) {exit;}
	$required_fields = array("pic-name");
	validate_presences($required_fields);

	if(check_pic_name($_POST['pic-name'])) {
		$return_array = ['success' => true, 'message' => "The Image File name has been taken"];
		echo json_encode($return_array);
		exit;
	}
	$required_fields = array("picture");
	validate_photo($required_fields);
	if(!empty($errors)) {
		$return_array = ['success' => false, 'message' => form_errors($errors)];
		echo json_encode($return_array);
		exit;
	}
	$id = 1;
	$time = (int) time();
	$name = mysql_prep($_POST['pic-name']);
	// $query = "INSERT INTO pictures (name, upload_id, time) VALUES ('{$name}', {$session->user_id}, {$time})";
	$query = "INSERT INTO pictures (name, upload_id, time) VALUES ('{$name}', 1, {$time})";
	$result = query($query);
	if(!$result){exit;}
	$tmp_file = $_FILES['picture']['tmp_name'];
	$id = mysqli_insert_id($connection);
	$target_file = '../post_pics/' . $id . '_postpic';
	$url = $target_file . '_1.png'; 
	$pic_div = "<div class=\"pictures\" data-name=\"{$_POST['pic-name']}\" style=\"background: url({$url}), url(spinner.gif);background-size: cover;\"  id=\"pic_{$id}\" data-id=\"{$id}\" onclick=\"picClick('pic_{$id}')\"></div>";
	if(move_pic($tmp_file, $target_file)) {
		$return_array = ['success' => true, 'message' => "The Image was uploaded", "pic_div" => $pic_div];
		echo json_encode($return_array);	
		exit;// goback
	} else {
		$return_array = ['success' => false, 'message' => "The Image upload failed"];
		echo json_encode($return_array);
		exit;// goback
	}

}

$string_con = <<<EOT
<section style="height: 80%; width: 80%; overflow: auto; margin: 0 auto;">
	<div id="pic" style="height: 100px; width:100px;"></div>
	<form method = "post" enctype="multipart/form-data" id="pic-form">
		<input type = "hidden" name = "MAX_FILE_SIZE" value = "{$max_file_size}"/>
		<input type = "file" name = "picture" />
		<input type = "text" name = "pic-name" id="pic-name" placeholder="Name Of Picture"/><br />
		<button id="submit" class="submit" value = "" onclick="return false";> Upload</button>
		<br><button id="select" onclick="return false";>Select Image</button><br>
		<section style="overflow:auto; clear:both;">
		</section>
		<br><button id="insert" onclick="return false";>Insert Image</button><br>
		
	</form>
	
	<div id="debug"></div>
</section>
EOT;

$string_script = <<<EOT
var select = document.getElementById("select");

$("#submit").click(function () {
alert("submitted");
var form = document.getElementById("pic-form");
var action = "images.php";
var picdiv = document.getElementById("pic");
picdiv.style.background = "url(spinner.gif)";
picdiv.style.backgroundSize = "cover";
// gather form data
var form_data = new FormData(form);
// console.log("processing");
for ([key, value] of form_data.entries()) {
  console.log(key + ': ' + value);
}

var xhr = new XMLHttpRequest();
xhr.open('POST', action, true);

xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
xhr.onreadystatechange = function () {
	if(xhr.readyState == 4 && xhr.status == 200) {
		var debugdiv = document.getElementById("debug");
		debugdiv.innerHTML = xhr.responseText;
		console.log('Result: ' + xhr.responseText);
		var json = JSON.parse(xhr.responseText);
		if(json.success == true) {
			alert(json.now);
			picdiv.style.background = 'url(' + json.now + ')';
			picdiv.style.backgroundSize = "cover";
		}
	}
}
xhr.send(form_data);

});

$(".pictures").click(function(event) {
	var str = "The id of the image is: ";
	// alert(str + event.target.id);
	var image = document.getElementById(event.target.id);
	var allimage = document.getElementsByClassName("pictures");
	for(i=0; i<allimage.length; i++) {
		allimage[i].style.borderColor = "white";
	}
	image.style.borderColor = "green";
	select.setAttribute('data-image', event.target.id);
});


$("#insert").click(function(event) {
	var popup = document.getElementById("popup");
	var id = select.getAttribute('data-image');
	var text = "\\n" + "[[content:image, source:" + id + ", download:true]]" + "\\n";
	typeInTextarea($("textarea"), text);
	popup.style.display="none";
	return false;
});


EOT;

$string = ['message' => $string_con, 'script' => $string_script];

// $return_array = ['success' => true, 'message' => $string];
// echo json_encode($return_array);
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
$text = "<p>Once you master the basics of authoring HTML, you&rsquo;ll need focus on what your next steps will be. If you&rsquo;re an aspiring web designer, you&rsquo;ll need to dive deeper into HTML, CSS, and JavaScript. If you&rsquo;re maintaining a corporate or personal site through a CMS, you&rsquo;ll need to focus on how the CMS works, and the most efficient ways to edit and maintain content. On this page I&rsquo;ll give you some basic advice on how to approach learning web design and point you towards additional resources that can help you along the way.</p>";

		
		
$string_con = <<<EOT
	<section id="image-section" style="width: 80%; height: 90%; display: none; margin-top: 1rem;" class="popup-main"  data-mcs-theme="dark-thick">
      <div id= "tabs-cover" style="padding-left: 2%;">
        <div id="tab1" class="tabs"><a href="#tabPanel1">
			Upload Image
		</a></div>
        <div id="tab2" class="tabs"><a href="#tabPanel2">
			Select From Uploaded
		</a></div>
		<span id="image-name-span"><b>Image Name:</b> <span id="image-name"></span></span>
		 <div data-image="0" id="insert" class="insert">
			<span id="insert-message" style="display: hidden;">Insert Image</span><span id="img-id"></span>
		</div>
	</div>
	<div id='panels-div'>
	<div id="tabPanel1" class="panel" style="height: 28.5rem; padding: 2%;  margin: 0 auto;overflow: auto;">
	<form method = "post" enctype="multipart/form-data" id="pic-form" class="pic-size" style="margin-right: 1.2rem;">
		<input type = "hidden" name = "MAX_FILE_SIZE" value = "{$max_file_size}"/>
		<input type = "file" name = "picture" class=""/><br>
		<input type = "text" name = "pic-name" id="pic-name" placeholder="Name Of Pic.."/><br />
		<button id="image-submit" class="submit image-buttons" value = "" onclick="return false";> Upload</button><br>
		<div id="error" style='color: white;'></div>
	</form>	
		<div id="insert-before"></div>
		<div id="formspin" class="pic-size"></div>
		<!--<br><button id="insert" onclick="return false"; data-image="0">Insert Image</button><br>-->
		
	</div>
	
	<div id="tabPanel2" class="panel" style="height: 28.5rem; overflow: auto; margin: 0 auto;content-align: center; padding: 2%;">
		<div id="load">
		<div id="load-button">
		<div id="pic-click"  data-page="0">Load More...</div>
		</div>
		<div id="picspin" class="load-spin"></div>
		
		</div>

	</div>
	</div>
	<button class="image-buttons"style="height:1.5rem; float:right;color: red; cursor: pointer;" onclick="closePopup();">Close</button>
	</section>
EOT;
		
$string_script = <<<EOT
	setTimeout(slideDown, 1000);
	function slideDown() {		
		$("#image-section").slideDown(1000);
	}
	var select = document.getElementById("insert");
	
	function loadPic() {
		// alert('start');
		document.getElementById('load-button').style.display = 'none';
		document.getElementById('picspin').style.display = 'block';
		var page = parseInt(document.getElementById('pic-click').getAttribute('data-page')) + 1;
		// if(id == 'edu') {// }
		
		var url = 'load_pic.php?page=' + page;
		
		var xhr = new XMLHttpRequest();
		xhr.open('GET', url, true);
		xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
		xhr.onreadystatechange = function () {
			if(xhr.readyState == 4 && xhr.status == 200) {
				console.log(xhr.responseText);
				// document.getElementById('debug').innerHTML = xhr.responseText;
				var json = JSON.parse(xhr.responseText);
				if(json.success == true) {
				document.getElementById('pic-click').setAttribute('data-page', page);
				var temp = document.createElement('div');
				// temp.setAttribute('class', 'article');
				temp.setAttribute('id', 'now');
				temp.innerHTML = json.message;
				temp.style.display = 'none';
				$('#load').before(temp);
				$('#now').toggle(1000);
				temp.setAttribute('id', 'later');
				if(json.finished == true) {
					// document.getElementById('load').innerHTML = "";
					document.getElementById('load-button').innerHTML = json.extra;
					document.getElementById('picspin').style.display = 'none';
					document.getElementById('load-button').style.display = 'block';
						// document.getElementById('load').innerHTML = json.extra;
				} else {
					document.getElementById('load-button').style.display = 'block';
					document.getElementById('picspin').style.display = 'none';
				}
					
				}
			}
		}
		xhr.send();	
		
	}
	
	function displayPanel(tabToActivate) {
		// go through all the <li> elements
		for (var i = 0; i < tabLinks.length; i++) {
			if (tabLinks[i] == tabToActivate) {
				// if it's the one to activate, change its class
				tabLinks[i].classList.add("active");
				// and display the corresponding panel
				tabPanels[i].style.display = "block";
			} else {
				// remove the active class on the link
				tabLinks[i].classList.remove("active");
				// hide the panel
				tabPanels[i].style.display = "none";
			}
		}
	}
	
	function clearError() {
		document.getElementById('error').innerHTML = '';
	}

	function picClick(id) {
		var str = "The id of the image is: ";
		// alert(str + event.target.id);
		var image = document.getElementById(id);
		var allimage = document.getElementsByClassName("pictures");
		var pic_id = document.getElementById(id).getAttribute('data-id');
		// alert('Id is ' + document.getElementById(id).getAttribute('data-id'));
		for(i=0; i<allimage.length; i++) {
			allimage[i].style.borderColor = "white";
		}
		image.style.borderColor = "green";
		select.setAttribute('data-image', pic_id);
		document.getElementById('image-name-span').style.display = 'inline';
		document.getElementById('image-name').innerHTML = document.getElementById(id).getAttribute('data-name');
		// document.getElementById('insert-message').innerHTML = "Insert Image";
		document.getElementById('insert').style.color = "white";
		document.getElementById('insert').style.color = "white";

	}

	tabLinks = document.getElementsByClassName("tabs");
	// Now get all the tab panel container divs
	tabPanels = document.getElementsByClassName("panel");

	// activate the _first_ one
	displayPanel(tabLinks[0]);

		// attach event listener to links using onclick and onfocus, fire the displayPanel function, return false to disable the link
	for (var i = 0; i < tabLinks.length; i++) {
		tabLinks[i].onclick = function() { 
			displayPanel(this); 
			return false;
		}
		tabLinks[i].onfocus = function() { 
			displayPanel(this); 
			return false;
		}
	}
	
	$(".popup-main").mCustomScrollbar({
		scrollButtons:{enable:true},
		theme:"light-thick",
		scrollbarPosition:"inside"
	});
	
	$(".panel").mCustomScrollbar({
		scrollButtons:{enable:true},
		theme:"dark-thick",
		scrollbarPosition:"inside"
	});
	
	$("#insert").click(function(event) {
		var popup = document.getElementById("popup");
		var id = select.getAttribute('data-image');
		var text = "\\n" + "[[content:image, source:" + id + ", download:true]]" + "\\n";
		typeInTextarea($("textarea"), text);
		popup.style.display="none";
		return false;
	});

	$("#pic-click").click(function () {
		loadPic();			
	});

	$("#image-submit").click(function () {
		var form = document.getElementById("pic-form");
		var action = "images.php";
		var picspin = document.getElementById("formspin");
		picspin.style.display = 'block';
		// gather form data
		var form_data = new FormData(form);
		// console.log("processing");
		for ([key, value] of form_data.entries()) {
		  console.log(key + ': ' + value);
		}

		var xhr = new XMLHttpRequest();
		xhr.open('POST', action, true);

		xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
		xhr.onreadystatechange = function () {
			if(xhr.readyState == 4 && xhr.status == 200) {
				// var debugdiv = document.getElementById("debug");
				// debugdiv.innerHTML = xhr.responseText;
				console.log('Result: ' + xhr.responseText);
				var json = JSON.parse(xhr.responseText);
				document.getElementById('error').innerHTML = json.message;
				picspin.style.display = 'none';
				setTimeout(clearError, 3000);
				if(json.success == true) {
					$('#insert-before').before(json.pic_div);
					
					// picdiv.style.background = 'url(' + json.now + ')';
					// picdiv.style.backgroundSize = "cover";
				} else {
					
				}
			}
		}
		xhr.send(form_data);

	});


EOT;
		
		
		
		
$string = ['message' => $string_con, 'script' => $string_script];
		
$return_array = ['success' => true, 'message' => $string];
echo json_encode($return_array);

// echo $string;


// require_once('../../includes/validation_functions.php');
// if (isset($_GET['email']) && isset($_GET['rank'])){
	// if (!check_email_regex($_GET['email'])) {
		// $return_array = ['success' => false, 'error' => "The Email is not valid"];
		// echo json_encode($return_array);
		// exit;
	// }
// }


?>