<?php

require_once('../../includes/initialize.php'); 
sleep(3);
if(!is_ajax_request()) { exit; }
// if (!$session->is_logged_in()) {exit;}

if(!isset($_GET['page'])) {
		exit;
}

$per_page = 5;
$page = (int) $_GET['page'];
$off_set = (($page - 1) * $per_page);

$pictures = load_all_pictures($per_page, $off_set);
$extra = ''; 
$finished = false;
if($pictures['finished'] == true) {
	$extra = "<div class=\"pic-size\">Pictures Is Finished Boy</div>";
	$finished = true;
}

$return_array = ['success' => true, 'message' => $pictures['pictures'], 'finished' => $finished, 'extra' => $extra];
echo json_encode($return_array);
exit;


$return_array = ['success' => true, 'message' => $message['message'], 'finished' => $finished, 'extra' => $extra];
echo json_encode($return_array);
exit;// goback


?>