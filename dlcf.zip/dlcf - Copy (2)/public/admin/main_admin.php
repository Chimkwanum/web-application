<?php $max_file_size = 1000000000 ?>
<?php  require_once('../../includes/initialize.php');?> 
<?php
// if (!$session->is_logged_in()) { redirect_to('login.php?landingsite=logfile.php');}
?>

<?php  require_once('../../includes/validation_functions.php');?> 
	<?php
	if (isset($_POST['submit'])){
		$username = mysql_prep($_POST["username"]);
		$password = password_encrypt($_POST["password"]);

		$required_fields = array("username", "password");
		validate_presences($required_fields);
		
		$fields_with_max_lenghts = array("username" => 30);
		validate_max_lengths($fields_with_max_lenghts);
		
		if(empty($errors)){
			$query = "INSERT INTO admins ( ";
			$query.= "username, hashed_password";
			$query.= ") VALUES ( ";
			$query.= "'{$username}', '{$password}'";
			$query.= ")";
			$result = query($query);
			if ($result) {
				//success
				$_SESSION["message"] = "Admin Profile Created.";
				redirect_to ("manage_admins.php");
			}else{
				//failure
				$message = "Admin Profile Creation failed.";

			}

			
			}
	}

	
	
?>
<!DOCTYPE HTML>
<html lang = "en">
	<head>
		<link rel="stylesheet" href="stylesheets/main.css">
	</head>
	<style>
	#product-spinner-div{
		background-image: url(<?php echo ASSETS;?>spinner.gif);
	}
	</style>
	<body>
		<section>
		<h2>Create Admin</h2>
		<form action= "" method = "post" id="new-admin-form">
		<p>Email:
				<input type="text" id="admin_email" value = "" />
				<br />
		</p>
		<p>Admin Rank:<br />
		<select id="admin_rank"> 
			<option value="1">Leader</option>
			<option value="2">Worker</option>
		</select>
		<button class="submit" id="create-admin-submit" onclick= "return false";>Create New Admin</button>
		</form>
		<div id="notification"> </div>
		</section>
		<section>
		<h2>Pending Admins</h2>
		
		<?php
		$query = "SELECT * FROM pending_admins";
		$results = query($query);
		
		echo "<ul>";
		while($result = fetch_assoc($results)) {
			// print_r($results);	
			echo "<li>" . $result['email'] . "</li>";
			// echo "There is pending transactions";

		}
		
		echo "</ul>";
		?>
		Refresh Page to see new pending admins.
		</section>
		
		<section>
		Add Courses:
		<form action= "" method = "post" id="course-form">
		Course Name:<br />
		<input type="text" name="coursename"/><br />
		Course Short Name<br />
		<input type="text" name="shortname"/><br />
		Number OF years:<br />
		<input type="number" name="years"/><br />
		<button class="submit" id="create-course-button" onclick= "return false";>Create New Admin</button>
		</form>
		<div id="error"> </div>
		</section>
		<section>
		<h2>All courses</h2>
		<?php
		$query = "SELECT * FROM courses";
		$results = query($query);
		
		echo "<table>";
		echo "<th>Course Name</th>";
		echo "<th>Short Name</th>";
		echo "<th>No of years </th>";
		while($result = mysqli_fetch_assoc($results)) {
			// print_r($results);	
			echo "<tr>";
			echo "<td>" . $result['coursename'] . "&nbsp;" . "</td>";
			echo "<td>" . $result['shortname'] . "&nbsp;" . "</td>";
			echo "<td>" . $result['years'] . "&nbsp;" . "</td>";
			echo "</tr>";
			// echo "There is pending transactions";

		}
		
		echo "</table>";
		?>
		Refresh Page to see new pending admins.
		</section>
		
		<section>
		<?php
		$query = "SELECT * FROM background_frames ORDER BY id DESC";
		$frames = query($query);
		while($frame = mysqli_fetch_assoc($frames)) {
			$id = $frame['id'];
			$url = IMAGE_URL . $id . "_backpic_1.png";
			echo "<div class=\"location-div\" id=\"frame_{$id}\"style=\"height: 350px; width: 400px;\">";
			echo "<div class=\"location-pics\" style=\"background:url({$url}); background-size: cover;height: 70%;\"></div>";
			echo "<div class=\"location-desc\" style=\"height: 15%;background: red;\">";
			echo "<p style=\"margin:0; word-wrap: break-word;\">{$frame['back_text']}</p>";
			echo "</div>";
			echo "<button style=\"float: right; height:10%;\" onclick=\"deleteFrame({$id})\">Delete Frame</button>";
			echo "</div>";
			echo "<div id=\"message_{$id}\"></div>";
		}

		
		?>
			<!--<div class="location-div" style="height: 350px; width: 400px;">
				<div class="location-pics" style="background:url(<?php echo IMAGE_URL . 'pic11.jpg'?>); background-size: cover;height: 70%;"></div>
				<div class="location-desc" style="height: 15%;background: red;">
				<p style="margin:0; word-wrap: break-word;">This  Is Just Some random text That Will dis play the text area of the stuff</p>
				<input type="text" style="height: 100%; width: 100%;"name="shortname"/>
				</div>
				<button style="float: left; height:10%;">Choose File</button>
				<button style="float: left; height:10%;">Save Frame</button>
				<button style="float: left; height:10%;">Delete Frame</button>
				<button style="float: right; height: 10%;">Edit Details</button>
			</div>
		
		
			<div class="location-div" style="height: 350px; width: 400px;">
				<div class="location-pics" style="background:url(<?php echo IMAGE_URL . 'pic11.jpg'?>); background-size: cover;height: 70%;"></div>
				<div class="location-desc" style="height: 15%;background: red;">
				<p style="margin:0; word-wrap: break-word;">This  Is Just Some random text That Will dis play the text area of the stuff</p>
				<!--<input type="text" style="height: 100%; width: 100%;"name="shortname"/>
				</div>
				<button style="float: left; height:10%;">Choose File</button>
				<button style="float: left; height:10%;">Save Image</button>
				<button style="float: left; height:10%;">Delete Frame</button>
				<button style="float: right; height: 10%;">Edit Details</button>
			</div>-->
		
		Add Background Theme<br>
		Select Image:<br>
		<form method = "post" enctype="multipart/form-data" id="add-form">
			<input type = "hidden" name = "MAX_FILE_SIZE" value = "<?php echo $max_file_size; ?>"/><br />
			Update Profile Pic:<br>
			<div style="height: 200px; width: 200px; background: violet;"></div><br>
			<input type = "file" name = "picture"/><br>
			<textarea name="back-text" id="about-me" class="edit-form" rows="5" cols="40" placeholder="aaa"></textarea><br />		
			<input class="submit" type="submit" name="submit" id="save-frame" value="Save Background Slide"/><br />
		</form>
		<div id="error"></div>
		</section>
		<br><br><br><br><br>
	</body>
</html>
		
	<script src="../javascripts/jquery.js"></script>
    <script src="../javascripts/main_admin_script.js"></script>
<?php if(isset($connection)) {mysqli_close($connection); }?>











