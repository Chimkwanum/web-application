<?php

require_once('../../includes/initialize.php'); 

sleep(3);
if(!is_ajax_request()) { exit; }
if(!isset($_GET['cont']) || !isset($_GET['page']) || !isset($_GET['user']) || !isset($_GET['level']) || !isset($_GET['edu-op'])) {
	exit;// goback
}
if($_GET['user'] == 'admin') {	
	if (!$session->is_logged_in()) {exit;}
	$id = $session->user_id;
} else {
	$id = NULL;
}
$per_page = 4;
$page = (int) $_GET['page'];
$offset = (($page - 1) * $per_page);

// function load_posts_thumb($id, 	$cont, 			$level, 		edu_op, 	$amount, 	$off, $admin) {
$message = load_posts_thumb($id, $_GET['cont'], $_GET['level'], $_GET['edu-op'], $per_page, $offset); 
// $message = load_posts_thumb($id, $_GET['cont'], $_GET['level'], $_GET['edu-op'], 20, 0);
$extra = ''; 
$finished = false;
if($message['finished'] == true) {
	$extra = "<div class='article posts'>The Stuff Is Bro....</div>";
	$finished = true;
}	

$return_array = ['success' => true, 'message' => $message['message'], 'finished' => $finished, 'extra' => $extra];
echo json_encode($return_array);
exit;// goback


?>