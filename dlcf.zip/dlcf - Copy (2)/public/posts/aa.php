	<?php
	require_once('../../includes/functions.php');
	echo generate_post(12);
	
	?>