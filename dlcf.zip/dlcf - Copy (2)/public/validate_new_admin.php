<?php
$username = "";
$email = "";
$first_name = "";
$last_name = "";
$max_file_size = 10000000000000;
require_once('../includes/db_connection.php');
require_once('../includes/functions.php');
require_once('../includes/validation_functions.php');
require_once('../includes/session.php');

// print_r($_POST);
// print_r($_FILES);

if(isset($_POST['submit'])) {
	if(!isset($_SESSION['pending_admin']['email'])) {redirect_to("index.php");}
	if(!isset($_SESSION['pending_admin']['rank'])) {redirect_to("index.php");}
	
	// new
	// photo::validate_admin_photo();
	$required_fields = array("first_name", "last_name", "password", "confirm-password", "courseid", "level", "aboutme");
	validate_presences($required_fields);
	confirm_level_course();
	$fields_with_max_lengths = array("first_name" => 50, "last_name" => 50, "password" => 30, "confirm-password" => 30);
	validate_max_lengths($fields_with_max_lengths);
	// $required_file_fields = array("profile-pic");
	// validate_file($required_file_fields);
	// $photo_fields = array("profile-pic");
	// validate_photo($photo_fields);
	
	
	confirm_password();
 	if(empty($errors)) {
		// $tmp_file = $_FILES['profile-pic']['tmp_name'];
		// $target_file = "admin_pics/" . admin_pic_name();
		// if (move_pic($tmp_file, $target_file)) {
		$profile_pic = "aaaaa";
		$time = (int) time();
		// $sex = (int) mysql_prep($_SESSION['sex']);
		$level = (int) mysql_prep($_POST['level']);
		$course = (int) mysql_prep($_POST['courseid']);
		$email = mysql_prep($_SESSION['pending_admin']['email']);
		$rank = mysql_prep($_SESSION['pending_admin']['rank']);
		$first_name = mysql_prep($_POST['first_name']);
		$last_name = mysql_prep($_POST['last_name']);
		$password = password_encrypt($_POST['password']);
		$about_me = mysql_prep($_POST['aboutme']);
		// image id = mysqlcount plus 1
		$query = "INSERT INTO admins ( ";
		$query.= "email, first_name, last_name, hashed_password, date_created, admin_rank, ";
		$query.= "level, course, about_me";
		$query.= ") VALUES (";
		$query.= "'{$email}', '{$first_name}', '{$last_name}', '{$password}', {$time}, {$rank}, ";
		$query.= "{$level}, {$course}, '{$about_me}')";
		// echo $query . "<br /><br /><br />";
		$result = query($query);	
		if($result) {
			$id = mysqli_insert_id($connection);
			// if($sex == 1) {'
				// $image_path = male
			// } else {
				// $image_path = female
			// }
			$image_path = "admin_pics/default.png";
			$image = imagecreatefromjpeg($image_path);
			$image_path = "admin_pics/" . $id . "_admin_profile";
			imagepng($image, $image_path);
			process_image($image_path);
			unset($_SESSION['pending_admin']['email']);
			unset($_SESSION['pending_admin']['rank']);
		} else {
			// Something happened;
		}
		$query = "DELETE FROM pending_admins WHERE email = '{$email}' LIMIT 1";
		query($query);
		$session->message( "Dear " . $email . "Your Profile has been created, you can now Login... GRACE");
		redirect_to("index.php");
		// } else {
			// $errors['File'] = "The file upload failed, possibly due to incorrect permissions on the upload folder.";
		// }
		
		
	} else {
		// print_r($errors);
	}
	
}

// Validation for link from email
if (isset($_GET['email']) && isset($_GET['rand'])) {
	
	if(!check_email_regex($_GET['email'])) {redirect_to("index.php");}
	$email = mysql_prep($_GET['email']);
	$rand = mysql_prep($_GET['rand']);
	if($pending_admin = validate_pending_admin($email, $rand)) {
		$_SESSION['pending_admin']['email'] = $pending_admin['email'];
		$_SESSION['pending_admin']['rank'] = $pending_admin['rank'];
		redirect_to("validate_new_admin.php");
	} else {
		redirect_to("index.php");
	}
} else {

}

if(!isset($_SESSION['pending_admin']['email'])) {redirect_to("index.php");}
if(!isset($_SESSION['pending_admin']['rank'])) {redirect_to("index.php");}


?>
<!DOCTYPE HTML>
<html lang = "en">
	<head>
		<!--<link rel="stylesheet" href="stylesheets/main.css">-->
		<style>
		</style>
	</head>
	<body>
	<?php echo "Hello there your email is {$_SESSION['pending_admin']['email']} and rank is {$_SESSION['pending_admin']['rank']}"; ?>
	<?php echo form_errors($errors);?>
	<br />
	<form action= "<?php echo $_SERVER['PHP_SELF'];?>" method = "post" enctype="multipart/form-data" id="validate-admin-form">
	<input type = "test" name = "first_name" id="first_name" value = "<?php echo $first_name?>" placeholder="First Name"/><br />
	<input type = "test" name = "last_name" id="last_name" value = "<?php echo $last_name ?>" placeholder="Last Name"/><br />
	<input type = "password" name = "password" value = "" placeholder="password" id="password"/><br />
	<input type = "password" name = "confirm-password" value = "" placeholder="Confirm Password" id="confirm-password"/><br />
	<!--email, username, password, profilepic, level, course, about_me-->
	Course Name:
	<select id="courses" class="select" name="courseid">
	<?php
	$query = "SELECT * FROM courses";
	$results = query($query);
	while($result = mysqli_fetch_assoc($results)) {
		echo "<option data-years='{$result['years']}' ";
		echo "value ='{$result['id']}'>";
		echo "{$result['coursename']}</option>";
	}
	?>
	</select><br />
	Level:
	<select class="select" id="level" name="level">
	
	</select><br />
	About Me:<br />
	<textarea name="aboutme" rows="20" cols="40"></textarea><br />
	<input class="submit" type="submit" name="submit" id="validate-new-admin" value="Create New Admin"/><br />
	</form>
	<div id="error"></div>
	</body>
	<script src="javascripts/jquery.js"></script>
    <script src="javascripts/validate_new_admin.js"></script>
<?php if(isset($connection)) {mysqli_close($connection); }?>
