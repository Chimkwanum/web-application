<?php

require_once('database.php');
require_once('database_object.php');
class Photograph {
	
	protected static $table_name = "photographs";
	protected static $db_fields = array('id', 'filename', 'type', 'size', 'caption');
	
	public $id;
	public $filename;
	public $type;
	public $size;
	public $caption;
	
	private $temp_path;
	protected $upload_dir = "images";
	public $errors = array();
	
	public function create_image_name() {
		$query = "SELECT LAST FROM admins";
		return $image;
	}
}

?>