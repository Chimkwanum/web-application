<!--<a href="validate_new_admin.php?rand=123345&email=darl@gmail.com">GO now</a>-->
<a href="validate_new_admin.php?rand=123345&email=gc@gmail.com">GO now</a>
