<?php
require_once('../includes/initialize.php');
$text = "Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that ";
$text1 = "Hello there this is some  lorem Ipsum Text  so I can put it in any div tag or block level tag that i want so thats what  I am going to do now so lets do that ";
?>
<!DOCTYPE HTML>	
<html>
	<head>
		<meta charset="UTF-8">
        <title>Some</title>
		<meta name="viewport" content="width=device-width, initial-scale = 1.0">
		<link rel="stylesheet" href="stylesheets/jquery.mCustomScrollbar.min.css">
		<link rel="stylesheet" href="stylesheets/main.css">
    <style>
	</style>
	<script>
	var width = window.innerWidth;
	var width_id;
	if(width >= 1200){width_id = 6;}
	if(width <= 1199 && width >= 1024){width_id = 5;}
	if(width <= 1023 && width >= 768){width_id = 4;}
	if(width <= 767 && width >= 480){width_id = 3;}	
	if(width <= 479){width_id = 2;}
	if(width <= 320){width_id = 1;}
	var imageArray = [];
	var textArray = [];
	<?php
		$query = "SELECT * FROM background_frames ORDER BY id DESC";
		$frames = query($query);
		$index = 0;
		while($frame = fetch_assoc($frames)) {
			$back_text = htmlentities($frame['back_text']);
			$url = IMAGE_URL . "{$frame['id']}_backpic_";
			echo "imageArray[{$index}] = \"{$url}\";\n";
			echo "textArray[{$index}] = \"{$back_text}\";\n";
			$index++;
		}
	?>
	</script>
	</head>
	<body id="body" data-mcs-theme="rounded-dots-dark">
	<section id="popup"></section>
	<!--<section style="align-content:center;overflow:auto; padding-right: 1rem;" class="height" id="main" data-mcs-theme="rounded-dots-dark">-->
	<header id="header" class="banner">
	<div id="logo1"></div> <div id="logo2"></div>
	<div id="region-text">DLCF FUPRE</div>
	</header>
	<span style="margin:0 auto;position:fixed;color:black;text-align:center; z-index: 10;">W:<span id="w"></span>px &nbsp;H:<span id="h"></span>px</span>

	<div id="drop-down"></div>
	<div id="menu">
	<a class="smoothscroll" href="#smooth">About</a> <br>
	<a class="smoothscroll">Contact Us</a><br>
	<a class="smoothscroll">Educational Posts</a> <br>
	<a class=""  id="login" href="">Admin Login</a><br>
	</div>
	<div id="scroll" style= "margin: 0px; padding: 0px;">

	<section class="height" style="">
	<div id="dummy"></div>
	<div id="home-banner">
	<div id="quotes">
	<div style="background: url(icon.png); background: white; height:30px; width:10px; display: inline-block; line-height: 100%;"></div>
		<div style="height: 90%; width: 90%; background:green; margin: 0 auto; padding-top: 2%; display: inline-block; line-height: 100%;">
		<p id="quotes-text" style=""><?php echo $text1; ?></p>
		</div>
	<div style="display: inline-block; background: white;"></div>
	</div>
	</div>
	</section>

	<section class="height">
	<div id="about-content-cover" class="main-image regions-cover">
	<hr/>
	<div id="about-content" class="regions-content"data-mcs-theme="rounded-dots-dark">
	<hr/>
	<h2>About DLCF Fupre</h2>
	<hr/>
	<p><?php echo $text.$text.$text;?></p>
	<section class="thumbnail-cover section" data-mcs-theme="rounded-dots-dark">
	<div class="article posts load" id="loadall">
		<div class="load-button" id="buttonall">
		<div id="all" class="load-click" data-page="0">Load More...</div>
		</div>
		<div id="spinall" class="load-spin" style="display: none"></div>
	</div>
	</section>
	</div>
	<hr/>	
	</div></section>

	<section class="height">
	<div id="about-content-cover" class="main-image regions-cover">
	<hr/>
	<div id="about-content" class="regions-content"data-mcs-theme="rounded-dots-dark">
	<hr/>
	<h2>Educational Posts</h2>
	<hr/>
	<p><?php echo $text.$text.$text;?></p>
	<section class="thumbnail-cover section" data-mcs-theme="rounded-dots-dark">
	<div class="article posts load" id="loadall">
		<div class="load-button" id="buttonall">
		<div id="all" class="load-click" data-page="0">Load More...</div>
		</div>
		<div id="spinall" class="load-spin" style="display: none"></div>
	</div>
	</section>
	</div>
	<hr/>	
	</div></section>

	
	<section class="height">
	<div id="about-content-cover" class="main-image regions-cover">
	<hr/>
	<div id="about-content" class="regions-content"data-mcs-theme="rounded-dots-dark">
	<hr/>
	<h2>Announcement Posts</h2>
	<hr/>
	<p><?php echo $text.$text.$text;?></p>
	<section class="thumbnail-cover section" data-mcs-theme="rounded-dots-dark">
	<div class="article posts load" id="loadedu">
		<div class="load-button" id="buttonedu">
		<div id="edu" class="load-click" data-page="0">Load More...</div>
		</div>
		<div id="spinedu" class="load-spin" style="display: none"></div>
	</div>
	</section>
	</div>
	<hr/>	
	</div></section>

	
	<section class="height">
	<div id="about-content-cover" class="main-image regions-cover">
	<hr/>
	<div id="about-content" class="regions-content"data-mcs-theme="rounded-dots-dark">
	<hr/>
	<h2>Below are the followgin stuffs</h2>
	<hr/>
	<p><?php echo $text.$text.$text;?></p>
	<section class="thumbnail-cover section" data-mcs-theme="rounded-dots-dark">
	<div class="article posts load" id="loadspirit">
		<div class="load-button" id="buttonspirit">
		<div id="spirit" class="load-click" data-page="0">Load More...</div>
		</div>
		<div id="spinspirit" class="load-spin" style="display: none"></div>
	</div>
	</section>
	</div>
	<hr/>	
	</div></section>
	
	<footer id="half" style="background: orange;">
	<h1>All Rights Reserved DCLF FUPRE</h1>
	</footer>
		
	<script src="javascripts/jquery.js"></script>
	<script src="javascripts/index_script.js"></script>
	<script src="javascripts/jquery.mCustomScrollbar.concat.min.js"></script>
	<script>
	$(window).on("load",function(){
		var amount=200;
		$(".section").mCustomScrollbar({
			axis:"x",
			theme:"rounded-dots-dark",
			theme:"3d-thick",
			advanced:{
				autoExpandHorizontalScroll:true
			},
				autoHideScrollbar: false,
			scrollButtons:{
				enable:true,
				scrollType:"stepped"
			},
			keyboard:{scrollType:"stepped"},
			snapAmount:amount,
			mouseWheel:{scrollAmount:amount}
		});
		
		$(".regions-content").mCustomScrollbar({
			scrollButtons:{enable:true},
			scrollInertia:400,
			axis: "y",
			autoHideScrollbar: false,
			autoExpandScrollbar:true,
		});
	});
	</script>
	</body>
</html>