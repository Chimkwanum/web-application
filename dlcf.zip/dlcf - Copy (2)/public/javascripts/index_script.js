var half = document.getElementById('half');
var html_back = "linear-gradient(rgba(100,100,100,.9), rgba(100,100,100,.9)), ";
var home_back = "linear-gradient(rgba(255,255,255,.7), rgba(255,255,255,.7)), ";
var main_back = "linear-gradient(rgba(255,255,255,.4), rgba(255,255,255,.4)), ";
var html = document.getElementsByTagName('html');
var home = document.getElementById('home-banner');
var mainImages = document.getElementsByClassName('main-image');
var header = document.getElementById('header');
var quotes = document.getElementById('quotes-text');
var region_text = document.getElementById('region-text');
var sectionArray = [];
sectionArray[0] = "DLCF Fupre";
sectionArray[1] = "About Us";
sectionArray[2] = "All Our Posts";
sectionArray[3] = "Our Educational Posts";
sectionArray[4] = "Our Spitritual Posts";
var imageIndex = 0;
console.log('loaded');
var reg = 'regions-head';
var ban = 'banner';
var load_click = document.getElementsByClassName('load-click');
var loadValue;
var level = 0;
var edu_op = 'all';
var submit_buttons = document.getElementsByClassName("submit");
function changeImage() {
	html[0].style.background = html_back + 'url(' + imageArray[imageIndex] +  width_id + '.png)';
	html[0].style.backgroundSize = "cover";
	html[0].style.backgroundAttachment = "fixed";
	home.style.background = home_back + 'url(' + imageArray[imageIndex] +  width_id + '.png)';
	home.style.backgroundSize = "cover";
	html[0].style.background = imageArray[imageIndex];
	quotes.innerHTML = textArray[imageIndex];
	for(var i = 0; i < mainImages.length; i++) {
		// mainImages[i].style.background = main_back + 'url(' + imageArray[imageIndex] +  width_id + '.png)';
		// mainImages[i].style.backgroundSize = "cover";
	}
	imageIndex++;
	if(imageIndex >= imageArray.length) {imageIndex = 0;}
}

function popupLoading() {
	popup.innerHTML = "";
	popup.style.display = "block";
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
	var string = "<div style=\"height:6.25rem; width: 6.25rem; background: url(images/spinner1.gif); background-size:cover;\"></div>";
	string+= "<div style=\"width: 6.25rem;\">&nbsp;&nbsp;&nbsp;Loading....</div>";
	popup.innerHTML = string;
}

function scrollEffect(attr, index) {
	header.setAttribute('class', attr);
	region_text.innerHTML = sectionArray[index]; 
}

function scrollReaction() {
	var current_y = window.innerHeight + window.pageYOffset;
	if(current_y >= (window.innerHeight * 2)) {scrollEffect(reg, 1);} 
	if(current_y >= (window.innerHeight * 3)) {scrollEffect(reg, 2);} 
	if(current_y >= (window.innerHeight * 4)) {scrollEffect(reg, 3);} 
	if(current_y >= (window.innerHeight * 5)) {scrollEffect(reg, 4);}
	if(current_y >= (window.innerHeight * 6)) {scrollEffect(reg, 5);} 
	if(current_y < (window.innerHeight * 2)) {scrollEffect(ban, 0);} 
}

function disableSubmitButton(button) {
	if(button == null) {
		button = false;
	} 
	if(button == false) {
		for(i=0; i<submit_buttons.length; i++) {
			// submit_buttons[i].style.backgroundSize = 'cover';
			submit_buttons[i].disabled = true;
			// submit_buttons[i].style.background = 'url(spinner.gif)';
			submit_buttons[i].innerHTML = 'Loading...';
		}
	} else {
		button.style.backgroundSize = 'cover';
		button.disabled = true;
		// button.style.background = 'url(spinner.gif)';
		button.innerHTML = 'Loading...';
	}
}

function enableSubmitButton(button) {
	if(button == null) {
		button = false;
	} 
	if(button == false){
		for(i=0; i<submit_buttons.length; i++) {
			submit_buttons[i].disabled = false;
			// submit_buttons[i].style.background = 'url(spinner.gif)';
			submit_buttons[i].innerHTML = 'Proceed';
		}
	} else {
		button
		button.disabled = false;
		// button.style.background = 'url(spinner.gif)';
		button.innerHTML = 'Proceed';
	}
}

function loadMore(id) {
	document.getElementById('button' + id).style.display = 'none';
	document.getElementById('spin' + id).style.display = 'block';
	var page = parseInt(document.getElementById(id).getAttribute('data-page')) + 1;
	// if(id == 'edu') {// }
	var url = 'admin/load_components.php?cont=' + id + '&page=' + page + '&level=' + level + '&edu-op=' + edu_op + '&user=visit';
	// alert(url);
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			// document.getElementById('error').innerHTML = xhr.responseText;
			var json = JSON.parse(xhr.responseText);
			if(json.success == true) {
				document.getElementById(id).setAttribute('data-page', page);
				var temp = document.createElement('div');
				temp.setAttribute('class', 'article');
				temp.setAttribute('id', 'now');
				temp.innerHTML = json.message;
				temp.style.display = 'none';
				$('#load' + id).before(temp);
				$('#now').toggle(1000);
				temp.setAttribute('id', 'later');
				if(json.finished == true) {
					document.getElementById('load' + id).innerHTML = json.extra;
				} else {
					document.getElementById('button' + id).style.display = 'block';
					document.getElementById('spin' + id).style.display = 'none';
				}
			}
		}
	}
	xhr.send();	
}

function closePopup() {
	var popup = document.getElementById('popup');
	popup.style.display = "none";
	popup.innerHTML = "";
	return false;
}

function displayPopUpMessage(message) {
	popup.innerHTML = "";
	popup.style.display = "block";
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
	var body = document.getElementsByTagName("body")[0];
	popup.innerHTML = message.message;
	var script = document.createElement("script");
	script.innerHTML = message.script;
	body.appendChild(script);
}
// changeImage();
var intervalHandle = setInterval(changeImage,9000);

/*Event Handlers*/
$('.smoothscroll').on('click', function (e) {
	e.preventDefault();
	var target = this.hash,
	$target = $(target);
	$('html, body').stop().animate({
		'scrollTop': $target.offset().top
	}, 1000, 'swing', function () {
		window.location.hash = target;
	});
});  

$("#drop-down").click(function () {
	$("#menu").slideToggle(1000);
});

$(document).ready(function () {
	windowHeight = $(window).innerHeight();
	$('.height').css('height', windowHeight);
	width = window.innerWidth;
	height = window.innerHeight;
	var w = document.getElementById("w");
	w.innerHTML = width;
	var h = document.getElementById("h");
	h.innerHTML = height;
	half.style.height = (height/2) + "px";
	
});

$(window).resize(function() {
	windowHeight = $(window).innerHeight();
	$('.height').css('height', windowHeight);
	width = window.innerWidth;
	height = window.innerHeight;
	var w = document.getElementById("w");
	w.innerHTML = width;
	var h = document.getElementById("h");
	h.innerHTML = height;
	half.style.height = (height/2) + "px";
});

$(".load-click").click(function (event) {
	loadMore(event.target.id);
	
});

$("#create-admin-submit").click(function () {
	var button = document.getElementById("create-admin-submit");
	var email_div = document.getElementById("admin_email");
	var rank_select = document.getElementById("admin_rank");
	var rank = rank_select.options[rank_select.selectedIndex].value;
	var email = email_div.value;
	alert(rank);
	alert(email);
	if(!validate_email(email)) {
		var error_div = document.getElementById("notification");
		error_div.innerHTML= "The Email is not valid";
	} else {
		disableSubmitButton(button);
		create_admin(email, rank);
	}
});

$("#login").click(function () {
	// alert('here');
	popupLoading();
	var url= 'login.php?login=true'
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			displayPopUpMessage(json.message);
			
		}
	}
	xhr.send();	
	return false;
});

window.onscroll = function() {
	scrollReaction();
}
