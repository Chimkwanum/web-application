


/* windows resizer....resizing section tabs to have the same height with view port*/
$(document).ready(function () {
  function setHeight() {
    windowHeight = $(window).innerHeight();
    $('.resize').css('height', windowHeight);
  }
    
  setHeight();
   
    
    function processor(){
         height = window.innerHeight;
         width = window.innerWidth;
        if (width <= 1280 && width > 1024){
            if(height > 442){
                setHeight();
            }
        }
        if( width <= 1024 && width > 768){
            if(height > 410 && height < 650 ){
                setHeight();
            }
        }
       if( width <= 768 && width > 480){
            if(height >371 && height < 675){
                setHeight();
            }
       }
        if( width <= 480 && width > 320){
            if(height < 310 && height > 330){
                setHeight();
            }
        }
        if(width <= 320){
            if(height < 470 && height >617){
                
            }
        }
    }
    
 
  
  $(window).resize(function() {
   processor();
  });
});
/* end of window resizer*/




/* smooth scrolling*/
  $('.smoothscroll').on('click', function (e) {
	 	
	 	e.preventDefault();


   	var target = this.hash,
    	$target = $(target);

    	$('html, body').stop().animate({
       	'scrollTop': $target.offset().top
      }, 1000, 'swing', function () {
      	window.location.hash = target;
      });

  	});  






/*  function for forms slide down*/
var counter = 0;
	
	function openForm(){
	$( "#registrationForm" ).slideDown( 1000 );
	}
	function closeForm(){
	$( "#registrationForm" ).slideUp( 1000 );
	}
	function openBook(){
	$( "#buyingBookDiv" ).slideDown( 1000 );
	}
	function closeBook(){
	$( "#buyingBookDiv" ).slideUp( 1000 );
	}
  	
	$( "#joinUs" ).click(function () {
        if (counter == 0){
		  openForm();
		  counter = 1;
        }else {
        if (counter == 1) {
            closeForm();
            counter = 0;
        }else {
            if (counter == 2){
                closeBook();
                
				setTimeout(openForm, 1000);
                counter = 1;
            }
        }
        }
        
	});
	
	$( "#buyBook" ).click(function () {
		 if (counter == 0){
		  openBook();
		  counter = 2;
        }else {
        if (counter == 2) {
            closeBook();
            counter = 0
        }else {
            if (counter == 1){
                closeForm();
				setTimeout(openBook, 1000);
                counter = 2;
            }
        }
        }
	});

        var count = 0;
    	$( "#processLocationLink" ).click(function () {
            if (count == 0){
		$( "#locationDiv" ).slideDown( 1000 );
        count = 1;
        }else {
            if (count == 1){
        $( "#locationDiv" ).slideUp( 1000 );
        count = 0;
            }
        }
        });// end of slide down and slide up

