
function disableSubmitButton(button=false) {
	if(button == false) {
		for(i=0; i<submit_buttons.length; i++) {
			submit_buttons[i].disabled = true;
			submit_buttons[i].innerHTML = 'Saving...';

		}
	} else {
		button.style.backgroundSize = 'cover';
		button.disabled = true;
		button.innerHTML = 'Saving...';
	}
}

function enableSubmitButton(button=false) {
	if(button == false){
		for(i=0; i<submit_buttons.length; i++) {
			submit_buttons[i].disabled = false;
			submit_buttons[i].innerHTML = 'Create Page';

		}
	} else {
		button
		button.disabled = false;
		// button.style.background = 'url(spinner.gif)';
		button.innerHTML = 'Create Page';
	}
	
}

function displayPopUpMessage(message) {
	var popup = document.getElementById("popup");
	popup.style.display = "block";
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
	popup.style.overflow = "scroll";
	alert(message.script);
	var mymessage = document.createTextNode(message);
	var body = document.getElementsByTagName("body")[0];
	
	// popup.appendChild(mymessage);
	popup.innerHTML = message.message;
	var script = document.createElement("script");
	script.innerHTML = message.script;
	body.appendChild(script);
}

document.getElementById("form").onsubmit = function() {	
	alert('Submitted');
	var form = document.getElementById("form");
	var form_data = new FormData(form);
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}
	var button = document.getElementById("submit");
	// disableSubmitButton(button);
	// alert("test");
	
	var url = 'process_edit_page.php';
	var xhr = new XMLHttpRequest();
	xhr.open('POST', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var error_div = document.getElementById("error");
			error_div.innerHTML = xhr.responseText;
			var json = JSON.parse(xhr.responseText);
			// if(json.success = true) {
				// // window.location.replace(json.location);
				// window.location.href = json.location;
			// } else {
				// var error_div = document.getElementById("error");
				// error_div.innerHTML = xhr.responseText;
				// enableSubmitButton(button);
			// }
			enableSubmitButton(button);
		}
	}
	xhr.send(form_data);	
	return false;
};

$("#addimage").click(function () {
	alert("Functions");
	var url = 'images.php';
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			
			// displayPopUpMessage(message);
			displayPopUpMessage(json.message);
			// console.log(json.background_url);
		}
	}
	xhr.send();
});

$(window).resize(function() {
	// var popup = document.getElementById("popup");
	// popup.style.display = "block";
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
	popup.style.overflow = "scroll";
});

