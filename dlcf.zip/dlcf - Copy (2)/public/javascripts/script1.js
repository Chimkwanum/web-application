
// handle the form submit event
function prepareEventHandlers() {
    var count = 0;
	document.getElementById("registrationForm").onsubmit = function() {
// prevent a form from submitting if no valid lastname..............
		if (document.getElementById("lastName").value == "") {
			document.getElementById("lastNameError").innerHTML = "Please provide a valid name.";
            count = 1;
			// to STOP the form from submitting
			
		} else {
			// reset and allow the form to submit
			document.getElementById("lastNameError").innerHTML = "";
			return true;
		} 
       
	/*
     if ( some regex stuffs){
            
        }
        */
// END of lastname validation...................................
        
        
        
      
// prevent a form from submitting if no valid firstname..............
		if (document.getElementById("firstName").value == "") {
			document.getElementById("firstNameError").innerHTML = "Please provide a valid name.";
            count = 1;
			// to STOP the form from submitting
			
		} else {
			// reset and allow the form to submit
			document.getElementById("firstNameError").innerHTML = "";
			return true;
		} 
       
	/*
     if ( some regex stuffs){
            
        }
        */
 // END of firstname validation...................................
        
        
        
// prevent a form from submitting if no valid email address..........
		if (document.getElementById("formEmail").value == "") {
			document.getElementById("formEmailError").innerHTML = "Please provide a valid name.";
            count = 1;
			// to STOP the form from submitting
			
		} else {
			// reset and allow the form to submit
			document.getElementById("formEmailError").innerHTML = "";
			return true;
		} 
       
	/*
     if ( some regex stuffs){
            
        }
        */
 // END of email validation...........................................
        
        
        
// prevent a form from submitting if no valid country................
		if (document.getElementById("country").value == "") {
			document.getElementById("countryError").innerHTML = "Please provide a valid name.";
            count = 1;
			// to STOP the form from submitting
			
		} else {
			// reset and allow the form to submit
			document.getElementById("countryError").innerHTML = "";
			return true;
		} 
       
	/*
     if ( some regex stuffs){
            
        }
        */
 // END of country validation.........................................
        
        
        
 // prevent a form from submitting if no valid state..............
		if (document.getElementById("state").value == "") {
			document.getElementById("stateError").innerHTML = "Please provide a valid name.";
            count = 1;
			// to STOP the form from submitting
			
		} else {
			// reset and allow the form to submit
			document.getElementById("stateError").innerHTML = "";
			return true;
		} 
       
	/*
     if ( some regex stuffs){
            
        }
        */
 // END of state validation.........................................
        
        
// prevent a form from submitting if no valid city ..................
		if (document.getElementById("city").value == "") {
			document.getElementById("cityError").innerHTML = "Please provide a valid name.";
			// to STOP the form from submitting
            count = 1;
			
		} else {
			// reset and allow the form to submit
			document.getElementById("cityError").innerHTML = "";
			return true;
		} 
       
	/*
     if ( some regex stuffs){
            
        }
        */
// END of city validation.........................................
        
        
// prevent a form from submitting if no valid tel ..................
		if (document.getElementById("telephone").value == "") {
			document.getElementById("telephoneError").innerHTML = "Please provide a valid name.";
            count = 1;
			// to STOP the form from submitting
			
		} else {
			// reset and allow the form to submit
			document.getElementById("telephoneError").innerHTML = "";
			return true;
		} 
       
	/*
     if ( some regex stuffs){
            
        }
        */
// END of tel validation.........................................
        
    
        if(count == 1){
           document.getElementById("allErrorMessage").innerHTML = "Please fix the items indicated.";
            return false;
        }
        
        
        
    };
}

// when the document loads
window.onload =  function() {
	prepareEventHandlers();
};

