var load_click = document.getElementsByClassName('load-click');
var loadValue;
var level = 0;
var edu_op = 'all';
var comment_select = document.getElementById("comment-select");

function loadMore(id) {
	document.getElementById('button' + id).style.display = 'none';
	document.getElementById('spin' + id).style.display = 'block';
	var page = parseInt(document.getElementById(id).getAttribute('data-page')) + 1;
	// if(id == 'edu') {// }
	// var url = 'load_components.php?cont=' + id + '&page=' + page + '&level=' + level + '&edu-op=' + edu_op + '&user=visit';
	var url = '../admin/load_components.php?cont=' + id + '&page=' + page + '&level=' + level + '&edu-op=' + edu_op + '&user=visit';
	// alert(url);
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			// document.getElementById('error').innerHTML = xhr.responseText;
			var json = JSON.parse(xhr.responseText);
			if(json.success == true) {
				document.getElementById(id).setAttribute('data-page', page);
				var temp = document.createElement('div');
				temp.setAttribute('class', 'article');
				temp.setAttribute('id', 'now');
				temp.innerHTML = json.message;
				temp.style.display = 'none';
				$('#load' + id).before(temp);
				$('#now').toggle(1000);
				temp.setAttribute('id', 'later');
				if(json.finished == true) {
					document.getElementById('load' + id).innerHTML = json.extra;
				} else {
					document.getElementById('button' + id).style.display = 'block';
					document.getElementById('spin' + id).style.display = 'none';
				}
			}
		}
	}
	xhr.send();	
}

function loadComments(id) {
	document.getElementById(id).innerHTML = 'Loading....';
	var page = parseInt(document.getElementById(id).getAttribute('data-page')) + 1;
	var post_id = parseInt(document.getElementById(id).getAttribute('data-postId'));
	// var url = "../admin/load_comments.php";
	var url = "../admin/load_comments.php?page=" + page + "&post-id=" + post_id;;
	// alert(url);
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			var temp = document.createElement('div');
			temp.setAttribute('id', 'now');
			temp.innerHTML = json.comments;
			// alert(json.comments);
			temp.style.display = 'none';
			$('#load-before').before(temp);
			$('#now').slideDown(1000);
			temp.setAttribute('id', 'later');
			var comments_button = document.getElementById("load-comm-button");
			if(json.finished == true) {
				comments_button.innerHTML = "Comments Loaded";
				comments_button.setAttribute('id', 'comm-loaded');
			} else {
				comments_button.innerHTML = "Load More Comments";
			}
		}
	}
	xhr.send();	
}

$("#load-comm-button").click(function () {
	loadComments('load-comm-button');
});

$(".load-click").click(function (event) {
	loadMore(event.target.id);
	
});

function hide_sender() {
	var name = document.getElementById("sender-name");
	var selected = comment_select.options[comment_select.selectedIndex].value;
	if(selected == "name") {
		name.style.display = "block";
	} else {
		name.style.display = "none";
	}	
}

$(document).ready(function () {
	hide_sender();
	loadMore('all');
});

comment_select.addEventListener("change",hide_sender);