$(window).on("load",function(){
	var amount=200;
	$(".section").mCustomScrollbar({
		axis:"x",
		theme:"rounded-dots-dark",
		advanced:{
			autoExpandHorizontalScroll:true
		},
		autoHideScrollbar: false,
		scrollButtons:{
			enable:true,
			scrollType:"stepped"
		},
		keyboard:{scrollType:"stepped"},
		snapAmount:amount,
		mouseWheel:{scrollAmount:amount}
	});
		
});