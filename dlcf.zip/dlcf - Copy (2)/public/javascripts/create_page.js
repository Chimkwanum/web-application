var popup = document.getElementById("popup");
var type_select = document.getElementById("page-type");

function disableSubmitButton(button=false) {
	if(button == false) {
		for(i=0; i<submit_buttons.length; i++) {
			submit_buttons[i].disabled = true;
			submit_buttons[i].innerHTML = 'Saving...';

		}
	} else {
		button.style.backgroundSize = 'cover';
		button.disabled = true;
		button.innerHTML = 'Saving...';
	}
}

function enableSubmitButton(button=false) {
	if(button == false){
		for(i=0; i<submit_buttons.length; i++) {
			submit_buttons[i].disabled = false;
			submit_buttons[i].innerHTML = 'Create Page';

		}
	} else {
		button
		button.disabled = false;
		// button.style.background = 'url(spinner.gif)';
		button.innerHTML = 'Create Page';
	}
	
}

function popupLoading() {
	popup.innerHTML = "";
	popup.style.display = "block";
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
	var string = "<div style=\"height:6.25rem; width: 6.25rem; background: url(spinner1.gif); background-size:cover;\"></div>";
	string+= "<div style=\"width: 6.25rem;\">&nbsp;&nbsp;&nbsp;Loading....</div>";
	popup.innerHTML = string;
}


function closePopup() {
	popup.style.display = "none";
	popup.innerHTML = "";
	return false;
}

function displayPopUpMessage(message) {
	popup.style.display = "block";
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
	popup.style.overflow = "scroll";
	var body = document.getElementsByTagName("body")[0];
	popup.innerHTML = message.message;
	var script = document.createElement("script");
	script.innerHTML = message.script;
	body.appendChild(script);	
}

document.getElementById("form").onsubmit = function() {	
	var form = document.getElementById("form");
	var form_data = new FormData(form);
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}
	var button = document.getElementById("submit");
	disableSubmitButton(button);
	// alert("test");
	
	var url = 'process_create_page.php';
	var xhr = new XMLHttpRequest();
	xhr.open('POST', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var error_div = document.getElementById("error");
			// error_div.innerHTML = xhr.responseText;
			var json = JSON.parse(xhr.responseText);
			error_div.innerHTML = json.message;
			// if(json.success = true) {
				// // window.location.replace(json.location);
				// window.location.href = json.location;
			// } else {
				// var error_div = document.getElementById("error");
				// error_div.innerHTML = xhr.responseText;
				// enableSubmitButton(button);
			// }
			enableSubmitButton(button);
		}
	}
	xhr.send(form_data);	
	return false;
};

$("#addimage").click(function () {
	popupLoading();
	var url = 'images.php';
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			
			// displayPopUpMessage(message);
			displayPopUpMessage(json.message);
			// console.log(json.background_url);
		}
	}
	xhr.send();
});

function hide_level() {
	var level = document.getElementById("level");
	var selected = type_select.options[type_select.selectedIndex].value;
	if(selected == "edu") {
		level.style.display = "block";
	} else {
		level.style.display = "none";
	}	
}

$(document).ready(function () {
	hide_level();
});

type_select.addEventListener("change",hide_level);

$(window).resize(function() {
	// var popup = document.getElementById("popup");
	// popup.style.display = "block";
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
	popup.style.overflow = "scroll";
});

