var popup = document.getElementById("popup");
var loadValue;
var level = 0;
var edu_op = 'all';

function closePopup() {
	popup.style.display = "none";
	popup.innerHTML = "";
	return false;
}

function displayPopUpMessage(message) {
	popup.innerHTML = "";
	popup.style.display = "block";
	popup.style.overflow = "scroll";
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
	var body = document.getElementsByTagName("body")[0];
	popup.innerHTML = message.message;
	var script = document.createElement("script");
	script.innerHTML = message.script;
	body.appendChild(script);
}
	
function testing() {
	alert("Testing script efficiency");
}

function send_message(form) {
	popupLoading();
	var url = 'send_message.php';
	var xhr = new XMLHttpRequest();
	xhr.open('POST', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			
			var error = document.getElementById("error");
			
			error.innerHTML = json.message;
			if(json.success == true) {
				// We close popup and then disable script
			} else {
				
			}
		}
	}
	xhr.send(form);
}

function messageForm() {
	console.log("Here now");
	var url = 'message_form.php';
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			displayPopUpMessage(json.message);
		}
	}
	xhr.send();	
}

function loadMore(id) {
	document.getElementById('button' + id).style.display = 'none';
	document.getElementById('spin' + id).style.display = 'block';
	var page = parseInt(document.getElementById(id).getAttribute('data-page')) + 1;
	// if(id == 'edu') {// }
	var url = 'load_components.php?cont=' + id + '&page=' + page + '&level=' + level + '&edu-op=' + edu_op + '&user=admin';
	// alert(url);
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			// document.getElementById('error').innerHTML = xhr.responseText;
			var json = JSON.parse(xhr.responseText);
			if(json.success == true) {
				document.getElementById(id).setAttribute('data-page', page);
				var temp = document.createElement('div');
				temp.setAttribute('class', 'article');
				temp.setAttribute('id', 'now');
				temp.innerHTML = json.message;
				temp.style.display = 'none';
				$('#load' + id).before(temp);
				$('#now').toggle(1000);
				temp.setAttribute('id', 'later');
				if(json.finished == true) {
					document.getElementById('load' + id).innerHTML = json.extra;
				} else {
					document.getElementById('button' + id).style.display = 'block';
					document.getElementById('spin' + id).style.display = 'none';
				}
			}
		}
	}
	xhr.send();	
}

function popupLoading() {
	popup.innerHTML = "";
	popup.style.display = "block";
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
	var string = "<div style=\"height:6.25rem; width: 6.25rem; background: url(spinner1.gif); background-size:cover;\"></div>";
	string+= "<div style=\"width: 6.25rem;\">&nbsp;&nbsp;&nbsp;Loading....</div>";
	popup.innerHTML = string;
}

function showMessage(id) {
	popupLoading();
	var message = document.getElementById(id);
	alert('Id is: ' + id);
	var id = message.getAttribute('data-messId');
	var  cont = message.getAttribute('data-context');
	alert('Context is: \n' + cont);
	alert(id);
	var url = 'message.php?id=' + id + '&cont=' + cont;
	alert(url);
	// alert(url); 
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			 displayPopUpMessage(json.message);
		}
	}
	xhr.send();
}

function loadAdmin(id) {
	alert('Adimin id is: ' + id);
	var url = 'admin.php?id=' + id;
	alert(url);
	popupLoading();
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			// var error = document.getElementById("error");
			// error.innerHTML = xhr.responseText;
			var json = JSON.parse(xhr.responseText);
			 displayPopUpMessage(json.message);
			// var background = json.image;
			// // alert(background);
			// image_cover.style.backgroundImage = background;
		}
	}
	xhr.send();
	
}

$(document).ready(function () {
	loadMore('all');
	loadMore('edu');
	loadMore('spirit');
	loadMore('announce');
});

$(window).resize(function() {
	popup.style.width = window.innerWidth + "px";
    popup.style.height = window.innerHeight + "px";
});

$("#send-message").click(function () {
	var form = document.getElementById("form");
	alert("here");
	var form_data = new FormData(form);
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}	
	send_message(form_data);
});

$("#sendmessage").click(function () {
	// var form = document.getElementById("form");
	// alert(evt.getAttribute("id"));
	// alert("here");
	var id;
	messageForm();
	/* displayPopUpMessage(messageForm());
	// alert(messageForm());
	// var form_data = new FormData(form);
	// for ([key, value] of form_data.entries()) {
	  // console.log(key + ': ' + value);
	// }	
	// send_message(form_data);*/
});

$(".admin").click(function (event) {
	alert("here");
	var id = event.target.id;
	alert(id);
	var url = 'admin1.php?id=' + id;
	alert(url);
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var error = document.getElementById("error");
			error.innerHTML = xhr.responseText;
			var json = JSON.parse(xhr.responseText);
			 displayPopUpMessage(json.message);
			// var background = json.image;
			// // alert(background);
			// image_cover.style.backgroundImage = background;
		}
	}
	xhr.send();
	displayPopUpMessage(getMessage(id));
	
});

$(".load-click").click(function (event) {
	loadMore(event.target.id);
});

$("#receivers").change(function () {
	var select = document.getElementById("receivers");
	sel_rec = select.options[select.selectedIndex].value;
	if(sel_rec == -3) {
		var admins = document.getElementById("admin-members-container");
		$("#admin-members-container").slideToggle(500);
		// $("#form").slideToggle(500);
	} else {
		$("#admin-members-container").slideUp(500);
	}
	alert("Working");
	// alert(sel_rec);
	
});

	
	
