var select_buttons = document.getElementsByClassName("zz");


$("#update-pic").click(function() {
	// form will first be validated by javascript first
	var button = document.getElementById('update-pic');
	disableSelect(button);
	var error = document.getElementById("error");
	var imageload = document.getElementById("image-loader");
	var image = document.getElementById("profile-pic");
	imageload.style.background = "url(spinner.gif)";
	imageload.style.backgroundSize = "cover";
	var form = document.getElementById("pic-form");
	var action = "edit_profile_pic.php";

	var form_data = new FormData(form);
	console.log("processing");
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}	
	var xhr = new XMLHttpRequest();
	xhr.open('POST', action, true);
	
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log('Result: ' + xhr.responseText);
			var error = document.getElementById("pic-error");
			error.innerHTML = xhr.responseText;
			var json = JSON.parse(xhr.responseText);
			if(json.success == true) {
				image.style.background = json.url;
				imageload.style.background = "";
				image.style.backgroundSize = "cover";
				imageload.style.backgroundSize = "cover";
				enableSelect(button);
				
			}
		}
	}
	xhr.send(form_data);

});

function enableSelect(button=false) {
	if(button == false){
		for(i=0; i<select_buttons.length; i++) {
			select_buttons[i].disabled = false;
			// submit_buttons[i].style.background = 'url(spinner.gif)';
		}
	} else {
		button.disabled = false;
		// button.style.background = 'url(spinner.gif)';
	}
	
}

function disableSelect(button=false) {
	if(button == false) {
		for(i=0; i<select_buttons.length; i++) {
			// submit_buttons[i].style.backgroundSize = 'cover';
			select_buttons[i].disabled = true;
			// submit_buttons[i].style.background = 'url(spinner.gif)';

		}
	} else {
		button.disabled = true;
		// button.style.background = 'url(spinner.gif)';
	}
}
	
function updateLevel() {
	disableSelect(courses);
	var years = courses.options[courses.selectedIndex].getAttribute("data-years");
	// alert(years);
	var string = "";
	var index = 1;
	for(i=0; i<years; i++) {
		string += "<option value='" + index + "'>" + index + "00" + "</option>";
		index++;
	}
	var level = document.getElementById("level");
	level.innerHTML = string;
	enableSelect(courses);
}

function check_presence(value) {
	return true;
}

courses.addEventListener("change",function(){
	updateLevel();
});

$(document).ready(function () {
	updateLevel();
	disableSelect(courses);
	
});

$(".edit").click(function(event) {
	var str = "The id is: ";
	// alert(str + event.target.data-id);
	// alert(str + event.target.getAttribute("data-id"));
	var id = event.target.getAttribute("data-id");
	var button = document.getElementById("edit-admin-det");
	if(id == "courses") {
		var level = document.getElementById("level");
		level.disabled = false;
		
	}
	var object = document.getElementById(id);
	button.disabled = false;
	object.disabled = false;
	return false;
});

$("#change-pass-butt").click(function(event) {
	var div = document.getElementById("change-pass-div");
	// div.slideToggle(500);
	$("#change-pass-div").slideToggle(500);
	// alert(str + event.target.data-id);
	// alert(str + event.target.getAttribute("data-id"));
});
	
$("#edit-admin-det").click(function(event) {
	// form will first be validated by javascript first
	var edit = document.getElementsByClassName("edit-form");
	var error = document.getElementById("error");
	
	for(i=0; i<edit.length; i++) {
		// submit_buttons[i].style.backgroundSize = 'cover';
		edit[i].disabled = false;
		// submit_buttons[i].style.background = 'url(spinner.gif)';

	}
	
	var form = document.getElementById("details-form");
	var action = "edit_profile_process.php";

	var form_data = new FormData(form);
	console.log("processing");
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	  if(!check_presence(value)){
		  error.innerHTML = key + "can't be blank";
		  return false;
	  }
	}	
	disableSelect();

	var xhr = new XMLHttpRequest();
	xhr.open('POST', action, true);
	
	// the form checks for form errors true means it passed and false means there was a form error if there was a form error then there will be the message to display 
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			
			console.log('Result: ' + xhr.responseText);
			var json = JSON.parse(xhr.responseText);
			
			error.innerHTML = json.message;
		}
	}
	xhr.send(form_data);

});
