var submit_buttons = document.getElementsByClassName("submit");

function create_admin(email, rank) {
	var button = document.getElementById("create-admin-submit");
	var url = 'create_admin.php?email=' + email + '&rank=' + rank;
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var error_div = document.getElementById("notification");
			error_div.innerHTML = xhr.responseText;
			enableSubmitButton(button);
		}
	}
	xhr.send();
}

function disableSubmitButton(button=false) {
	if(button == false) {
		for(i=0; i<submit_buttons.length; i++) {
			// submit_buttons[i].style.backgroundSize = 'cover';
			submit_buttons[i].disabled = true;
			// submit_buttons[i].style.background = 'url(spinner.gif)';
			submit_buttons[i].innerHTML = 'Loading...';

		}
	} else {
		button.disabled = true;
		// button.style.background = 'url(spinner.gif)';
		button.innerHTML = 'Loading...';
	}
}

function enableSubmitButton(button=false) {
	if(button == false){
		for(i=0; i<submit_buttons.length; i++) {
			submit_buttons[i].disabled = false;
			// submit_buttons[i].style.background = 'url(spinner.gif)';
			submit_buttons[i].innerHTML = 'Proceed';

		}
	} else {
		button
		button.disabled = false;
		// button.style.background = 'url(spinner.gif)';
		button.innerHTML = 'Proceed';
	}
	
}

function validate_email() {
	return true;
}

function create_course(form) {
	var button = document.getElementById("create-course-button");

	var url = 'create_course.php';
	var xhr = new XMLHttpRequest();
	xhr.open('POST', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var error_div = document.getElementById("error");
			error_div.innerHTML = xhr.responseText;
			enableSubmitButton(button);
		}
	}
	xhr.send(form);
}

function deleteFrame(id) {
	alert('Id is: ' + id);
	var xhr = new XMLHttpRequest();
	var url = 'background.php?delete=' + id;
	xhr.open('GET', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			$('#frame_' + id).slideUp(1000);
			var json = JSON.parse(xhr.responseText);
			// document.getElementById('frame_' + id).innerHTML = json.message;
			// document.getElementById('frame_' + id).style.display = "block";
			document.getElementById('message_' + id).innerHTML = json.message;
			document.getElementById('message_' + id).style.marginBottom = "2rem";
		}
	}
	xhr.send();

	
}

$("#create-admin-submit").click(function () {
	var button = document.getElementById("create-admin-submit");
	var email_div = document.getElementById("admin_email");
	var rank_select = document.getElementById("admin_rank");
	var rank = rank_select.options[rank_select.selectedIndex].value;
	var email = email_div.value;
	alert(rank);
	alert(email);
	if(!validate_email(email)) {
		var error_div = document.getElementById("notification");
		error_div.innerHTML= "The Email is not valid";
	} else {
		disableSubmitButton(button);
		create_admin(email, rank);
	}
	
});


$("#create-course-button").click(function () {
	var button = document.getElementById("create-course-button");	
	var form = document.getElementById("course-form");
	var action = "process_transactions.php";

	disableSubmitButton(button);
	// gather form data
	var form_data = new FormData(form);
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}	
	
	create_course(form_data);
	
});

document.getElementById("add-form").onsubmit = function() {
	var button = document.getElementById('save-frame');
	disableSubmitButton(button);
	alert('submitted');
	var form = document.getElementById("add-form");
	var form_data = new FormData(form);
	for ([key, value] of form_data.entries()) {
	  console.log(key + ': ' + value);
	}
	var url = 'background.php';
	var xhr = new XMLHttpRequest();
	xhr.open('POST', url, true);
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.onreadystatechange = function () {
		if(xhr.readyState == 4 && xhr.status == 200) {
			console.log(xhr.responseText);
			var error_div = document.getElementById("error");
			error_div.innerHTML = xhr.responseText;
			enableSubmitButton(button);
			// enableSubmitButton(button);
		}
	}
	xhr.send(form_data);
	return false;

};

