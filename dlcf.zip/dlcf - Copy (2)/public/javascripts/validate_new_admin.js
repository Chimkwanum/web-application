var select_buttons = document.getElementsByClassName("select");
var courses = document.getElementById("courses");
var submit_buttons = document.getElementsByClassName("submit");

function disableSubmitButton(button=false) {
	if(button == false) {
		for(i=0; i<submit_buttons.length; i++) {
			// submit_buttons[i].style.backgroundSize = 'cover';
			submit_buttons[i].disabled = true;
			// submit_buttons[i].style.background = 'url(spinner.gif)';
			submit_buttons[i].innerHTML = 'Loading...';

		}
	} else {
		button.style.backgroundSize = 'cover';
		button.disabled = true;
		// button.style.background = 'url(spinner.gif)';
		button.innerHTML = 'Loading...';
	}
}

function enableSubmitButton(button=false) {
	if(button == false){
		for(i=0; i<submit_buttons.length; i++) {
			submit_buttons[i].disabled = false;
			// submit_buttons[i].style.background = 'url(spinner.gif)';
			submit_buttons[i].innerHTML = 'Proceed';

		}
	} else {
		button
		button.disabled = false;
		// button.style.background = 'url(spinner.gif)';
		button.innerHTML = 'Proceed';
	}
	
}

function enableSelect(button=false) {
	if(button == false){
		for(i=0; i<select_buttons.length; i++) {
			select_buttons[i].disabled = false;
		}
	} else {
		button.disabled = false;
	}
}


function disableSelect(button=false) {
	if(button == false) {
		for(i=0; i<select_buttons.length; i++) {
			select_buttons[i].disabled = true;
		}
	} else {
		button.disabled = true;
	}
}

function validate_email() {
	return true;
}

function updateLevel() {
	disableSelect(courses);
	var years = courses.options[courses.selectedIndex].getAttribute("data-years");
	alert(years);
	var string = "";
	var index = 1;
	for(i=0; i<years; i++) {
		string += "<option value='" + index + "'>" + index + "00" + "</option>";
		index++;
	}
	var level = document.getElementById("level");
	level.innerHTML = string;
	enableSelect(courses);
}

courses.addEventListener("change",function(){
	updateLevel();
});

$(document).ready(function () {
	updateLevel();
});
