<?php


?>
<!DOCTYPE HTML>	
<html>
	<head>
		<meta charset="UTF-8">
        <title>
			Some
        </title>
        <meta name="viewport" content="width=device=width, initial-scale = 1.0">
        <link rel="stylesheet" href="stylesheets/main.css">
    <style>
	
	</style>
	</head>
 <body>
     <header>
         <div id="logo"> Some</div>
         <nav>
            <a class="nav, smoothscroll" id="navabout" href="#about">
            <span class="nav"> About us</span>
            </a>  
            <a class="nav, smoothscroll" id="navproduct" href="#product">
            <span class="nav"> Register</span>
            </a>  
            <a class="nav, smoothscroll" id="navservice" href="#"> services
                
                <a id="navseminar" href="#seminar">
                    
                </a>
                <a id="navnetwork" href="#network">
                </a>
            </a>
                 
        </nav>
     </header>
     
     
     <section  class="resize" id="about inline">
	 <div style=" overflow: auto;" >
	 <div style="height:10rem; width:2500px;">
	<?php
		for($i=0; $i<4; $i++){
			echo "<div style=\"";
			echo "width: 22rem;";
			echo "display: inline-block;";
			echo "background: url(images/kumuyi.jpg);";
			echo "color: black;";
			echo "background-size: cover;";
			echo "height: 22rem;";
			echo "float: left;";
			echo "margin-top: 2rem;";
			echo "margin-left: 2rem;";
			echo "margin-right: 2rem;";
			echo "border-radius: 1rem;";
			echo "\">";
			echo "	This is were the educational corner will be located for educational news and other stuffs.............
			";
			echo "</div>";
		}
	?>
	<div style="content-align:center; text-align:center;">Load More.......</div>
	</div>
	</div>
     </section>
    
     <section class="resize" id="product">
         
      <div style=" overflow: auto;" >
	 <div style="height:10rem; width:2500px;">
	<?php
		for($i=0; $i<4; $i++){
			echo "<div style=\"";
			echo "width: 22rem;";
			echo "display: inline-block;";
			echo "background: url(images/kumuyi.jpg);";
			echo "color: black;";
			echo "background-size: cover;";
			echo "height: 22rem;";
			echo "float: left;";
			echo "margin-top: 2rem;";
			echo "margin-left: 2rem;";
			echo "margin-right: 2rem;";
			echo "border-radius: 1rem;";
			echo "\">";
			echo "	This is were the educational corner will be located for educational news and other stuffs.............
			";
			echo "</div>";
		}
	?>
	</div>
	</div>
     
     </section>
     
     <section class="resize" id="seminar">
         
        <div style=" overflow: auto;" >
	 <div style="height:10rem; width:2500px;">
	<?php
		for($i=0; $i<4; $i++){
			echo "<div style=\"";
			echo "width: 22rem;";
			echo "display: inline-block;";
			echo "background: url(images/kumuyi.jpg);";
			echo "color: black;";
			echo "background-size: cover;";
			echo "height: 22rem;";
			echo "float: left;";
			echo "margin-top: 2rem;";
			echo "margin-left: 2rem;";
			echo "margin-right: 2rem;";
			echo "border-radius: 1rem;";
			echo "\">";
			echo "	This is were the educational corner will be located for educational news and other stuffs.............
			";
			echo "</div>";
		}
	?>
	</div>
	</div>
        
     </section>
     
     <section class="resize" id="network">
         
     When I was well grown, at last, I was sold and taken away, and I never saw her again. She was broken-hearted, and so was I, and we cried; but she comforted me as well as she could, and said we were sent into this world for a wise and good purpose, and must do our duties without repining, take our life as we might find it, live it for the best good of others, and never mind about the results; they were not our affair. She said men who did like this would have a noble and beautiful reward by and by in another world, and although we animals would not go there, to do
         <div> 
         You can  <a href="#" id="joinUs" onclick= "return false";>Join Us</a> to get started
		</div>		 
         <div> Or Just <a href="#" id="buyBook" onclick= "return false";>Buy our Book</a>
		</div> 
         
         or just buy our book
         <div id="registrationContainer">
             
             <form name="registrationForm" id="registrationForm" method="post" action="">
             <fieldset>
                 <!-- lastname -->
                 <p class="errorMessage"> PLease enter in a valid Last Name</p>
                 <span class="registrationDescribe">Lastname <span class = "errorMessages" id = "lastNameError"></span></span>
                 <div class="registrationDivs">
                     <input name="lastName" type="text" id="lastName" placeholder="Lastname" value="" minlength="2"> 
                 
                 </div>
                 
                 
                 
                 
                 <!-- firstname -->
                 <p class="errorMessage"> PLease enter in a valid First Name</p>
                 <span class="registrationDescribe">Firstname<span class = "errorMessages" id = "firstNameError"></span></span>
                 <div class="registrationDivs">
                    <input name="firstName" type="text" id="firstName" placeholder="Firstname" value="" minlength="2" >
                 
                 </div>
                 
                 
                 
                 <!-- email -->
                 <p class="errorMessage"> PLease enter in a valid Email address</p>
                 <span class="registrationDescribe">Email<span class = "errorMessages" id = "formEmailError"></span></span>
                 <div class="registrationDivs">
                 <input name="email" type="email" id="formEmail" placeholder="Email" value="" minlength="2"> 
                 
                 </div>
                 <div id = "processLocation">
				 <a href="#" id="processLocationLink" onclick= "return false";>Please click here to fill in or process your location</a>
				 </div>
                 <!-- Location section-->
                 <div id="locationDiv">
                     
                     <!-- country -->
                      <p class="errorMessage"> PLease enter in a valid Country</p>
                     <span class="registrationDescribe">Country<span class = "errorMessages" id = "countryError"></span></span>
                     <div class="registrationDivs">
                     <input name="country" type="text" id="country" placeholder="Country" value="" minlength="2" > 
                     </div>
                     
                     
                  
                     
                     
                     <!-- state-->
                     
                      <p class="errorMessage"> PLease enter in a valid State</p>
                     <span class="registrationDescribe">State<span class = "errorMessages" id = "stateError"></span></span>
                     <div class="registrationDivs">
                     <input name="state" type="text" id="state" placeholder="State" value="" minlength="2" > 
                     </div>
                     
                     
                     <!-- city-->
                      <p class="errorMessage"> PLease enter in a valid City</p>
                     <span class="registrationDescribe">City<span class = "errorMessages" id = "cityError"></span></span>
                     <div class="registrationDivs">
                     <input name="city" type="text" id="city" placeholder="City" value="" minlength="2" > 
                     </div>
                     
                     
                     
                     
                 </div>
              
                 
                 <!-- confimed Location-->
                 <div id="confirmedLocation">
                 <!-- this will diaplay the confirmed location -->
                 </div>
                 
                 <!-- Telephone number-->
                   <p class="errorMessage"> PLease enter in a valid Telephone number</p>
                 <span class="registrationDescribe">Telephone no.<span class = "errorMessages" id = "telephoneError"></span></span>
                 <div class="registrationDivs">
                    <input name="telephone" type="tel" id="telephone" placeholder="Telephone no." value="" minlength="2" > 
                
                 </div>
				 
				 <p><span class = "errorMessages" id = "allErrorMessage"> </span> </p>
                 <p class = "errorMessages"> Please fix the item(s) indicated</p>
                
                 <!-- submit button-->
                <input type="submit" name = "submit" id="submitForm" value="Submit">
                     
                 
                 
                 
                 
                 
             </fieldset>
             </form>
            <form id = "buyingBookDiv">
                <fieldset>
                    <!-- buying the book-->
                     <span class="registrationDescribe">Email</span>
                    <span class="registrationDescribe"> Please ensure you input the correct email as we will not be held responsible for unnecessary troubles arising from wrong emails</span>
                    <div class="registrationDivs">
                    <input name="bookEmail" type="email" id="bookEmail" placeholder="Email" value="" minlength="2" > 
                 </div>
                <p>
                    The book in its E-format will be sent to your email...
                    Thanks for the purchase
                </p>
                </fieldset>
             </form>
         </div>
     </section>
     <script src="javascripts/jquery.js"></script>
     <script src="javascripts/script.js"></script>
     <script src="javascripts/script1.js"></script>
	 <script>
         
   
	 </script>
        
	</body>
</html>