<?php


require_once('../includes/db_connection.php');
require_once('../includes/functions.php');
require_once('../includes/validation_functions.php');
require_once('../includes/session.php');
require_once('../includes/user.php');

sleep(3);
if(!is_ajax_request()) {exit;}
	$required_fields = array("email", "password");
	validate_presences($required_fields);
	// print_r($errors);
	if(!empty($errors)) {
		$return_array = ['success' => false, 'message' => form_errors($errors)];
		echo json_encode($return_array);
		exit;
	}
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	if($admin = attempt_login($email, $password)) {
		$_SESSION['testing'] = "My name is Okerefe";
		// echo $_SESSION['testing'];
		$session->login($admin);
		$return_array = ['success' => true, 'location' => "admin/index.php", 'message' => "Login Successful redirecting..."];
		echo json_encode($return_array);
		exit;
	} else {
		$return_array = ['success' => false, 'message' => "Username Or Password Incorrect"];
		echo json_encode($return_array); exit;
	}
	
?>